# BigQuery storage billing: logical vs physical

A reference for SAs running the BQ Profiler. Explains the two BigQuery
storage billing models, why customers tend to land on one or the
other, and how the profiler surfaces both views so the SA can
identify a pre-migration optimization opportunity.

## The two models

BigQuery charges for storage on either of two metrics, picked
**per dataset** by the customer.

| | Logical billing | Physical billing |
|---|---|---|
| What you pay for | **Uncompressed** bytes (the size of your data before BigQuery's columnar compression) | **Compressed on-disk** bytes (the actual storage footprint) |
| Active rate (US, 2026) | $20 / TB / month | $40 / TB / month |
| Long-term rate (US, 2026) | $10 / TB / month (>90 days unmodified) | $20 / TB / month |
| Time-travel storage | **Free** | Billed at active rate |
| Fail-safe storage | **Free** | Billed at active rate |
| Switching | Default. Customer can opt-in to physical billing per dataset — **but this is one-way (irreversible)**. | Opt-in only. |

Physical billing is roughly 2× the per-TB rate, but the bytes
charged are typically 3–10× smaller because of BigQuery's Capacitor
columnar compression. The break-even compression ratio is 2×: above
that and physical bills less in absolute dollars, below it and
logical wins.

## Why most customers are on logical

In our profiler runs, most customers have all-logical or
mostly-logical datasets. The reasons aren't economic — they're
process artifacts.

1. **Default + inertia.** New datasets default to logical. Physical
   billing was introduced in 2023; older datasets pre-date it.
   Customers who never re-evaluate just stay on logical.

2. **Switching is one-way.** Once a dataset flips to physical, the
   customer can't switch back. Teams that frame this as a financial
   risk choose to leave datasets alone.

3. **Compliance / audit constraints.** Some orgs lock down dataset
   billing-model changes because the switch crosses a financial-
   control boundary.

## When logical is actually the right choice

Even after re-evaluating, some workloads genuinely belong on logical.

1. **Heavy churn + short retention requirements.** Physical billing
   bills you for time-travel (7 days of modified rows) **and**
   fail-safe (another 7 days of immutable safety-net data). Under
   logical, both are free. For tables with heavy `UPDATE` /
   `DELETE` / `MERGE` / streaming churn, time-travel + fail-safe
   bytes routinely run 2–3× the active physical bytes — which
   erodes the compression advantage and can push physical above
   logical. Common in operational tables; less common in analytic
   append-only tables.

2. **Poor compression ratio.** Pre-compressed media, encrypted
   blobs, randomized IDs — anything that doesn't compress better
   than 2× makes physical more expensive. Rare in standard
   analytics, real for niche workloads.

3. **Cost predictability.** Logical bills track row count; physical
   bills can fluctuate with time-travel state. Some finance teams
   prefer the simpler model.

## Quick decision rule

| Compression ratio | Churn rate | Better choice |
|---|---|---|
| > 2× | Low (append-only / batch) | **Physical** |
| > 2× | High (heavy MERGE / streaming) | **Depends** — model time-travel overhead |
| < 2× | Any | **Logical** |

The conservative move when uncertain: model both views (the
profiler does — see below) and pick whichever is lower for the
customer's specific data shape.

## How the profiler surfaces both views

The post-analysis job materializes the `BQ_STORAGE_COST` table
(per `2-data-analysis.py`, see also
`plans/storage-cost-fix.md` for the math). Two columns matter
for this conversation:

- **`hypothetical_storage_cost_all_logical`** — what the customer's
  bill would be if every dataset in this project-region were on
  logical billing.
- **`hypothetical_storage_cost_all_physical`** — what the bill
  would be under physical billing.
- **`storage_cost_bq_monthly`** — what they actually pay today
  (mixed across datasets based on each dataset's billing model).

Plus a derived signal:

- **`physical_savings_pct_if_switched`** — the percentage cost
  reduction the customer would see if every logical dataset
  flipped to physical. NULL when the customer is already 100%
  physical (no signal). Positive when physical is cheaper;
  negative when logical is cheaper (so the customer is already
  on the optimal model).

The dashboard doesn't currently surface these as a recommendation
widget. If the SA wants to make "switch billing model" a visible
suggestion before showing the Databricks migration story, the
columns are already there — it's a one-widget add.

## SA conversation hook

If the profiler shows `physical_savings_pct_if_switched > 30%`
across a customer's largest project-regions, that's a substantial
pre-migration optimization the customer could capture **without**
moving to Databricks. Acknowledging it is the right move — it
builds credibility ("we noticed you could save $X/mo on BQ alone
by switching billing models on your top datasets") and it
reframes the migration conversation around the **other** savings
(compute, plus the storage savings beyond the billing-model
optimization).

The migration projection in the profiler always assumes the
customer migrates as-is (physical bytes onto cloud object storage
at Delta Lake / Parquet), so it captures the compression benefit
regardless of the source billing model — which is the right
default for an SA quote.

## References

- BigQuery storage pricing: https://cloud.google.com/bigquery/pricing#storage
- Storage billing models: https://cloud.google.com/bigquery/docs/storage-billing-models
- Profiler storage math: `post-analysis/notebooks/2-data-analysis.py`
  (BQ_STORAGE_COST materialization)
- Bug-fix history for the migration-volume math:
  `plans/2026-05-22-dashboard-cleanup.md`
