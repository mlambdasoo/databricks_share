-- This query produces daily estimated aggregates of the billed TiB 
-- and the resulting charges. BigQuery hides some statistics for queries 
-- over tables with row-level security. 
-- This query counts the number of jobs impacted as jobs_using_row_level_security, 
-- but does not have access to the billable usage.

DECLARE metadatalevel STRING DEFAULT 'region-us';
DECLARE profiling_window_in_days INT64 DEFAULT 180;
DECLARE price_per_tb FLOAT64 DEFAULT 6.25;
    
-- SET metadatalevel to the format <project>.<region>
SET metadatalevel = 'my-gcp-project.region-us';
SET profiling_window_in_days = 180;
SET price_per_tb = 6.25;

CREATE TEMP FUNCTION isBillable(error_result ANY TYPE)
AS (
  -- You aren't charged for queries that return an error.
  error_result IS NULL
  -- However, canceling a running query might incur charges.
  OR error_result.reason = 'stopped'
);

-- BigQuery hides the number of bytes billed on all queries against tables with
-- row-level security.
CREATE TEMP FUNCTION isMaybeUsingRowLevelSecurity(
  job_type STRING, tib_billed FLOAT64, error_result ANY TYPE)
AS (
  job_type = 'QUERY'
  AND tib_billed IS NULL
  AND isBillable(error_result)
);

EXECUTE IMMEDIATE 
FORMAT("""
WITH
  query_params AS (
    SELECT
      CAST(CURRENT_DATE() - INTERVAL @profiling_window_in_days DAY AS DATE) AS start_date,  -- inclusive
      CURRENT_DATE() AS end_date,  -- inclusive
  ),
  usage_with_multiplier AS (
    SELECT
      job_type,
      error_result,
      creation_time,
      -- Jobs are billed by end_time in PST8PDT timezone, regardless of where
      -- the job ran.
      EXTRACT(date FROM end_time AT TIME ZONE 'PST8PDT') billing_date,
      total_bytes_billed / 1024 / 1024 / 1024 / 1024 total_tib_billed,
      CASE statement_type
        WHEN 'SCRIPT' THEN 0
        WHEN 'CREATE_MODEL' THEN 50 * @price_per_tb
        ELSE @price_per_tb
        END AS multiplier,
    FROM `%s`.INFORMATION_SCHEMA.JOBS_BY_PROJECT
  )
SELECT
  billing_date,
  sum(total_tib_billed * multiplier) estimated_charge,
  sum(total_tib_billed) estimated_usage_in_tib,
  countif(isMaybeUsingRowLevelSecurity(job_type, total_tib_billed, error_result))
    AS jobs_using_row_level_security,
FROM usage_with_multiplier, query_params
WHERE
  1 = 1
  -- Filter by creation_time for partition pruning.
  AND date(creation_time) BETWEEN date_sub(start_date, INTERVAL 2 day) AND end_date
  AND billing_date BETWEEN start_date AND end_date
  AND isBillable(error_result)
GROUP BY billing_date
ORDER BY billing_date
""", metadatalevel)
USING 
profiling_window_in_days AS profiling_window_in_days,
price_per_tb AS price_per_tb;