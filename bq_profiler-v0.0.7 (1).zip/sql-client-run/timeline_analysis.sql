-- This procedure runs through timelined historical workloads on BQ
-- and generates an aggregated view of slot utilization
-- split between ETL and BI.
--
-- Diagnostic: also rolls up bytes_processed per (hour x workload_type)
-- by taking the terminal cumulative bytes per job (MAX(total_bytes_processed)
-- per job_id) and attributing it to the hour of the job's last active
-- period (close to job_end_time). Surfaced downstream as a workload-
-- character signal (bytes-per-slot-sec). Diagnostic only — not a
-- projection input.
DECLARE metadatalevel STRING DEFAULT 'region-us';
DECLARE profiling_window_in_days INT64 DEFAULT 180;
DECLARE TIME_FORMAT STRING DEFAULT '%Y-%m';
-- SET metadatalevel to the format <project>.<region>
SET metadatalevel = 'my-gcp-project.region-us';
-- Look back how many days?
SET profiling_window_in_days = 180;
-- TIME_FORMAT options are '%Y-%m' for Monthly and '%Y-%m-%d' for daily
-- %Y-%m-%dT%H for hourly
SET TIME_FORMAT = '%Y-%m-%dT%H';
EXECUTE IMMEDIATE
FORMAT("""
WITH SLOT_USAGE_PER_SEC AS
(
  SELECT
  period_start,
  period_slot_ms,
  job_type,
  statement_type
FROM
  `%s`.INFORMATION_SCHEMA.JOBS_TIMELINE
WHERE
  period_start BETWEEN TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL @lookback_period DAY) AND CURRENT_TIMESTAMP()
  AND (statement_type != 'SCRIPT' OR statement_type IS NULL)
),
STATEMENT_CLASSIFICATION AS
(
SELECT * FROM UNNEST([STRUCT<statement_type string, workload_category STRING>
  ("SELECT", "BI"),
  ("ASSERT", "ETL"),
  ("INSERT", "ETL"),
  ("UPDATE", "ETL"),
  ("DELETE", "ETL"),
  ("MERGE", "ETL"),
  ("CREATE_TABLE", "ETL"),
  ("CREATE_TABLE_AS_SELECT", "ETL"),
  ("CREATE_VIEW","ETL"),
  ("CREATE_MODEL", "ML"),
  ("CREATE_MATERIALIZED_VIEW", "ETL"),
  ("CREATE_FUNCTION", "ETL"),
  ("CREATE_PROCEDURE", "ETL"),
  ("CREATE_SCHEMA", "ETL"),
  ("DROP_TABLE", "ETL"),
  ("DROP_EXTERNAL_TABLE", "ETL"),
  ("DROP_VIEW", "ETL"),
  ("DROP_MATERIALIZED_VIEW", "ETL"),
  ("DROP_FUNCTION", "ETL"),
  ("DROP_PROCEDURE", "ETL"),
  ("DROP_SCHEMA", "ETL"),
  ("ALTER_TABLE", "ETL"),
  ("ALTER_VIEW", "ETL"),
  ("ALTER_MATERIALIZED_VIEW", "ETL"),
  ("SCRIPT", "ETL"),
  ("TRUNCATE_TABLE", "ETL"),
  ("CREATE_EXTERNAL_TABLE", "ETL"),
  ("EXPORT_DATA", "ETL"),
  ("CALL", "ETL"),
  ("QUERY_STATEMENT_TYPE_UNSPECIFIED", "Other"),
(null, "BI")
  ])
),
-- each second may be repeated per job
-- hence, aggregation by period_start is important
SLOT_USAGE_PER_SEC_BY_WORKLOAD
AS
(
  SELECT s.period_start,
          SUM(s.period_slot_ms) as period_slot_ms,
          CASE
          WHEN stmt.workload_category is NULL AND s.job_type = 'QUERY' THEN 'BI'
          WHEN stmt.workload_category is NULL AND s.job_type = 'COPY' THEN 'ETL'
          WHEN stmt.workload_category is NULL AND s.job_type = 'LOAD' THEN 'ETL'
          ELSE stmt.workload_category
          END as workload_type
          FROM SLOT_USAGE_PER_SEC s
          LEFT JOIN STATEMENT_CLASSIFICATION stmt
          ON s.statement_type = stmt.statement_type
          GROUP BY s.period_start, workload_type
),
-- num_slots_in_period = total_slot_secs in the period / secs in the period
SLOT_USAGE_AGGREGATED_BY_WORKLOAD
AS
(
  SELECT FORMAT_TIMESTAMP(@timeformat, period_start) as time_window,
          SUM(s.period_slot_ms) / 1000.0 as slot_secs,
          CAST(COUNT(1) as FLOAT64) as cumulative_secs_spent_in_exec,
          SUM(s.period_slot_ms) / (1000.0 * CAST(COUNT(1) as FLOAT64)) AS slots_avg,
          APPROX_QUANTILES(s.period_slot_ms / 1000.0, 100) [OFFSET(50)] AS slots_perc_50th,
          APPROX_QUANTILES(s.period_slot_ms / 1000.0, 100) [OFFSET(90)] AS slots_perc_90th,
          APPROX_QUANTILES(s.period_slot_ms / 1000.0, 100) [OFFSET(99)] AS slots_perc_99th,
          MAX(s.period_slot_ms / 1000.0) AS slots_max,
          workload_type
          FROM SLOT_USAGE_PER_SEC_BY_WORKLOAD s
          GROUP BY FORMAT_TIMESTAMP(@timeformat, period_start),
          workload_type
),
-- Per-job terminal cumulative bytes_processed (MAX across periods of the job)
-- attributed to the hour of the job's last active period. JOBS_TIMELINE's
-- total_bytes_processed is cumulative-as-of-period; the row's MAX equals the
-- job's final total. For typical sub-hour jobs this is exact; for multi-hour
-- jobs it attributes all bytes to the terminal hour (approximation).
JOB_BYTES_TERMINAL AS
(
  SELECT
    j.job_id,
    j.workload_type,
    FORMAT_TIMESTAMP(@timeformat, MAX(j.period_start)) AS time_window,
    MAX(j.total_bytes_processed) AS bytes_processed_final
  FROM (
    SELECT
      jt.job_id,
      jt.period_start,
      jt.total_bytes_processed,
      CASE
        WHEN stmt.workload_category IS NULL AND jt.job_type = 'QUERY' THEN 'BI'
        WHEN stmt.workload_category IS NULL AND jt.job_type = 'COPY' THEN 'ETL'
        WHEN stmt.workload_category IS NULL AND jt.job_type = 'LOAD' THEN 'ETL'
        ELSE stmt.workload_category
      END AS workload_type
    FROM `%s`.INFORMATION_SCHEMA.JOBS_TIMELINE jt
    LEFT JOIN STATEMENT_CLASSIFICATION stmt
      ON jt.statement_type = stmt.statement_type
    WHERE jt.period_start BETWEEN TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL @lookback_period DAY) AND CURRENT_TIMESTAMP()
      AND (jt.statement_type != 'SCRIPT' OR jt.statement_type IS NULL)
      AND jt.total_bytes_processed IS NOT NULL
  ) j
  GROUP BY j.job_id, j.workload_type
),
BYTES_BY_HOUR_WORKLOAD AS
(
  SELECT
    time_window,
    workload_type,
    SUM(bytes_processed_final) AS bytes_processed
  FROM JOB_BYTES_TERMINAL
  GROUP BY time_window, workload_type
)
SELECT
  s.time_window,
  @metadatalevel AS metadata_level,
  s.workload_type,
  s.slot_secs,
  s.slots_avg,
  s.slots_perc_50th,
  s.slots_perc_90th,
  s.slots_perc_99th,
  s.slots_max,
  s.cumulative_secs_spent_in_exec,
  b.bytes_processed
FROM SLOT_USAGE_AGGREGATED_BY_WORKLOAD s
LEFT JOIN BYTES_BY_HOUR_WORKLOAD b
  USING (time_window, workload_type)
ORDER BY s.time_window, s.workload_type;
""", metadatalevel, metadatalevel)
USING
metadatalevel AS metadatalevel,
TIME_FORMAT AS timeformat,
profiling_window_in_days AS lookback_period;
