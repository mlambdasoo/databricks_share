# BigQuery Profiler

A lightweight, customer-run tool that collects BigQuery usage metadata so Databricks can model an equivalent workload on Lakehouse. It reads from BigQuery `INFORMATION_SCHEMA` views only — **no customer query results or table data are accessed**.

The profiler runs against your BQ project(s), produces a small zip of CSVs, and you send the zip back to your Databricks contact.

---

## What you need

| | |
|---|---|
| **GCP access** | A user account or service account with BigQuery read permissions across the project(s) you want to profile. |
| **Run environment** | GCP Cloud Shell (recommended — no local setup) **or** a local machine with Python 3.9+ and the `gcloud` CLI installed and authenticated. |
| **Time** | Typically 5–20 minutes depending on the number of `(project × region)` pairs you include. |

### IAM permissions

The identity running the profiler needs the following BigQuery permissions on the project(s) being profiled:

- `bigquery.datasets.get` *— also reads each dataset's storage billing model (logical vs physical) from `INFORMATION_SCHEMA.SCHEMATA.ddl`, which is dataset metadata. Without it, every dataset is classified as logical and the storage cost projection will be wrong for any datasets actually using physical billing.*
- `bigquery.tables.get`
- `bigquery.tables.list`
- `bigquery.routines.get`
- `bigquery.routines.list`
- `bigquery.jobs.create`
- `bigquery.jobs.listAll`
- `bigquery.capacityCommitments.list`
- `bigquery.readsessions.create`
- `bigquery.readsessions.getData`

The simplest path is to attach the **BigQuery Admin** role (`roles/bigquery.admin`) on the project, which covers all of the above. If you need a least-privilege custom role, the list above is the exact set.

---

## Setup

### 1. Get the profiler package

Your Databricks contact will send you a zip (e.g., `bq_profiler-v0.0.7.zip`).

### 2. Upload to GCP Cloud Shell (recommended)

1. Open the GCP Console → click the **Activate Cloud Shell** icon (top-right).
2. Upload the zip via the Cloud Shell **⋮ menu → Upload** or the editor's file panel.
3. Unzip:
   ```bash
   unzip bq_profiler-v0.0.7.zip -d bq_profiler-v0.0.7
   cd bq_profiler-v0.0.7/automation
   ```

Cloud Shell is preferred because authentication is automatic (uses your logged-in GCP identity) and Python is pre-installed.

### Alternative: run locally

If you can't use Cloud Shell, run on your local machine:

```bash
# Authenticate
gcloud auth login
gcloud auth application-default login
gcloud config set project YOUR-BQ-PROJECT-ID

# Install Python dependencies
cd bq_profiler-v0.0.7/automation
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

---

## Configure

Edit `automation/config/bq_settings.json` with your details:

```json
{
    "customer_name": "your_company",
    "projects": ["your-bq-project-id"],
    "regions": ["us", "eu", "us-central1"],
    "project_regions_csv": []
}
```

- **`customer_name`** — A short identifier for your company (lowercase, no spaces). This becomes the output zip's name.
- **`projects`** — List of BQ project IDs to profile. Include all projects you want included in the analysis.
- **`regions`** — List of GCP regions where your BQ data lives. Include all relevant regions. (For convenience, the file ships pre-populated with every supported GCP region — leave as-is if unsure.)
- **`project_regions_csv`** — Optional. If you only want to profile *specific* `(project, region)` pairs, list them here (one per line as `"project_id,region"`). Otherwise leave as `[]` and the profiler will try every combination of `projects × regions`.

![bq_settings.json example](./image-files/updating-bq-settings-json.png)

---

## Run

From the `automation/` directory:

```bash
python run.py
```

**Options** (most users won't need these):

| Flag | Purpose |
|---|---|
| `--cred-file=/path/to/key.json` | Path to a GCP service-account JSON key. Skip this if you're using Cloud Shell or `gcloud auth`. |
| `--num-threads=N` | Run up to N regions in parallel. Default is 1. Bumping to 4 typically halves the runtime. |

The script will:
1. Compile the SQL templates against each `(project, region)` you configured.
2. Execute them against BQ.
3. Write CSV results to `output/runs/<customer_name>/`.
4. Bundle everything into `output/<customer_name>.zip` when done.

You'll see progress per region. When you see `Output saved in zipped archive: ...`, the run is complete.

---

## Send the results back

Download `output/<customer_name>.zip` (from Cloud Shell: right-click in the file panel → Download; locally: it's in the `automation/output/` folder).

Share that single zip with your Databricks contact via whichever channel you've been using (Slack file share, email attachment, customer-facing Drive folder, etc.).

That's it — the rest of the analysis happens on the Databricks side.

---

## What the profiler queries

All collection is from `INFORMATION_SCHEMA` views — the profiler never reads from your actual tables:

- `JOBS_TIMELINE_BY_*` — per-job slot usage, runtime, workload type
- `RESERVATIONS_TIMELINE` / `RESERVATION_CHANGES` — capacity commitments and reservation history
- `TABLE_STORAGE` — current storage footprint (sizes only, no contents)
- `SCHEMATA` — dataset-level metadata including the `storage_billing_model` option (logical vs physical)
- `STREAMING_TIMELINE_*` / `WRITE_API_TIMELINE_*` — streaming ingest volume

**No customer query text, query results, table contents, or PII is read.** The storage billing model comes from the `ddl` column of `INFORMATION_SCHEMA.SCHEMATA`, which is dataset metadata (covered by `bigquery.datasets.get`) — the profiler's SQL never executes a `SELECT` against any of your data tables, and no table-data read permission (`bigquery.tables.getData`) is requested. The full list of SQL templates is in `sql-client-run/` if your security team wants to review.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `Permission denied` errors during execution | Verify the IAM permissions listed above. Try `roles/bigquery.admin` if a custom role isn't working. |
| `Auth credentials not found` | Run `gcloud auth application-default login`. Or pass `--cred-file=/path/to/key.json`. |
| One region returns empty results | Expected — you may not have data in every region. The zip will still be complete. |
| Run feels stuck on one region | Some history-heavy queries can take 10+ minutes on busy projects. If a region is genuinely stuck (>30 min), Ctrl+C and re-run with that region removed; share what you have. |

Reach out to your Databricks contact if you hit anything else.
