import os
import datetime
from typing import Optional

class Logger:
    _instance = None
    
    def __new__(cls, log_dir: str = "logs"):
        if cls._instance is None:
            cls._instance = super(Logger, cls).__new__(cls)
            cls._instance.log_dir = log_dir
            cls._instance._ensure_log_directory()
            cls._instance.log_file = os.path.join(
                cls._instance.log_dir, 
                f"app_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
            )
        return cls._instance

    def _ensure_log_directory(self) -> None:
        if not os.path.exists(self.log_dir):
            os.makedirs(self.log_dir)
    
    def _write_log(self, level: str, message: str) -> None:
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] {level}: {message}\n"
        
        with open(self.log_file, "a") as f:
            f.write(log_entry)

    def info(self, message: str) -> None:
        self._write_log("INFO", message)

    def debug(self, message: str) -> None:
        self._write_log("DEBUG", message)

    def warning(self, message: str) -> None:
        self._write_log("WARNING", message)

    def error(self, message: str) -> None:
        self._write_log("ERROR", message)