import json
import os
from .logger import Logger

class Compiler:
    def __init__(self, base_path:str, substitutions_file:str, output_folder:str, logger:Logger=None, **kwargs):
        """
        Initialize the Compiler with paths and substitution variables.
        
        :param substitutions_file: Path to the JSON file with substitution rules.
        :param output_folder: Directory to save the modified SQL files.
        :param kwargs: Substitution variables where key is the variable name 
                       and value is the replacement text.
        """
        try:
            self.base_path = base_path
            self.substitutions_file = substitutions_file
            self.variables = kwargs  # Store substitution variables
            if not self.variables.get("project_region"):
                raise Exception("The 'project_region' variable is required but was not provided.")
            self.output_folder = os.path.join(output_folder, self.variables.get("project_region"))
            self.logger = logger
        except Exception as e:
            print(f"Error initializing Compiler: {e}")
            raise

    def apply_substitutions(self, file_path, substitutions):
        """
        Apply substitutions to specific lines in the SQL file identified by search_text.
        
        :param file_path: Path to the SQL file.
        :param substitutions: List of substitution rules for this file.
        :return: Modified SQL text as a single string.
        """
        try:
            self.logger.debug(f"Reading file: {file_path}")
            with open(file_path, 'r') as file:
                sql_lines = file.readlines()

            for sub in substitutions:
                if sub["is_rule_active"]:
                    # Check if the replacement variable is provided in kwargs
                    if sub["replace_with_var"] in self.variables:
                        replacement = self.variables[sub["replace_with_var"]]
                        for i, line in enumerate(sql_lines):
                            if sub["search_text"] in line:
                                # Replace only within the specified line containing `search_text`
                                sql_lines[i] = line.replace(sub["find_text"], replacement)
                                break

            return ''.join(sql_lines)
        except FileNotFoundError:
            self.logger.error(f"File not found: {file_path}")
            raise
        except KeyError as e:
            self.logger.error(f"Missing substitution key: {e}")
            raise
        except Exception as e:
            self.logger.error(f"Error applying substitutions to {file_path}: {e}")
            raise

    def save_modified_sql(self, original_file_path, modified_sql_text):
        """
        Save the modified SQL text to a new file in the output folder,
        retaining the original file name.
        
        :param original_file_path: Path to the original SQL file.
        :param modified_sql_text: Modified SQL content to save.
        """
        try:
            os.makedirs(self.output_folder, exist_ok=True)
            original_file_name = os.path.basename(original_file_path)
            new_file_path = os.path.join(self.output_folder, original_file_name)

            self.logger.debug(f"Saving modified SQL to: {new_file_path}")
            with open(new_file_path, 'w') as file:
                file.write(modified_sql_text)
        except OSError as e:
            self.logger.error(f"Error creating directory or writing file: {e}")
            raise
        except Exception as e:
            self.logger.error(f"Error saving modified SQL file: {e}")
            raise

    def compile(self):
        """
        Load substitution rules, apply substitutions, and save modified SQL files.
        """
        try:
            self.logger.debug(f"Loading substitution rules from: {self.substitutions_file}")
            with open(self.substitutions_file, 'r') as file:
                substitution_rules = json.load(file)

            for rule in substitution_rules:
                self.logger.debug(f"Processing rule: {rule}")
                file_path = os.path.join(self.base_path, rule["file_path"])
                substitutions = rule["substitutions"]

                try:
                    self.logger.debug(f"Applying substitutions to file: {file_path}")
                    # Apply substitutions and generate modified SQL text
                    modified_sql_text = self.apply_substitutions(file_path, substitutions)
                    
                    self.logger.debug(f"Saving modified SQL as {file_path}")
                    self.logger.info(f"SQL text: {modified_sql_text}")
                    # Save the modified SQL text to the output folder
                    self.save_modified_sql(file_path, modified_sql_text)
                except Exception as e:
                    self.logger.error(f"Error processing file {file_path}: {e}")
                    # Continue with next file if there's an error
        except FileNotFoundError:
            self.logger.error(f"Substitutions file not found: {self.substitutions_file}")
            raise
        except json.JSONDecodeError:
            self.logger.error(f"Error decoding JSON in file: {self.substitutions_file}")
            raise
        except Exception as e:
            self.logger.error(f"Error in compilation process: {e}")
            raise
