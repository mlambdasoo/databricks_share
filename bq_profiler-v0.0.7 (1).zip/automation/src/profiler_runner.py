import os
from google.cloud import bigquery
from google.oauth2 import service_account
import csv
# import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from .logger import Logger

class ProfilerRunner:
    def __init__(self, root_folder:str, output_folder:str, output_files_and_analysis_type_map:dict, credential_file:str=None, logger:Logger=None, num_threads:int=10) -> None:
        """
        Initialize ProfilerRunner with root folder for SQL files and output folder for CSVs.
        
        :param root_folder: Root directory containing <project_id>.<region> folders with SQL files.
        :param output_folder: Directory to save CSV outputs.
        """
        self.root_folder = root_folder
        self.output_folder = output_folder
        self.credential_file = credential_file
        self.logger = logger
        self.num_threads = num_threads
        self.output_files_and_analysis_type_map = output_files_and_analysis_type_map

    def run_sql_and_save_csv(self, sql_file, project_id, region):
        """
        Execute SQL and save results as CSV.
        
        :param sql_file: Path to the SQL file to execute.
        :param project_id: BigQuery project ID.
        :param region: BigQuery region.
        """
        try:
            self.logger.debug(f"Reading compiled SQL file: {sql_file}")
            with open(sql_file, 'r') as file:
                query = file.read()

            newregion = region.replace("region-", "")
            self.logger.debug(f"Fixed region {region} to {newregion}")

            if self.credential_file:
                if os.path.exists(self.credential_file):
                    # Create credentials using the service account key file
                    self.logger.debug(f"Using credential file: {self.credential_file} to initialize BigQuery client with project {project_id} and location {newregion}")
                    credentials = service_account.Credentials.from_service_account_file(self.credential_file)
                    client = bigquery.Client(project=project_id, location=newregion, credentials=credentials)
                else:
                    self.logger.error(f"Credential file {self.credential_file} not found.")
                    raise FileNotFoundError(f"Credential file {self.credential_file} not found.")
            else:
                self.logger.debug(f"Using default credentials, initializing BigQuery client with project {project_id} and location {newregion}")
                client = bigquery.Client(project=project_id, location=newregion)

            self.logger.debug(f"Executing query: {query}")
            # Execute the query
            query_job = client.query(query)
            result = query_job.result()  # Wait for the job to complete

            # Add validation for unexpected result types
            if result is None:
                raise ValueError(f"Query returned None result for {sql_file}")
                
            if isinstance(result, str):
                raise ValueError(f"Query returned error string: {result}")
                
            if not hasattr(result, 'schema'):
                raise ValueError(f"Query result missing schema attribute: {type(result)}")

            # Prepare output file path
            sql_filename_without_extn = os.path.splitext(os.path.basename(sql_file))[0]
            sql_filename_extn = ".csv"
            sql_filename_with_extn = sql_filename_without_extn + sql_filename_extn
            subfolder_name = self.output_files_and_analysis_type_map.get(sql_filename_with_extn, "other")
            output_file_name = f"{project_id}.{region}_{sql_filename_with_extn}"

            output_dir = os.path.join(self.output_folder, subfolder_name)
            os.makedirs(output_dir, exist_ok=True)
            output_file = os.path.join(output_dir, output_file_name)

            self.logger.debug(f"Writing query result to CSV: {output_file}")
            # Write result to CSV
            with open(output_file, 'w', newline='') as csv_file:
                writer = csv.writer(csv_file)
                writer.writerow([field.name for field in result.schema])  # Write header
                for row in result:
                    writer.writerow(row.values())

            # print(f"Query result saved to {output_file}")
        except Exception as e:
            self.logger.error(f"Failed to execute {sql_file}: {e}")
            raise  # Re-raise the exception for handling upstream

    def execute_sql_file(self, args):
        """Helper function to execute a single SQL file"""
        sql_file_path, project_id, region = args
        try:
            return self.run_sql_and_save_csv(sql_file_path, project_id, region)
        except Exception as e:
            return sql_file_path, e

    def execute_all_sql_files(self) -> None:
        """Execute SQL files from project folders in parallel"""
        execution_args = []
    
        # Collect all SQL files and their project info
        self.logger.debug(f"Preparing args for parallel execution of SQL")
        for folder_name in os.listdir(self.root_folder):
            folder_path = os.path.join(self.root_folder, folder_name)
            
            if os.path.isdir(folder_path) and '.' in folder_name:
                project_id, region = folder_name.split('.', 1)
                
                for file_name in os.listdir(folder_path):
                    if file_name.endswith(".sql"):
                        sql_file_path = os.path.join(folder_path, file_name)
                        execution_args.append((sql_file_path, project_id, region))
        
        self.logger.debug(f"Executing {len(execution_args)} SQL files in {self.num_threads} threads at a time in parallel")
        # Execute SQL files in parallel
        with ThreadPoolExecutor(max_workers=min(len(execution_args), self.num_threads)) as executor:
            future_to_sql = {
                executor.submit(self.execute_sql_file, args): args[0]
                for args in execution_args
            }
            
            for future in as_completed(future_to_sql):
                sql_file = future_to_sql[future]
                try:
                    result = future.result()
                    if isinstance(result, tuple):  # Error case
                        self.logger.error(f"Failed to execute {result[0]}: {result[1]}")
                except Exception as e:
                    self.logger.error(f"Failed to execute {sql_file}: {e}")
                    raise  # Re-raise for upstream handling

