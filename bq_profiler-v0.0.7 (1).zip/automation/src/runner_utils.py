import os
import re
import zipfile
import json
from .logger import Logger

class RunnerUtils:

    def __init__(self, logger:Logger):
        self.logger = logger

    def zip_directory(self, source_dir, output_filename):
        """
        Creates a zip file from the contents of a directory.
        
        :param source_dir: The directory to zip.
        :param output_filename: The name of the resulting zip file (e.g., 'output.zip').
        """
        self.logger.debug(f"Begin creating zip file '{output_filename}' from directory '{source_dir}'...")
        try:
            # Check if the source directory exists
            if not os.path.isdir(source_dir):
                raise FileNotFoundError(f"Cannot generate zipped archive because the directory '{source_dir}' does not exist.")
            
            # Open a zip file for writing
            with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
                # Walk through all files and directories inside the source directory
                for root, dirs, files in os.walk(source_dir):
                    for file in files:
                        file_path = os.path.join(root, file)
                        try:
                            # Add file to zip, preserving the directory structure
                            arcname = os.path.relpath(file_path, start=source_dir)
                            zipf.write(file_path, arcname)
                            self.logger.debug(f"Added '{file_path}' to zip.")
                        except Exception as e:
                            self.logger.error(f"Error adding '{file_path}' to zip: {e}")
            
            self.logger.info(f"Zip file created successfully: {output_filename}")
            self.logger.debug(f"End creating zip file")
        
        except FileNotFoundError as e:
            self.logger.error(f"File not found error: {e}")
            raise
        except zipfile.BadZipFile:
            self.logger.error(f"Error: Failed to create a valid zip file '{output_filename}'.")
            raise
        except PermissionError as e:
            self.logger.error(f"Permission error: {e}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def load_bq_settings(self, bq_settings_path):
        """
        Loads the bq_settings.json file, which contains the project and region specs 
        for the profiler.
        
        :param bq_settings_path: bq_settings json path.
        """
        self.logger.debug(f"Loading BigQuery settings from: {bq_settings_path}")
        try:
            with open(bq_settings_path, 'r') as file:
                return json.load(file)
        except FileNotFoundError as e:
            self.logger.error(f"File not found error: {e}")
            raise
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            raise
        except PermissionError as e:
            self.logger.error(f"Permission error: {e}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise
        
    def load_vars(self, vars_file):
        """
        Loads the vars.json file, which contains variables to be plugged into the substitutions.json file.
        
        :param vars_file: vars.json file path.
        """
        self.logger.debug(f"Loading variables from: {vars_file}")
        try:
            with open(vars_file, 'r') as file:
                return json.load(file)
        except FileNotFoundError as e:
            self.logger.error(f"File not found error: {e}")
            raise
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            raise
        except PermissionError as e:
            self.logger.error(f"Permission error: {e}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise
        
    def clean_up_text(self, input_string):
        """
        Generate a valid customer name by cleaning the input string.

        This function performs the following steps:
        1. Strips leading and trailing whitespaces.
        2. Removes all special characters other than period, whitespace, hyphen, and underscore.
        3. Replaces period, whitespace, and hyphen with underscores.

        Args:
        input_string (str): The input string to be cleaned.

        Returns:
        str: A cleaned string that can be used as a valid customer name.
        """
        try:
            # Strip leading and trailing whitespaces
            cleaned_string = input_string.strip()
            # Remove all special characters other than period, whitespace, hyphen, and underscore
            cleaned_string = re.sub(r'[^a-zA-Z0-9\s._-]', '', cleaned_string)
            # Replace period, whitespace, and hyphen with underscores
            cleaned_string = re.sub(r'[.\s-]', '_', cleaned_string)
            return cleaned_string
        except TypeError as e:
            self.logger.error(f"Type error: {e}")
            raise
        except re.error as e:
            self.logger.error(f"Regex error: {e}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def load_analysis_types(self, analysis_types_file):
        """
        Loads the analysis_types.json file, which contains the analysis types to be run.
        Returns a dictionary mapping of output file names to analysis types.
        
        :param analysis_types_file: analysis_types.json file path.
        """
        self.logger.debug(f"Loading analysis_types settings from: {analysis_types_file}")
        try:
            analysis_types_spec = {}
            output_files_and_analysis_type_map = {}
            with open(analysis_types_file, 'r') as file:
                analysis_types_spec = json.load(file)

            for analysis_type, extras in analysis_types_spec.items():
                filenames = extras.get("filenames", [])
                for filename in filenames:
                    output_files_and_analysis_type_map[filename] = analysis_type
            return output_files_and_analysis_type_map
        
        except FileNotFoundError as e:
            self.logger.error(f"File not found error: {e}")
            raise
        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error: {e}")
            raise
        except PermissionError as e:
            self.logger.error(f"Permission error: {e}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise