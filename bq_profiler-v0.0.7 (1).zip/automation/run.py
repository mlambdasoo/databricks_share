# This script automates the process of compiling and executing SQL files for BigQuery profiling.
# Functions:
#     zip_directory(source_dir, output_filename):
#     load_bq_settings(bq_settings_path):
#         Loads the bq_settings.json file, which contains the project and region specs for the profiler.
#     load_vars(vars_file):
#         Loads the vars.json file, which contains variables to be plugged into the substitutions.json file.
#     clean_up_text(input_string):
#         Generates a valid customer name by cleaning the input string.
#     main(compile_only, cred_file=None, num_threads=1):
#         Main function to compile and execute SQL files for BigQuery profiling.
# Usage:
#     Run the script with the following command:
#     python run.py [--compile] [--cred-file=CRED_FILE] [--num-threads=NUM_THREADS]
#     Options:
#         --compile, -c: Only compile SQL files.
#         --cred-file, -f: Path to the GCP credential file.
#         --num-threads, -n: Number of threads to use for executing SQL files.

# Example command to compile SQL files only:
    # python run.py --compile
    # OR
    # python run.py -c

# Example command to compile and execute SQL files with a specified GCP credential file:
    # python run.py --cred-file=/path/to/your/credential/file.json

# Example command to compile and execute SQL files with a specified number of threads:
    # python run.py --num-threads=4

# Example command to compile and execute SQL files without any specified GCP credential file:
    # python run.py

import argparse
from src.compiler import Compiler
from src.profiler_runner import ProfilerRunner
from itertools import product
import os
import shutil
from src.logger import Logger
from src.runner_utils import RunnerUtils

def recreate_directory(directory_path):
    """
    Recreates a directory. If the directory exists, it is deleted and then recreated.
    If the directory does not exist, it is created.

    :param directory_path: The path of the directory to recreate.
    """
    if os.path.exists(directory_path):
        if os.path.isdir(directory_path):
            # Remove the existing directory
            shutil.rmtree(directory_path)
        else:
            raise NotADirectoryError(f"The path '{directory_path}' exists and is not a directory.")
    
    # Create the directory
    os.makedirs(directory_path)

def main(compile_only, cred_file=None, num_threads=1):
    output_folder_name = "output"
    sql_output_folder_name = "sql"
    runs_output_folder_name = "runs"
    log_output_folder_name = "logs"

    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    output_folder = os.path.join(base_dir, output_folder_name)
    log_output_folder = os.path.join(output_folder, log_output_folder_name)
    
    # Recreate the output directory
    recreate_directory(output_folder)

    # Initialize logger
    logger = Logger(log_output_folder)

    logger.debug(f"Base directory: {base_dir}")
    logger.debug(f"Input args: compile_only = {compile_only}, cred_file = {cred_file}, num_threads = {num_threads}")

    ru = RunnerUtils(logger)

    bq_settings_file = os.path.join(base_dir, "automation/config/bq_settings.json")
    substitutions_file = os.path.join(base_dir, "automation/config/substitutions.json")
    vars_file = os.path.join(base_dir, "automation/config/vars.json")
    analysis_types_file = os.path.join(base_dir, "automation/config/analysis_types.json")
    
    # This is the folder where the compiled SQL files will be saved
    sql_output_folder = os.path.join(output_folder, sql_output_folder_name)

    logger.debug(f"Loading BigQuery settings from: {bq_settings_file}")
    # Load BigQuery settings
    bq_settings = ru.load_bq_settings(bq_settings_file)

    logger.debug(f"Loading variables from: {vars_file}")
    # Load variables
    kwargs = ru.load_vars(vars_file)

    logger.debug(f"Loading analysis_types settings from: {analysis_types_file}")
    # Load analysis types
    output_files_and_analysis_type_map = ru.load_analysis_types(analysis_types_file)

    customer_name_supplied = bq_settings.get("customer_name")
    if not customer_name_supplied:
        logger.error("No customer_name provided in bq_settings.json")
        raise ValueError(f"Invalid customer_name provided: {customer_name_supplied}")

    customer_name = ru.clean_up_text(customer_name_supplied)
    logger.debug(f"Supplied customer name: {customer_name_supplied}. Cleaned customer name: {customer_name}")

    run_output_folder = os.path.join(output_folder, runs_output_folder_name, customer_name)
    zip_file_name = os.path.join(output_folder, f"{customer_name}.zip")

    # If a list of project_regions is supplied in thr format <project_id>.<region>
    # they will override all combinations of <project_id> and <region>
    project_regions = []
    project_regions_csv_list = bq_settings.get("project_regions_csv", [])
    if project_regions_csv_list and len(project_regions_csv_list) > 0:
        for pr_csv in project_regions_csv_list:
            project_region_array = [txt.strip() for txt in pr_csv.split(",")]
            project_region = f"{project_region_array[0]}.region-{project_region_array[1]}"
            
            # keep only unique project_regions
            if project_region not in project_regions:
                project_regions.append(project_region)
    else:
        # strip and remove duplicates from project_ids and regions
        project_ids = list(set([project.strip() for project in bq_settings.get("projects", [])]))
        regions_raw = list(set([region.strip() for region in bq_settings.get("regions", [])]))
        regions = [f"region-{region}" for region in regions_raw]
        project_regions = [f"{project}.{region}" for project, region in product(project_ids, regions)]

    logger.debug(f"Beginning SQL compilation for Project regions: {project_regions}")
    
    print(f"Compiling sql for project.regions...")
    # Instantiate and run the Compiler for each project-region
    for project_region in project_regions:
        try:
            print(f"{project_region} Done")

            compiler = Compiler(base_dir,
                                substitutions_file, 
                                sql_output_folder, 
                                project_region=project_region, 
                                logger=logger,
                                **kwargs)
            logger.debug(f"Compiling sql for {project_region}.")

            compiler.compile()
        except Exception as e:
            logger.error(f"Error compiling sql for {project_region}: {e}")
            print(f"Error compiling sql for {project_region}: {e}")

    if compile_only:
        logger.debug("Compilation only mode. Exiting after finishing compilation...")
        return

    print("\nExecuting sql...")
    logger.debug(f"Initializing profiler runner with args sql_output_folder = {sql_output_folder}, run_output_folder = {run_output_folder}, credential_file = {cred_file}, num_threads = {num_threads}")
    
    # Instantiate ProfilerRunner
    profiler_runner = ProfilerRunner(sql_output_folder, 
                                     run_output_folder, 
                                     output_files_and_analysis_type_map,
                                     credential_file=cred_file, 
                                     logger=logger,
                                     num_threads=num_threads)

    logger.debug("Executing all SQL files...")
    profiler_runner.execute_all_sql_files()
    print("\nExecution finished")

    if os.path.isdir(run_output_folder):
        logger.debug(f"Generating zip archive for output folder: {run_output_folder}")
        print("\nGenerating zip archive...")
        ru.zip_directory(run_output_folder, zip_file_name)
        print(f"\nOutput saved in zipped archive: {zip_file_name}")
        logger.debug(f"Zip archive generated successfully: {zip_file_name}")
    else:
        print("\nNo output files generated. Check logs for errors.")
        logger.error(f"No output files generated in {run_output_folder}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run the BigQuery profiler automation script.")
    parser.add_argument('--compile', '-c', action='store_true', help="Only Compile SQL files.")
    parser.add_argument('--cred-file', '-f', type=str, help="Path to the GCP credential file.")
    parser.add_argument('--num-threads', '-n', type=int, default=10, help="Number of threads to use for executing SQL files.")
    args = parser.parse_args()
    cred_file = args.cred_file if args.cred_file else None
    main(args.compile, cred_file, args.num_threads)