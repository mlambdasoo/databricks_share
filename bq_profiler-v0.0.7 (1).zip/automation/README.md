# BigQuery Profiler Automation - Local Setup Guide

This guide explains how to set up and run the BigQuery profiler automation tool locally on your machine, outside of the GCP console.

## Prerequisites

### 1. Python Environment
- **Python 3.8 or higher** (recommended: Python 3.9+)
- **pip** (Python package installer)

### 2. Google Cloud Setup
- **Google Cloud Project** with BigQuery enabled
- **Service Account** with appropriate BigQuery permissions
- **Service Account Key** (JSON file) for authentication
- **GCP Cloud Shell** (recommended for easy execution)

### 3. Required IAM Permissions
Your service account needs the following BigQuery permissions:
- `bigquery.datasets.get`
- `bigquery.datasets.create`
- `bigquery.capacityCommitments.list`
- `bigquery.tables.get`
- `bigquery.tables.list`
- `bigquery.routines.get`
- `bigquery.routines.list`
- `bigquery.jobs.create`
- `bigquery.readsessions.create`
- `bigquery.readsessions.getData`
- `bigquery.jobs.listAll`

## Local Environment Setup

### Step 1: Download and Extract the Package
```bash
# Download the BigQuery profiler zip package (e.g., bq_profiler-v0.0.1.zip)
# Extract the package
unzip bq_profiler-v0.0.1.zip -d bq_profiler-v0.0.1

# Navigate to the automation directory
cd bq_profiler-v0.0.1/automation
```

### Step 2: Create a Virtual Environment
```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# On macOS/Linux:
source venv/bin/activate

# On Windows:
venv\Scripts\activate
```

### Step 3: Install Dependencies
```bash
# Install required packages
pip install -r requirements.txt
```

### Step 4: Set Up Google Cloud Authentication

#### Option A: Using Service Account Key (Recommended for Local Development)
1. Download your service account key JSON file from Google Cloud Console
2. Place it in a secure location (e.g., `~/.gcp/credentials.json`)
3. Set the environment variable:
```bash
# On macOS/Linux:
export GOOGLE_APPLICATION_CREDENTIALS="~/.gcp/credentials.json"

# On Windows:
set GOOGLE_APPLICATION_CREDENTIALS=C:\path\to\credentials.json
```

#### Option B: Using gcloud CLI
```bash
# Install gcloud CLI if not already installed
# https://cloud.google.com/sdk/docs/install

# Authenticate with gcloud
gcloud auth login
```

#### Option C: Using GCP Cloud Shell (Recommended)
When running in GCP Cloud Shell, authentication is handled automatically:
```bash
# No additional setup needed - Cloud Shell provides default credentials
```

### Step 5: Configure the Project

#### 1. Update `config/bq_settings.json`
```json
{
  "customer_name": "your-customer-name",
  "projects": ["your-project-id"],
  "regions": ["us", "eu"],
  "project_regions_csv": []
}
```

#### 2. Update `config/vars.json`
```json
{
  "project_region": "your-project-id.region-us"
}
```

#### 3. Update `config/substitutions.json`
```json
[
  {
    "file_path": "sql-client-run/your-sql-file.sql",
    "substitutions": [
      {
        "is_rule_active": true,
        "search_text": "my-gcp-project.region-us",
        "find_text": "my-gcp-project.region-us",
        "replace_with_var": "project_region"
      }
    ]
  }
]
```

## Running the Profiler

### Basic Usage

#### Compile SQL files only:
```bash
python run.py --compile
# or
python run.py -c
```

#### Compile and execute with service account key:
```bash
python run.py --cred-file=/path/to/service-account-key.json
```

#### Compile and execute with custom thread count:
```bash
python run.py --num-threads=4
```

#### Full execution with all options:
```bash
python run.py --cred-file=/path/to/service-account-key.json --num-threads=8
```

#### Execute in GCP Cloud Shell (no credentials needed):
```bash
python run.py
```

### Command Line Options

- `--compile`, `-c`: Only compile SQL files without execution
- `--cred-file`, `-f`: Path to GCP service account key file
- `--num-threads`, `-n`: Number of threads for parallel execution (default: 10)

## Project Structure

```
automation/
├── README.md                 # This file
├── requirements.txt          # Python dependencies
├── run.py                   # Main execution script
├── config/                  # Configuration files
│   ├── bq_settings.json     # BigQuery project settings
│   ├── vars.json           # Variable substitutions
│   ├── substitutions.json   # SQL file substitution rules
│   └── analysis_types.json # Output file categorization
└── src/                     # Source code
    ├── __init__.py
    ├── compiler.py          # SQL compilation logic
    ├── profiler_runner.py   # BigQuery query execution
    ├── runner_utils.py      # Utility functions
    └── logger.py           # Logging functionality
```

## Output Structure

After running the profiler, you'll find:

```
output/
├── logs/                    # Execution logs
├── sql/                     # Compiled SQL files
│   └── project-id.region-us/
└── runs/                    # CSV output files
    └── customer-name/
        ├── consumption/
        ├── storage/
        └── other/
```

## Troubleshooting

### Common Issues

#### 1. Authentication Errors
```
google.auth.exceptions.DefaultCredentialsError
```
**Solution**: Ensure your service account key is properly configured and has the required permissions.

#### 2. Permission Denied
```
google.api_core.exceptions.Forbidden
```
**Solution**: Verify your service account has all required BigQuery IAM roles.

#### 3. Project Not Found
```
google.api_core.exceptions.NotFound
```
**Solution**: Check that the project ID in your configuration exists and is accessible.

#### 4. "String indices must be integers" Error
This error occurs when BigQuery returns an error string instead of a proper result object.
**Solution**: 
- Check SQL syntax in your queries
- Verify table/dataset existence
- Ensure proper permissions for all referenced resources

### Debug Mode

Enable detailed logging by checking the log files in `output/logs/`:
```bash
# View latest log file
tail -f output/logs/app_*.log
```

## Development

### Adding New SQL Files

1. Add your SQL file to the `sql-client-run/` directory
2. Update `config/substitutions.json` to include substitution rules
3. Update `config/analysis_types.json` to categorize the output

### Modifying Configuration

- **bq_settings.json**: Project and region configuration
- **vars.json**: Variables for SQL substitution
- **substitutions.json**: Rules for replacing placeholders in SQL files
- **analysis_types.json**: Categorization of output CSV files

## Security Best Practices

1. **Never commit service account keys** to version control
2. **Use environment variables** for sensitive configuration
3. **Rotate service account keys** regularly
4. **Limit service account permissions** to minimum required
5. **Use separate service accounts** for different environments

## Support

For issues or questions:
1. Check the log files in `output/logs/`
2. Verify your configuration files
3. Ensure all prerequisites are met
4. Test with a simple query first

## Contacts
- **uday.satapathy@databricks.com**
- **akash.jaiswal@databricks.com**

## Example Workflow

### Local Development Setup
```bash
# 1. Download and extract the package
unzip bq_profiler-v0.0.1.zip -d bq_profiler-v0.0.1
cd bq_profiler-v0.0.1/automation

# 2. Set up environment
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 3. Configure authentication
export GOOGLE_APPLICATION_CREDENTIALS="~/.gcp/credentials.json"

# 4. Update configuration files
# Edit config/bq_settings.json, config/vars.json, etc.

# 5. Test compilation
python run.py --compile

# 6. Run full execution
python run.py --cred-file=~/.gcp/credentials.json --num-threads=4

# 7. Check results
ls -la output/runs/your-customer-name/
```

### GCP Cloud Shell Setup (Recommended)
```bash
# 1. Upload the zip package to Cloud Shell
# 2. Extract the package
unzip bq_profiler-v0.0.1.zip -d bq_profiler-v0.0.1
cd bq_profiler-v0.0.1/automation

# 3. Update configuration files
# Edit config/bq_settings.json, config/vars.json, etc.

# 4. Run execution (no credentials needed in Cloud Shell)
python run.py

# 5. Download results
# The output zip will be in the output/ folder
``` 