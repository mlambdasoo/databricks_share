import { defineConfig, type Plugin } from "vite";
import react from "@vitejs/plugin-react";

// 웹 글꼴은 woff2만 쓴다: fontsource CSS의 woff(구형 브라우저용) 대체 경로를 지워 빌드에 woff 파일이 안 들어가게 한다
const woff2Only: Plugin = {
  name: "woff2-only",
  enforce: "pre",
  transform(code, id) {
    if (!id.includes("@fontsource") || !id.endsWith(".css")) return null;
    return code.replace(/,\s*url\([^)]*\.woff\)\s*format\(['"]woff['"]\)/g, "");
  },
};

export default defineConfig({
  plugins: [woff2Only, react()],
  build: { outDir: "../app/static", emptyOutDir: true, chunkSizeWarningLimit: 900 },
  server: { port: 5173, proxy: { "/api": "http://localhost:8765" } },
});
