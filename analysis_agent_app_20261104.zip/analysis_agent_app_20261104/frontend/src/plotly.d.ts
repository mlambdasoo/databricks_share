/**
 * plotly.js 번들 모듈의 타입 선언.
 * 용도: "plotly.js-cartesian-dist-min" 경로로 import할 때 plotly.js 타입을 붙여 준다.
 * 목적: 번들 경로에는 타입 정의가 없어서, TypeScript가 오류 없이 읽도록 하기 위함.
 */
declare module "plotly.js-cartesian-dist-min" {
  import Plotly from "plotly.js";
  export default Plotly;
}
