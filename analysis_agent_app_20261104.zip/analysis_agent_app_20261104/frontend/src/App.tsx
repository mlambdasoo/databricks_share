/**
 * 메인 화면 (대화 + 오른쪽 상세 패널).
 * 용도: 가운데 대화창(기본)과 오른쪽 상세 패널(오브젝트를 누르거나 데이터 버튼을 눌렀을 때만)을 그리고, 서버 스트림 이벤트를 화면 상태에 반영한다.
 * 목적: 분석 설정·결과·조회 결과는 대화에 오브젝트 카드로 남기고, 패널은 그 상세(설정 칸·표·차트)만 보여주기 위함.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { setUnit } from "./data";
import { fetchDemo, fetchMeta, fetchSettings, fetchSources, makePdf, pickSource, streamChat, type ServerEvent } from "./api";
import type { AnalysisResult, Artifact, Cfg, ChartSpec, DemoScenario, Layout, Meta, Panel, SourceItem, UIMsg } from "./types";
import ChatPane from "./components/ChatPane";
import Readout from "./components/Readout";
import SettingsPanel from "./components/SettingsPanel";
import DataPanel from "./components/DataPanel";
import LookupPanel from "./components/LookupPanel";
import WorkPanel from "./components/WorkPanel";
import ActivityBar, { type Activity } from "./components/ActivityBar";
import { captureCharts } from "./components/PlotChart";
import { DemoBar, DemoMenu, type DemoState } from "./components/Demo";

const uid = () => Math.random().toString(36).slice(2, 10);
const PANEL_DEFAULT = 720;
const PANEL_MIN = 420;
const panelMax = () => Math.max(PANEL_MIN, Math.round(window.innerWidth * 0.72));
const clampW = (w: number) => Math.round(Math.min(panelMax(), Math.max(PANEL_MIN, w)));
const EMPTY_LAYOUT: Layout = { removed: [], overrides: {}, added: [], cols: {} };

/** 대화로 바꾼 차트 배치(추가·수정·삭제·열 수)를 기존 레이아웃 위에 쌓는다. 기본 차트는 덮어쓰기로 바꾸고, 추가한 차트는 added 목록에서 고친다.
 *  입력: l — 지금 레이아웃(없으면 빈 값), ops — 바뀐 내용(add·update·remove·cols)  반환: 새 Layout */
function applyOps(l: Layout | undefined, ops: { add: ChartSpec[]; update: ChartSpec[]; remove: string[]; cols?: Record<string, number> }): Layout {
  const cur = l ?? EMPTY_LAYOUT;
  const addedIds = new Set(cur.added.map((c) => c.id));
  let added = [...cur.added, ...ops.add];
  const overrides = { ...cur.overrides };
  for (const u of ops.update) {
    if (addedIds.has(u.id)) added = added.map((c) => (c.id === u.id ? u : c));
    else overrides[u.id] = u;
  }
  const removed = [...cur.removed];
  for (const r of ops.remove) {
    if (addedIds.has(r)) added = added.filter((c) => c.id !== r);
    else removed.push(r);
  }
  return { ...cur, added, overrides, removed, cols: { ...cur.cols, ...(ops.cols ?? {}) } };
}

/** 메인 화면 컴포넌트. 대화·오브젝트·패널·진행 상태 같은 화면 상태를 들고, 자식 컴포넌트에 나눠 준다.
 *  입력: 없음(props 없음)  반환: 상단바·대화창·오른쪽 상세 패널을 그린 JSX */
export default function App() {
  const [meta, setMeta] = useState<Meta | null>(null);
  const [metaError, setMetaError] = useState<string | null>(null);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [msgs, setMsgs] = useState<UIMsg[]>([]);
  const [artifacts, setArtifacts] = useState<Record<string, Artifact>>({});
  const [panel, setPanel] = useState<Panel | null>(null);
  const [busy, setBusy] = useState(false);
  const convRef = useRef<string | null>(null);
  const [activeView, setActiveView] = useState<Record<string, string>>({});
  const [source, setSource] = useState<{ label: string; rows: number; unit?: string } | null>(null);
  const [activity, setActivity] = useState<Activity | null>(null);
  const [followups, setFollowups] = useState<string[]>([]);  // 후속 질문(턴이 끝난 뒤 LLM이 만든 것, 입력창 위 칩)
  const turnRef = useRef(0);
  const [demo, setDemo] = useState<DemoState | null>(null);  // 시연 시나리오 진행(다음에 보낼 단계)
  const [scen, setScen] = useState<{ items: DemoScenario[] | null; error?: string }>({ items: null });  // 메뉴를 처음 열 때 받는다
  const loadScen = () => {
    if (scen.items) return;
    setScen({ items: null });
    fetchDemo().then((r) => setScen({ items: r.scenarios })).catch((e) => setScen({ items: null, error: String(e.message || e) }));
  };
  const [srcList, setSrcList] = useState<{ items: SourceItem[]; current: string; default: string; tags: string[] } | null>(null);
  const screenRef = useRef<Record<string, any> | null>(null);
  const [panelW, setPanelW] = useState<number>(() => clampW(Number(localStorage.getItem("panelWidth")) || PANEL_DEFAULT));
  const [dragging, setDragging] = useState(false);
  useEffect(() => localStorage.setItem("panelWidth", String(panelW)), [panelW]);
  useEffect(() => {
    const onResize = () => setPanelW((w) => clampW(w));
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);
  const startDrag = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    setDragging(true);
    document.body.classList.add("resizing");
    const move = (ev: PointerEvent) => setPanelW(clampW(window.innerWidth - ev.clientX - 4));
    const up = () => {
      setDragging(false);
      document.body.classList.remove("resizing");
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  const metaToken = useRef(0);
  /** 대화의 첫 화면 정보를 받아 상태에 넣는다. 서버는 계산 없이 Unity Catalog 메타데이터로 바로 답한다. 대화가 없으면 서버가 새로 만든다.
   *  입력: cid — 대화 id(없으면 null), src — 처음 고를 테이블(선택)  반환: 없음(상태 갱신) */
  const loadMeta = useCallback((cid: string | null, src?: string | null) => {
    const token = ++metaToken.current;
    fetchMeta(cid, src)
      .then((m) => {
        if (token !== metaToken.current) return;
        if (m.conversation_id && !convRef.current) {
          convRef.current = m.conversation_id;
          setConversationId(m.conversation_id);
        }
        setMeta(m);
        setMetaError(m.error ?? null);
      })
      .catch((e) => token === metaToken.current && setMetaError(String(e.message || e)));
  }, []);
  useEffect(() => loadMeta(null), [loadMeta]);

  const push = useCallback((m: UIMsg) => setMsgs((prev) => [...prev, m]), []);
  const openArtifact = (id: string) => setPanel({ kind: "artifact", id });

  /** 오브젝트: 대화에 카드를 넣고 내용은 패널용으로 보관(누를 때 연다). */
  const addObject = useCallback((a: Artifact, title: string, detail: string) => {
    setArtifacts((prev) => ({ ...prev, [a.id]: a }));
    push({ id: uid(), role: "object", artifactId: a.id, kind: a.kind, title, detail });
  }, [push]);

  const findResult = (prev: Record<string, Artifact>, target: string) =>
    Object.values(prev).find((x) => x.kind === "result" && (x.data.run_id === target || x.data.views.some((v) => v.run_id === target)));

  /** 서버 스트림 이벤트 하나를 화면 상태에 반영한다. type별로 진행 표시, 답 글, 제안 카드, 결과, 차트 변경, 오류, 완료를 처리한다.
   *  입력: ev — 서버 이벤트(type으로 구분)  반환: 없음(상태 갱신) */
  const onEvent = useCallback(
    (ev: ServerEvent) => {
      const now = Date.now();
      const act = (patch: Partial<Activity>) => setActivity((a) => (a ? { ...a, ...patch } : a));
      setActivity((a) => (a ? { ...a, lastServer: now, ...(ev.type === "alive" && ev.from === "server" ? {} : { lastProgress: now }) } : a));
      switch (ev.type) {
        case "activity":
          act({ text: ev.text, detail: undefined, tool: false });
          break;
        case "conversation":
          convRef.current = ev.conversation_id;
          setConversationId(ev.conversation_id);
          break;
        case "assistant_start":
          push({ id: uid(), role: "assistant", text: "", streaming: true });
          break;
        case "text":
          setActivity((a) => (a && !a.text.includes("해석") ? { ...a, text: "답변을 쓰는 중", detail: undefined } : a));
          setMsgs((prev) => {
            const next = [...prev];
            for (let i = next.length - 1; i >= 0; i--) {
              const m = next[i];
              if (m.role === "assistant") {
                next[i] = { ...m, text: m.text + ev.text };
                break;
              }
            }
            return next;
          });
          break;
        case "skill":
          push({ id: uid(), role: "skill", title: ev.title });
          break;
        case "source":  // 질문에 맞게 LLM이 테이블을 골랐다(또는 바꿨다): 대화에 한 줄, 데이터 패널·첫 화면 정보는 그 테이블로
          push({ id: uid(), role: "source", label: ev.label, rows: ev.rows, unit: ev.unit });
          setSource({ label: String(ev.key || ev.label).split(/[./]/).pop() || ev.label, rows: ev.rows, unit: ev.unit });
          setSrcList((l) => (l && ev.key ? { ...l, current: ev.key } : l));
          if (convRef.current) loadMeta(convRef.current);
          break;
        case "tool_start":
          act({ text: ev.label, detail: undefined, tool: !ev.silent });
          if (!ev.silent) push({ id: uid(), role: "tool", name: ev.name, label: ev.label, status: "running" });
          break;
        case "tool_progress":
          act({ detail: ev.text });
          setMsgs((prev) => {
            const next = [...prev];
            for (let i = next.length - 1; i >= 0; i--) {
              const m = next[i];
              if (m.role === "tool" && m.status === "running") {
                next[i] = { ...m, progress: ev.text };
                break;
              }
            }
            return next;
          });
          break;
        case "pdf_capture":
          act({ text: "결과 차트를 PDF에 담는 중", detail: undefined, tool: true });
          pdfRef.current?.(ev.run_id);
          break;
        case "tool_end":
          if (ev.silent) break;
          act({ text: ev.ok ? "결과를 정리하는 중" : "오류를 확인하는 중", detail: undefined, tool: false });
          setMsgs((prev) => {
            const next = [...prev];
            for (let i = next.length - 1; i >= 0; i--) {
              const m = next[i];
              if (m.role === "tool" && m.name === ev.name && m.status === "running") {
                next[i] = { ...m, status: ev.ok ? "done" : "error", ms: ev.ms, error: ev.error };
                break;
              }
            }
            return next;
          });
          break;
        case "proposal": {
          const d = ev.data;
          const id = uid();
          setArtifacts((prev) => ({ ...prev, [id]: { id, kind: "settings", data: d.settings, skill: d.skill } }));
          push({ id: uid(), role: "proposal", artifactId: id, lines: d.lines, skill: d.skill, skillTitle: d.skill_title, runTool: d.run_tool, cfg: d.cfg, footer: d.footer });
          break;
        }
        case "result": {
          const d: AnalysisResult = ev.data;
          addObject({ id: uid(), kind: "result", data: d, layouts: {} }, d.title, d.badge ?? d.subtitle);
          break;
        }
        case "work": {
          const d = ev.data;
          addObject({ id: d.id, kind: "work", data: d }, d.title, `${d.subtitle} · 채운 결측 ${d.n_filled.toLocaleString()}칸`);
          break;
        }
        case "lookup": {
          const d = ev.data;
          addObject({ id: d.id, kind: "lookup", data: d }, d.title, `${d.n_rows.toLocaleString()}행 · 원본 데이터 기준`);
          break;
        }
        case "charts":  // 대화로 차트를 고치면 그 결과를 패널에 열어 바뀐 모습을 보여준다
          setArtifacts((prev) => {
            const hit = findResult(prev, ev.target);
            if (!hit || hit.kind !== "result") return prev;
            setPanel({ kind: "artifact", id: hit.id });
            const layouts = { ...(hit.layouts ?? {}), [ev.view]: applyOps(hit.layouts?.[ev.view], ev.ops) };
            return { ...prev, [hit.id]: { ...hit, layouts } };
          });
          break;
        case "section":  // 대화로 결과 아래에 표·차트 묶음을 덧붙였다(add_section): 그 보기에 이어 붙이고 패널에 연다
          setArtifacts((prev) => {
            const hit = findResult(prev, ev.target);
            if (!hit || hit.kind !== "result") return prev;
            setPanel({ kind: "artifact", id: hit.id });
            const views = hit.data.views.map((v) => {
              if (v.id !== ev.view || (v.chart_groups ?? []).some((g) => g.id === ev.group.id)) return v;
              const base = v.chart_groups?.length || !v.charts.length ? v.chart_groups ?? [] : [{ id: "main", title: "차트", cols: 2 }];
              const charts = v.chart_groups?.length ? v.charts : v.charts.map((c) => ({ ...c, group: c.group ?? "main" }));
              return { ...v, chart_groups: [...base, ev.group], charts: [...charts, ...ev.charts] };
            });
            return { ...prev, [hit.id]: { ...hit, data: { ...hit.data, views } } };
          });
          setTimeout(() => document.getElementById(`grp-${ev.group.id}`)?.scrollIntoView({ behavior: "smooth", block: "start" }), 400);  // 덧붙인 곳으로
          break;
        case "file":
          push({ id: uid(), role: "file", name: ev.name, url: ev.url });
          break;
        case "error":
          push({ id: uid(), role: "notice", level: "error", text: ev.message });
          break;
        case "done":  // 답은 끝났다(후속 질문은 뒤따라 온다) — 입력창을 바로 푼다
          setMsgs((prev) => prev.map((m) => (m.role === "assistant" && m.streaming ? { ...m, streaming: false } : m)));
          setBusy(false);
          setActivity(null);
          break;
        case "followups":
          setFollowups(ev.items ?? []);
          break;
        default:
          break;
      }
    },
    [push, addObject, loadMeta],
  );

  const finishStreaming = () =>
    setMsgs((prev) => prev.map((m) => (m.role === "assistant" && m.streaming ? { ...m, streaming: false } : m)));

  /** 대화 한 턴을 보낸다. 상태 표시를 켜고, 서버 스트림을 onEvent로 받으며, 끝나면 입력을 다시 연다.
   *  입력: body — 메시지 또는 action·label, echo — 대화창에 먼저 보일 글(선택)  반환: 스트림이 끝나면 완료 Promise */
  const send = useCallback(
    async (body: { message?: string; action?: Record<string, any>; label?: string }, echo?: { text: string; system?: boolean }) => {
      if (busy) return;
      if (echo) push({ id: uid(), role: "user", text: echo.text, system: echo.system });
      setBusy(true);
      setFollowups([]);
      const turn = ++turnRef.current;
      const t = Date.now();
      setActivity({ text: "요청을 보내는 중", startedAt: t, lastProgress: t, lastServer: t });
      try {
        await streamChat({ conversation_id: convRef.current, ...body, screen: screenRef.current },
          (ev) => (ev.type === "followups" && turn !== turnRef.current ? undefined : onEvent(ev)));  // 앞 턴의 늦은 후속 질문은 버린다
      } catch (e: any) {
        push({ id: uid(), role: "notice", level: "error", text: e?.message || String(e) });
      } finally {
        if (turn === turnRef.current) {
          finishStreaming();
          setBusy(false);
          setActivity(null);
        }
      }
    },
    [busy, onEvent, push],
  );

  const sendText = (text: string) => send({ message: text }, { text });
  const runAction = (tool: string, cfg: Cfg, label: string, base?: Cfg) =>
    send({ action: { type: "run", tool, cfg, ...(base ? { base } : {}) }, label }, { text: label, system: true });

  const runProposal = (msgId: string) => {
    const m = msgs.find((x) => x.id === msgId);
    if (!m || m.role !== "proposal") return;
    setMsgs((prev) => prev.map((x) => (x.id === msgId && x.role === "proposal" ? { ...x, decided: "run" } : x)));
    runAction(m.runTool, m.cfg, "제안대로 실행");
  };

  /** 결과의 [설정 수정]: 그 결과의 설정으로 분석 설정 패널을 연다(대화에는 남기지 않고, 돌아가기로 결과로). */
  const openSettingsFor = async (cfg: Cfg, skill: string, from: string) => {
    try {
      const d = await fetchSettings(convRef.current, skill, cfg, true);
      const id = uid();
      setArtifacts((prev) => ({ ...prev, [id]: { id, kind: "settings", data: d, skill, from } }));
      setPanel({ kind: "artifact", id });
    } catch (e: any) {
      push({ id: uid(), role: "notice", level: "error", text: e?.message || String(e) });
    }
  };

  /** 결과를 PDF 리포트로 만든다. 결과 패널을 열어 화면의 차트를 이미지로 담은 뒤 서버에 보낸다.
   *  입력: runId — 결과 실행 id  반환: 없음(완료 시 파일 메시지, 실패 시 도구 오류 표시) */
  const savePdf = async (runId: string) => {
    if (!convRef.current) return;
    push({ id: uid(), role: "tool", name: "save_pdf", label: "PDF 리포트 만들기", status: "running" });
    const t0 = performance.now();
    const own = !busyRef.current;  // 대화 턴 밖에서 누른 PDF 버튼이면 여기서 상태 표시를 연다
    if (own) setActivity({ text: "PDF 리포트 만들기", tool: true, startedAt: Date.now(), lastProgress: Date.now(), lastServer: Date.now() });
    try {
      // 그 결과를 패널에 연 뒤, 보이는 차트를 그대로 이미지로 담는다
      const art = Object.values(artifactsRef.current).find((x) => x.kind === "result" && (x.data.run_id === runId || x.data.views.some((v) => v.run_id === runId)));
      let images: { title: string; data_url: string }[] = [];
      if (art) {
        const p = panelRef.current;
        if (!(p?.kind === "artifact" && p.id === art.id)) {
          setPanel({ kind: "artifact", id: art.id });
          await new Promise((r) => setTimeout(r, 2200));
        }
        onEvent({ type: "tool_progress", text: "결과 차트 담는 중" });
        images = panelElRef.current ? await captureCharts(panelElRef.current) : [];
      }
      onEvent({ type: "tool_progress", text: `PDF 만드는 중 (화면 차트 ${images.length}개)` });
      const r = await makePdf(convRef.current, runId, images);
      onEvent({ type: "tool_end", name: "save_pdf", ok: true, ms: Math.round(performance.now() - t0) });
      push({ id: uid(), role: "file", name: r.name, url: r.url });
    } catch (e: any) {
      onEvent({ type: "tool_end", name: "save_pdf", ok: false, ms: 0, error: e?.message });
    } finally {
      if (own) setActivity(null);
    }
  };

  const loadSources = useCallback(async () => {
    try {
      setSrcList(await fetchSources(convRef.current));
    } catch {
      /* 목록은 다음에 열 때 다시 */
    }
  }, []);
  useEffect(() => {
    if (meta && !srcList) loadSources();
  }, [meta, srcList, loadSources]);

  /** 데이터 패널에서 고름: LLM 없이 바로 이 대화의 소스를 바꾸고, 안내·예시를 그 데이터 값으로 다시 받는다. */
  const selectSource = async (name: string, announce = true) => {
    if (busyRef.current) return;
    setBusy(true);
    const t = Date.now();
    setActivity({ text: "테이블을 바꾸는 중", startedAt: t, lastProgress: t, lastServer: t });
    try {
      const r = await pickSource(convRef.current, name);
      convRef.current = r.conversation_id;
      setConversationId(r.conversation_id);
      setMeta((m) => ({ ...(m ?? ({} as Meta)), ...r.meta }));
      if (r.event) {
        setSource({ label: r.event.key.split(/[./]/).pop() || r.event.label, rows: r.event.rows, unit: r.event.unit });
        if (announce) push({ id: uid(), role: "source", label: r.event.label, rows: r.event.rows, unit: r.event.unit });
      }
      setSrcList((l) => (l ? { ...l, current: name } : l));
    } catch (e: any) {
      push({ id: uid(), role: "notice", level: "error", text: e?.message || String(e) });
    } finally {
      setBusy(false);
      setActivity(null);
    }
  };

  /** 새 대화: 테이블은 다시 질문에 맞게 고른다. */
  const newSession = () => {
    if (busy) return;
    convRef.current = null;
    setConversationId(null);
    setMsgs([]);
    setArtifacts({});
    setPanel(null);
    setSource(null);
    setMeta(null);
    setFollowups([]);
    loadMeta(null);
  };


  /** 시연 시나리오: 처음부터면 새 대화로 열고(대화가 비어 있지 않을 때), 단계를 고르면 지금 대화에서 그 단계부터. */
  const startDemo = (id: string, step: number) => {
    if (busy) return;
    if (step === 0 && msgs.length) newSession();
    setDemo({ id, i: step });
  };
  const demoSend = () => {
    const st = demo && scen.items?.find((s) => s.id === demo.id)?.steps[demo.i];
    if (!demo || !st || busy) return;
    setDemo({ ...demo, i: demo.i + 1 });
    sendText(st.ask);
  };

  const panelElRef = useRef<HTMLElement>(null);
  const busyRef = useRef(busy);
  busyRef.current = busy;
  const artifactsRef = useRef(artifacts);
  artifactsRef.current = artifacts;
  const panelRef = useRef(panel);
  panelRef.current = panel;
  const pdfRef = useRef<((runId: string) => void) | null>(null);
  pdfRef.current = savePdf;
  useEffect(() => {
    panelElRef.current?.scrollTo({ top: 0 });
  }, [panel]);

  const chosen = !!source || !!meta?.chosen;  // 이 대화의 테이블이 정해졌는지(질문으로 LLM이 골랐거나 데이터 패널에서 골랐거나)
  setUnit(meta?.unit);  // 화면 문구의 행 단위 = 고른 테이블의 단위(식별자 이름에서)
  const art = panel?.kind === "artifact" ? artifacts[panel.id] : null;
  // 지금 패널에서 보고 있는 결과·보기·차트 배치를 다음 요청과 함께 보낸다 (대화로 차트를 고칠 때 기준)
  if (art?.kind === "result") {
    const vid = activeView[art.id] ?? art.data.views[0]?.id;
    screenRef.current = { ui: true, run_id: art.data.run_id, view_id: vid, layout: art.layouts?.[vid] ?? null };
  } else {
    screenRef.current = { ui: true };
  }

  return (
    <div className="shell">
      <header className="topbar">
        <div className="brand">
          <span className="mark" aria-hidden><i /> <i /> <i /></span>
          <span className="brand-name">공정 데이터 분석</span>
          <DemoMenu scenarios={scen.items} error={scen.error} state={demo} busy={busy} onOpen={loadScen} onStart={startDemo} />
        </div>
        <button className="dataset" title="데이터 패널 열기(등록 테이블·기초 통계, 직접 고르기)" disabled={!meta}
          onClick={() => { setPanel({ kind: "data" }); loadSources(); }}>
          {metaError && !meta?.source ? (
            <span className="dataset-sub warn">{metaError}</span>
          ) : !meta ? (
            <span className="dataset-sub">데이터 정보를 불러오는 중</span>
          ) : chosen ? (
            <>
              <span className="dataset-name">데이터: {source?.label ?? String(meta.source ?? "").split(".").pop()}</span>
              <span className="dataset-sub">{meta.title}{(source?.rows ?? meta.rows) ? ` · ${(source?.rows ?? meta.rows)!.toLocaleString()}${source?.unit || meta.unit || "행"}` : ""}</span>
            </>
          ) : (
            <>
              <span className="dataset-name">데이터: 질문에 맞게 자동 선택</span>
              <span className="dataset-sub">등록 테이블 {(meta.sources ?? []).length || "-"}개</span>
            </>
          )}
        </button>
        <div className="topbar-actions">
          <button className="ghost" onClick={newSession} disabled={busy}>새 분석</button>
        </div>
      </header>
      <main className={`workspace ${panel ? "panel-open" : ""}`} style={{ ["--panel-w" as any]: `${panelW}px` }}>
        <ChatPane
          msgs={msgs}
          artifacts={artifacts}
          busy={busy}
          meta={meta}
          activity={activity}
          openId={panel?.kind === "artifact" ? panel.id : null}
          onSend={sendText}
          onRunProposal={runProposal}
          onOpen={openArtifact}
          onOpenData={() => { setPanel({ kind: "data" }); loadSources(); }}
          followups={followups}
          demoBar={demo && (
            <DemoBar scenarios={scen.items ?? []} state={demo} busy={busy} ready={!!meta}
              onSend={demoSend} onSkip={() => setDemo({ ...demo, i: demo.i + 1 })} onNext={(id) => startDemo(id, 0)} onEnd={() => setDemo(null)} />
          )}
        />
        {panel && (
          <>
            <div
              className={`resizer ${dragging ? "dragging" : ""}`}
              role="separator"
              aria-orientation="vertical"
              aria-label="패널 크기 조절"
              aria-valuenow={panelW}
              aria-valuemin={PANEL_MIN}
              aria-valuemax={panelMax()}
              tabIndex={0}
              title="끌어서 크기 조절, 두 번 누르면 기본 크기"
              onPointerDown={startDrag}
              onDoubleClick={() => setPanelW(PANEL_DEFAULT)}
              onKeyDown={(e) => {
                if (e.key === "ArrowLeft") { e.preventDefault(); setPanelW((w) => clampW(w + 32)); }
                if (e.key === "ArrowRight") { e.preventDefault(); setPanelW((w) => clampW(w - 32)); }
              }}
            />
            <aside className="panel" aria-label="상세 패널" ref={panelElRef}>
              <div className="panel-top">  {/* 한 줄: 왼쪽 진행 상태(작업 중일 때) · 오른쪽 닫기 — 스크롤해도 내용 위를 덮지 않는다 */}
                {activity && (art || panel.kind === "data") && <ActivityBar a={activity} variant="bench" />}
                <button type="button" className="panel-close" aria-label="패널 닫기" onClick={() => setPanel(null)}>닫기 ✕</button>
              </div>
              {panel.kind === "data" && (
                <DataPanel meta={meta} sources={srcList} chosen={chosen} busy={busy} onPickSource={(n) => selectSource(n, msgs.length > 0)} />
              )}
              {art?.kind === "settings" && (
                <SettingsPanel key={art.id} data={art.data} conversationId={conversationId} busy={busy}
                  onRun={(cfg, tool) => runAction(tool, cfg, art.data.from_result ? "설정을 바꿔 다시 실행" : "이 설정으로 실행", art.data.cfg)}
                  onBack={art.from ? () => openArtifact(art.from!) : undefined} />
              )}
              {art?.kind === "result" && (
                <Readout
                  key={art.id}
                  data={art.data}
                  layouts={art.layouts}
                  onLayout={(viewId, l) =>
                    setArtifacts((prev) => {
                      const a = prev[art.id];
                      return a?.kind === "result" ? { ...prev, [a.id]: { ...a, layouts: { ...(a.layouts ?? {}), [viewId]: l } } } : prev;
                    })
                  }
                  busy={busy}
                  onPdf={savePdf}
                  onSettings={art.data.settings ? () => openSettingsFor(art.data.cfg, art.data.skill, art.id) : undefined}
                  onAsk={sendText}
                  onView={(vid) => setActiveView((prev) => (prev[art.id] === vid ? prev : { ...prev, [art.id]: vid }))}
                />
              )}
              {art?.kind === "lookup" && <LookupPanel key={art.id} data={art.data} />}
              {art?.kind === "work" && <WorkPanel key={art.id} data={art.data} />}
            </aside>
          </>
        )}
      </main>
    </div>
  );
}
