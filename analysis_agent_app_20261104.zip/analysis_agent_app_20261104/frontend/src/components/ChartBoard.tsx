/**
 * 차트 보드: skill이 준 기본 배치 위에 사용자 편집을 얹어 보여주는 차트 영역.
 * 용도: 그룹별 격자에 차트 카드를 그린다. 카드마다 크게 보기·삭제(기본 차트는 숨기기)를 하고, 추가한 차트는 순서를 바꾼다. 그룹 열 수 변경과 점 눌러 설명 요청도 처리한다.
 * 목적: 기본 차트 정의(view)는 건드리지 않고, 편집 상태(Layout)만 부모에서 받아 저장해 같은 결과를 다시 열어도 편집이 남게 함.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { unit } from "../data";
import type { ChartGroup, ChartSpec, Dataset, Layout, View } from "../types";
import PlotChart from "./PlotChart";
import { Sections } from "./Sections";

interface Props {
  view: View;
  datasets: Record<string, Dataset>;
  layout?: Layout;
  onLayout: (l: Layout) => void;
  targetLabel?: string | null;
  busy?: boolean;
  onExplain?: (rowId: string, metricLabel: string) => void;
}

const EMPTY: Layout = { removed: [], overrides: {}, added: [], cols: {} };
const HEIGHT: Record<number, number> = { 1: 340, 2: 280, 3: 230 };





/** 기본 차트에 사용자 편집을 적용한 최종 차트 목록을 만든다. 숨긴 차트는 빼고, 재정의(overrides)는 덮어쓰고, 추가한 차트(added)는 뒤에 붙인다.
 *  입력: view — 결과 뷰, l — 사용자 편집 상태(Layout)  반환: 화면에 그릴 ChartSpec 배열 */
export function applyLayout(view: View, l: Layout): ChartSpec[] {
  return [
    ...view.charts.filter((c) => !l.removed.includes(c.id)).map((c) => ({ ...c, ...(l.overrides[c.id] ?? {}) })),
    ...l.added,
  ];
}

/** 차트 보드 본체. 그룹(chart_groups)별 격자에 차트 카드를 그리고, 크게 보기 창과 점 선택 막대를 관리한다.
 *  입력: view — 결과 뷰, datasets — 데이터셋 맵, layout — 사용자 편집 상태(없으면 빈 편집), onLayout — 편집 상태 저장 콜백, targetLabel — 설명 대상 지표 이름, busy — 처리 중 여부, onExplain — 점을 눌렀을 때 (행 id, 지표 이름)을 받는 콜백  반환: 차트 보드 section JSX */
export default function ChartBoard({ view, datasets, layout, onLayout, targetLabel, busy, onExplain }: Props) {
  const l = layout ?? EMPTY;
  const charts = useMemo(() => applyLayout(view, l), [view, l]);
  const [zoom, setZoom] = useState<ChartSpec | null>(null);
  const [picked, setPicked] = useState<{ chart: string; id: string; metric: string; value?: string } | null>(null);
  const fieldLabel = (ds: string, key?: string) => datasets[ds]?.fields.find((f) => f.key === key)?.label ?? key ?? "";
  const zoomRef = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const d = zoomRef.current;
    if (!d) return;
    if (zoom && !d.open) d.showModal();
    if (!zoom && d.open) d.close();
  }, [zoom]);

  const groups: ChartGroup[] = [...(view.chart_groups ?? [{ id: "main", title: "차트", cols: 2 }])];
  if (charts.some((c) => c.group === "user")) groups.push({ id: "user", title: "추가한 차트", cols: 2 });
  const known = new Set(groups.map((g) => g.id));
  const inGroup = (g: ChartGroup, i: number) => charts.filter((c) => (known.has(c.group ?? "") ? c.group === g.id : i === 0));

  const set = (patch: Partial<Layout>) => onLayout({ ...l, ...patch });
  const remove = (id: string) =>
    l.added.some((c) => c.id === id) ? set({ added: l.added.filter((c) => c.id !== id) }) : set({ removed: [...l.removed, id] });
  const move = (id: string, dir: -1 | 1) => {
    const i = l.added.findIndex((c) => c.id === id);
    if (i < 0) return;
    const a = [...l.added];
    const j = Math.max(0, Math.min(a.length - 1, i + dir));
    [a[i], a[j]] = [a[j], a[i]];
    set({ added: a });
  };

  return (
    <section className="board" aria-label="차트">
      {groups.map((g, gi) => {
        const list = inGroup(g, gi);
        if (!list.length && !g.sections?.length) return null;
        const cols = l.cols[g.id] ?? g.cols;
        return (
          <div key={g.id} id={`grp-${g.id}`} className="board-group">
            <div className="group-head">
              <div>
                <strong>{g.title}</strong>
                {g.note && <span>{g.note}</span>}
              </div>
            </div>
            {!!g.sections?.length && <Sections items={g.sections} />}
            {list.length > 0 && <div className="board-grid" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}>
              {list.map((c) => {
                const span = Math.min(cols, c.span ?? 1);
                const tall = c.type === "beeswarm" || c.type === "corr" || (c.horizontal && cols === 1);
                return (
                  <figure key={c.id} className={`plot-card ${c.tone ? "t-" + c.tone : ""}`} style={{ gridColumn: `span ${span}` }}>
                    <figcaption>
                      <strong title={c.title}>{c.title}</strong>
                      <span className="plot-tools">
                        {c.group === "user" && <button className="icon" onClick={() => move(c.id, -1)} aria-label="앞으로">‹</button>}
                        {c.group === "user" && <button className="icon" onClick={() => move(c.id, 1)} aria-label="뒤로">›</button>}
                        <button className="icon" onClick={() => setZoom(c)} aria-label={`${c.title} 크게 보기`}>크게</button>
                        <button className="icon" onClick={() => remove(c.id)} aria-label={`${c.title} 삭제`}>×</button>
                      </span>
                    </figcaption>
                    {picked?.chart === c.id && (
                      <div className="pick-bar" role="status">
                        <span>선택한 {unit()} <b>{picked.id}</b>{picked.value ? ` · ${picked.metric} ${picked.value}` : ""}</span>
                        <span>
                          <button className="primary" disabled={busy || !onExplain} onClick={() => { onExplain?.(picked.id, picked.metric); setPicked(null); }}>
                            이 {unit()} 설명
                          </button>
                          <button className="link" onClick={() => setPicked(null)}>닫기</button>
                        </span>
                      </div>
                    )}
                    <PlotChart spec={c} dataset={datasets[c.dataset]} height={tall ? Math.max(HEIGHT[cols], 300) : HEIGHT[cols]}
                      onPick={onExplain && datasets[c.dataset]?.id_field ? (p) => {
                        const metric = targetLabel ?? fieldLabel(c.dataset, c.y);  // 결과의 지표를 설명한다
                        const yv = c.y === undefined ? p.y : undefined;
                        setPicked({ chart: c.id, id: p.id, metric, value: typeof yv === "number" ? yv.toPrecision(4) : undefined });
                      } : undefined} />
                  </figure>
                );
              })}
            </div>}
          </div>
        );
      })}
      {l.removed.length > 0 && (
        <p className="board-removed">
          숨긴 기본 차트 {l.removed.length}개 <button className="link" onClick={() => set({ removed: [] })}>다시 보이기</button>
        </p>
      )}
      <dialog ref={zoomRef} className="zoom plot-zoom" onClose={() => setZoom(null)}>
        {zoom && (
          <div className="zoom-body">
            <header><strong>{zoom.title}</strong><button className="link" onClick={() => setZoom(null)}>닫기</button></header>
            <PlotChart spec={zoom} dataset={datasets[zoom.dataset]} height={Math.min(640, window.innerHeight - 140)} />
          </div>
        )}
      </dialog>
    </section>
  );
}
