/**
 * 결과 패널: 분석 결과를 공통 형식으로 그린다. skill이 무엇이든 같은 구조다.
 * 용도: 머리말 · 적용된 설정 · 지표 · 알림 · 보기 탭(표 + 차트 보드) · 처리 기록 · 경고 · PDF 저장 버튼 순서로 보여준다.
 * 목적: 해석은 대화에 쓰고, 이 패널은 근거 자료를 보여주는 곳으로 둠.
 */
import { useEffect, useState } from "react";
import { unit } from "../data";
import type { AnalysisResult, Layout } from "../types";
import { Metrics, Sections } from "./Sections";
import ChartBoard from "./ChartBoard";

interface Props {
  data: AnalysisResult;
  layouts?: Record<string, Layout>;
  onLayout: (viewId: string, l: Layout) => void;
  busy: boolean;
  onPdf: (runId: string) => void;
  onSettings?: () => void;
  onAsk: (text: string) => void;
  onView?: (viewId: string) => void;
}

/** 결과 패널 본체.
 *  입력: data — 분석 결과(공통 형식), layouts — 뷰별 차트 편집 상태, onLayout — (뷰 id, 편집) 저장 콜백, busy — 처리 중 여부, onPdf — PDF 저장(run id), onSettings — 설정 수정 열기(없으면 버튼 없음), onAsk — 대화로 질문 보내기, onView — 보고 있는 뷰 id 알림  반환: 결과 패널 JSX */
export default function Readout({ data, layouts, onLayout, busy, onPdf, onSettings, onAsk, onView }: Props) {
  const canEdit = data.settings && !!onSettings;
  const pickDefault = () => {
    // 반복 분석은 마지막 회차를 먼저 보여준다
    if (data.kind === "run" && data.views.length > 1 && data.views[0].id !== "summary") return data.views.length - 1;
    return 0;
  };
  const [vi, setVi] = useState(pickDefault);
  useEffect(() => setVi(pickDefault()), [data.run_id]); // eslint-disable-line react-hooks/exhaustive-deps
  const view = data.views[Math.min(vi, data.views.length - 1)];
  useEffect(() => onView?.(view.id), [view.id]); // eslint-disable-line react-hooks/exhaustive-deps
  const pdfRun = view.run_id ?? (data.pdf ? data.run_id : null);

  return (
    <div className="readout">
      <div className="readout-head">
        <span className="skill-tag">{data.tag ?? data.skill_title ?? data.skill}</span>
        <h2>{data.title}</h2>
        {!data.applied?.length && <p>{data.subtitle}</p>}
      </div>

      {(data.applied?.length ?? 0) > 0 && (
        <section className="applied" aria-label="적용된 설정">
          <div className="applied-head">
            <h3>적용된 설정</h3>
            {canEdit && <button className="secondary" disabled={busy} onClick={onSettings}>설정 수정</button>}
          </div>
          <dl>
            {data.applied!.map((a) => (
              <div key={a.label}><dt>{a.label}</dt><dd>{a.value}</dd></div>
            ))}
          </dl>
        </section>
      )}

      <Metrics items={[...data.metrics, ...view.metrics]} />

      {data.callouts.map((c, i) => (
        <div key={i} className={`callout t-${c.tone}`} role="note">
          <p>{c.text}</p>
          {c.action && <button className="secondary" disabled={busy} onClick={() => onAsk(c.action!.message)}>{c.action.label}</button>}
        </div>
      ))}

      <Sections items={data.sections} />

      {data.views.length > 1 && (
        <div className="rounds" role="tablist" aria-label="보기">
          {data.views.map((v, i) => (
            <button key={v.id} role="tab" aria-selected={i === vi} className={i === vi ? "on" : ""} onClick={() => setVi(i)}>
              {v.label}{v.sub && <small>{v.sub}</small>}
            </button>
          ))}
        </div>
      )}

      <Sections items={view.sections} />

      {view.charts.length > 0 || (layouts?.[view.id]?.added.length ?? 0) > 0 ? (
        <ChartBoard key={`${data.run_id}-${view.id}`} view={view} datasets={data.datasets}
          layout={layouts?.[view.id]} onLayout={(l) => onLayout(view.id, l)} targetLabel={data.target_label} busy={busy}
          onExplain={(id, metric) => onAsk(`${id} ${unit()}의 ${metric || "지표"} 값이 왜 이렇게 나왔는지 설명해줘`)} />
      ) : null}

      {data.log.length > 0 && (
        <details className="prep-log">
          <summary>처리 기록 {data.log.length}건</summary>
          <ul>{data.log.map((e, i) => <li key={i}><strong>{e.label}</strong> {e.detail}</li>)}</ul>
        </details>
      )}
      {data.warnings.length > 0 && <ul className="warnings">{data.warnings.map((w) => <li key={w}>{w}</li>)}</ul>}

      <div className="readout-actions">
        {pdfRun && <button className="primary" disabled={busy} onClick={() => onPdf(pdfRun)}>PDF 리포트 저장</button>}
      </div>
    </div>
  );
}
