/**
 * 조회 결과 패널: Genie Agent로 실행한 원본 조회 결과를 표로 보여준다.
 * 용도: 제목·설명, 결과 행 수, 결과 표(최대 200행), 실행한 SQL(접힌 상자)을 그린다. 셀 표기는 fmtCell로 맞춘다.
 * 목적: 분석 근거가 되는 원본 데이터와 SQL을 사용자가 직접 확인할 수 있게 함.
 */
import type { Lookup } from "../types";

/** 조회 결과 패널: 실행한 SQL과 결과 표 전체(최대 200행). 조회는 Genie Agent가 한다(화면에는 이름을 드러내지 않는다).
 *  입력: data — 조회 결과(제목·설명·SQL·열·행·전체 행 수)  반환: 조회 패널 JSX */
export default function LookupPanel({ data }: { data: Lookup }) {
  return (
    <div className="lookup-panel">
      <div className="sp-head">
        <h2>{data.title}</h2>
        <p>원본 데이터 기준 · 결과 {data.n_rows.toLocaleString()}행{data.n_rows > data.rows.length ? ` (앞 ${data.rows.length}행 표시)` : ""}</p>
        {data.description && <p className="lk-desc">{data.description}</p>}
      </div>
      <div className="stats-table">
        <table>
          <thead><tr>{data.columns.map((c) => <th key={c}>{c}</th>)}</tr></thead>
          <tbody>
            {data.rows.map((r, i) => <tr key={i}>{r.map((v, j) => <td key={j} className={typeof v === "number" || /^-?\d+(\.\d+)?$/.test(String(v ?? "")) ? "num" : ""}>{fmtCell(v)}</td>)}</tr>)}
          </tbody>
        </table>
      </div>
      {data.sql && (
        <details className="sql-box">
          <summary>실행한 SQL</summary>
          <pre>{data.sql}</pre>
        </details>
      )}
    </div>
  );
}

/** 긴 소수는 4자리 유효숫자, 시각 표기의 0시는 날짜만. */
export function fmtCell(v: string | number | null): string {
  if (v === null || v === undefined) return "-";
  const s = String(v);
  if (/^-?\d+\.\d{5,}$/.test(s)) return Number(Number(s).toPrecision(4)).toLocaleString();
  if (/^\d{4}-\d{2}-\d{2}T00:00:00(\.000)?Z?$/.test(s)) return s.slice(0, 10);
  return s;
}
