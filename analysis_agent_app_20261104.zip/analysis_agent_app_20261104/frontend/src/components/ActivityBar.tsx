/**
 * 진행 막대: 분석 한 턴이 도는 동안 지금 하는 일과 경과 시간을 한 줄로 보여준다.
 * 용도: 대화창(chat)과 벤치(bench) 두 곳에서 variant로 모양만 바꿔 쓴다. 서버 이벤트로 갱신되는 Activity 상태를 받아 그린다.
 * 목적: 응답이 늦어도 멈춘 것이 아니라 진행 중이라는 신호를 계속 보여주기 위함.
 */
import { useEffect, useState } from "react";

/** 한 턴이 진행되는 동안의 작업 상태. 서버 이벤트로 갱신한다(App.onEvent). */
export interface Activity {
  text: string;          // 지금 하는 일 (서버 activity·도구 이름)
  detail?: string;       // 도구의 실제 처리 단계 (tool_progress)
  tool?: boolean;        // 분석 도구가 계산 중인지
  startedAt: number;     // 요청을 보낸 시각
  lastProgress: number;  // 마지막 진행 신호(이벤트·LLM 응답 수신)
  lastServer: number;    // 마지막 서버 신호(연결 확인 포함, 4초마다)
}

/** 진행 막대. 0.5초마다 경과 시간을 다시 센다.
 *  입력: a — 진행 상태(시작 시각·현재 작업 문구·도구 진행 단계), variant — 모양("chat" 대화창 / "bench" 벤치 트랙 포함)  반환: 진행 막대 JSX */
export default function ActivityBar({ a, variant }: { a: Activity; variant: "chat" | "bench" }) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const h = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(h);
  }, []);
  const total = Math.max(0, (now - a.startedAt) / 1000);

  return (
    <div className={`activity ${variant}`}>
      {variant === "bench" && <span className="act-track" aria-hidden><i /></span>}
      <span className="act-spin" aria-hidden />
      <span className="act-text" role="status">
        {a.text}{a.detail ? <small> · {a.detail}</small> : null}
      </span>
      <span className="act-time" title="요청 후 지난 시간">{total.toFixed(0)}초</span>
    </div>
  );
}
