/**
 * 마크다운 렌더러: 답변 텍스트를 마크다운으로 그린다.
 * 용도: GFM 문법(표 등)을 쓰되 단일 물결(~) 취소선은 끈다. 한글 문장 안의 굵게(**…**)가 깨지는 문제를 고치는 플러그인을 붙인다.
 * 목적: LLM 답변을 읽기 좋은 서식으로 보여주기 위함.
 */
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

/** CommonMark 규칙상 닫는 `**` 앞이 문장부호이고 뒤에 한글이 바로 붙으면("**DO 최저(%)**이고") 굵게가 안 되고 별표가 그대로 남는다.
 *  파싱 뒤 글자 노드에 남은 `**…**`를 굵게(strong)로 바꾼다. 코드 안의 글자는 건드리지 않는다. */
function remarkCjkStrong() {
  const BOLD = /\*\*([^*\n]+?)\*\*/g;
  const walk = (node: any) => {
    if (!node.children || node.type === "code" || node.type === "inlineCode") return;
    const out: any[] = [];
    for (const ch of node.children) {
      if (ch.type === "text" && ch.value.includes("**")) {
        let last = 0;
        for (const m of ch.value.matchAll(BOLD)) {
          if (m.index! > last) out.push({ type: "text", value: ch.value.slice(last, m.index) });
          out.push({ type: "strong", children: [{ type: "text", value: m[1] }] });
          last = m.index! + m[0].length;
        }
        if (last < ch.value.length) out.push({ type: "text", value: ch.value.slice(last) });
      } else {
        walk(ch);
        out.push(ch);
      }
    }
    node.children = out;
  };
  return (tree: any) => walk(tree);
}

/** 답변 마크다운 블록.  입력: text — 마크다운 문자열  반환: 마크다운 div JSX */
export default function Markdown({ text }: { text: string }) {
  return (
    <div className="md">
      <ReactMarkdown remarkPlugins={[[remarkGfm, { singleTilde: false }], remarkCjkStrong]}>{text}</ReactMarkdown>
    </div>
  );
}
