/**
 * 공통 블록 렌더러: 지표·표·카드·문장 블록을 그린다. skill을 몰라도 그릴 수 있다.
 * 용도: 지표 묶음, 순위, 비교 행렬, 일반 표, 카드 묶음, 문장을 섹션 종류(variant)에 따라 고른다.
 * 목적: 분석 종류가 달라도 같은 블록 규칙으로 결과를 그리기 위함.
 */
import { useEffect, useState } from "react";
import type { Col, Metric, Section } from "../types";
import { SERIES } from "./PlotChart";

const DIR_GLYPH: Record<string, string> = { up: "↑", down: "↓", mixed: "∿" };

export function Metrics({ items }: { items: Metric[] }) {
  if (!items.length) return null;
  return (
    <dl className="metrics" style={{ gridTemplateColumns: `repeat(${Math.min(items.length, 4)}, minmax(0, 1fr))` }}>
      {items.map((m) => (
        <div key={m.label}>
          <dt>{m.label}</dt>
          <dd className={typeof m.value === "string" && m.value.length > 7 ? "txt" : undefined}>
            {typeof m.value === "number" ? m.value.toLocaleString() : m.value}
            {m.unit && <small>{m.unit}</small>}
            {m.note && <span className={`grade ${m.tone ? "t-" + m.tone : ""}`}>{m.note}</span>}
          </dd>
        </div>
      ))}
    </dl>
  );
}

function fmt(v: any, c: Col) {
  if (v == null || v === "") return "-";
  if (c.type === "pct") return `${(Number(v) * 100).toFixed(1)}%`;
  if (c.type === "num" && typeof v === "number") return c.digits != null ? Number(v.toPrecision(c.digits)).toLocaleString() : v.toLocaleString();
  return String(v);
}

function Ranking({ s }: { s: Extract<Section, { type: "table" }> }) {
  const [shown, setShown] = useState(false);
  const bar = s.columns.find((c) => c.type === "bar")!;
  const name = s.columns.find((c) => c.type === "text")!;
  const badge = s.columns.find((c) => c.type === "badge");
  const max = Math.max(0.0001, ...s.rows.map((r) => Number(r[bar.key]) || 0));
  useEffect(() => {
    setShown(false);
    const h = requestAnimationFrame(() => setShown(true));
    return () => cancelAnimationFrame(h);
  }, [s.rows]);
  return (
    <section className="ranking" aria-label={s.title}>
      <div className="ranking-head">
        <span>{name.label}</span>
        <span>{bar.label}</span>
        {badge && <span>{badge.label}</span>}
      </div>
      <ol>
        {s.rows.map((r, i) => (
          <li key={i} className={i === 0 ? "lead" : ""}>
            <span className="rk">
              {r.rank ?? i + 1}
              {r.delta !== undefined && r.delta !== null && r.delta !== 0 && (
                <em className={`delta ${r.delta === "new" ? "new" : r.delta > 0 ? "up" : r.delta < 0 ? "down" : "same"}`}
                  title="직전 분석 대비 순위 변화">
                  {r.delta === "new" ? "NEW" : r.delta > 0 ? `▲${r.delta}` : r.delta < 0 ? `▼${-r.delta}` : "–"}
                </em>
              )}
            </span>
            <span className="nm">{r[name.key]}{name.sub && r[name.sub] && <small>{r[name.sub]}</small>}</span>
            <span className="bar" aria-hidden><i style={{ width: shown ? `${(Number(r[bar.key]) / max) * 100}%` : "0%", transitionDelay: `${i * 35}ms` }} /></span>
            <span className="sh">{(Number(r[bar.key]) * 100).toFixed(1)}%</span>
            {badge && (
              <span className={`dir ${r[badge.tone ?? ""] ?? ""}`}>
                <b aria-hidden>{DIR_GLYPH[r[badge.tone ?? ""]] ?? "·"}</b>
                {r[badge.key]}
              </span>
            )}
          </li>
        ))}
      </ol>
    </section>
  );
}

function Matrix({ s }: { s: Extract<Section, { type: "table" }> }) {
  const bars = s.columns.filter((c) => c.type === "bar");
  const name = s.columns[0];
  const max = Math.max(0.0001, ...s.rows.flatMap((r) => bars.map((b) => Number(r[b.key]) || 0)));
  const grid = { gridTemplateColumns: `minmax(170px, 1.2fr) repeat(${bars.length}, 1fr)` };
  return (
    <section className="ranking share-matrix" aria-label={s.title}>
      <div className="matrix-head" style={grid}>
        <span>{name.label}</span>
        {bars.map((b, i) => <span key={b.key}><i className="swatch" style={{ background: SERIES[(b.series ?? i) % SERIES.length] }} />{b.label}</span>)}
      </div>
      <ol>
        {s.rows.map((r, ri) => (
          <li key={ri} style={grid}>
            <span className="nm">{r[name.key]}</span>
            {bars.map((b, i) => (
              <span key={b.key} className="cell">
                <span className="bar" aria-hidden><i style={{ width: `${((Number(r[b.key]) || 0) / max) * 100}%`, background: SERIES[(b.series ?? i) % SERIES.length] }} /></span>
                <span className="sh">{((Number(r[b.key]) || 0) * 100).toFixed(0)}%</span>
              </span>
            ))}
          </li>
        ))}
      </ol>
    </section>
  );
}

function Table({ s }: { s: Extract<Section, { type: "table" }> }) {
  const body = (
    <div className="table-wrap">
      <table className="grid-table">
        <thead>
          <tr>{s.columns.map((c) => <th key={c.key} className={c.type === "num" || c.type === "pct" ? "num" : ""}>{c.label}</th>)}</tr>
        </thead>
        <tbody>
          {s.rows.map((r, i) => (
            <tr key={i} className={r._strong ? "strong" : ""}>
              {s.columns.map((c) => (
                <td key={c.key} className={c.type === "num" || c.type === "pct" ? "num" : ""}>
                  {c.type === "badge" ? <span className={`badge t-${r[c.tone ?? ""] ?? ""}`}>{r[c.key]}</span> : fmt(r[c.key], c)}
                  {c.sub && r[c.sub] && <small>{r[c.sub]}</small>}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
  if (s.collapsed)
    return (
      <details className="sec-table">
        <summary>{s.title}</summary>
        {body}
      </details>
    );
  return (
    <section className="sec-table" aria-label={s.title}>
      {s.title && <h3>{s.title}</h3>}
      {body}
    </section>
  );
}

/** 섹션 목록을 종류별로 그린다: 문장(text), 카드 묶음(cards), 순위(ranking), 행렬(matrix), 그 밖은 표.  입력: items — 섹션 목록  반환: 섹션 JSX 묶음 */
export function Sections({ items }: { items: Section[] }) {
  return (
    <>
      {items.map((s, i) => {
        if (s.type === "text") return <p key={i} className={`sec-text ${s.tone ? "t-" + s.tone : ""}`}>{s.text}</p>;
        if (s.type === "cards")
          return (
            <div key={i} className="group-cards">
              {s.cards.map((c, ci) => (
                <div key={c.title} className="group-card" style={{ borderTopColor: SERIES[ci % SERIES.length] }}>
                  <strong>{c.title}</strong>
                  {c.error ? <span className="notice error">{c.error}</span> : (
                    <dl>{(c.items ?? []).map((it) => <div key={it.label}><dt>{it.label}</dt><dd>{it.value}</dd></div>)}</dl>
                  )}
                </div>
              ))}
            </div>
          );
        if (s.variant === "ranking") return <Ranking key={i} s={s} />;
        if (s.variant === "matrix") return <Matrix key={i} s={s} />;
        return <Table key={i} s={s} />;
      })}
    </>
  );
}
