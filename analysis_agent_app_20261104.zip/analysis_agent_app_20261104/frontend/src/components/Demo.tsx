/**
 * 시연 시나리오: 왼쪽 위 시나리오 메뉴와 입력창 위 진행 막대.
 * 용도: DemoMenu는 고객 요건별 자연어 요청 순서를 펼쳐 보여주고, DemoBar는 현재 단계 문장을 보내거나 건너뛰고 다음 시나리오로 넘긴다.
 * 목적: 시연할 때 요청 문장을 매번 새로 치지 않고 순서대로 보내게 하기 위함. 문장은 메뉴를 처음 열 때 서버(/api/demo)가 기본 테이블의 값으로 채운다.
 */
import { useEffect, useRef, useState } from "react";
import type { DemoScenario } from "../types";

export type DemoState = { id: string; i: number };   // 진행 중인 시나리오와 다음에 보낼 단계

/** 시연 시나리오 메뉴. 열 때 시나리오를 아직 안 받았으면 받아 오고, 고른 단계부터 대화를 이어가게 한다. 바깥을 누르거나 Esc를 누르면 닫는다.
 *  입력: scenarios — 시나리오 목록(null이면 받는 중), error — 받기 실패 메시지, state — 진행 중인 시나리오와 단계, busy — 처리 중 여부, onOpen — 메뉴를 열 때 호출, onStart — (시나리오 id, 단계 번호) 시작 콜백  반환: 메뉴 버튼과 팝업 JSX */
export function DemoMenu({ scenarios, error, state, busy, onOpen, onStart }: {
  scenarios: DemoScenario[] | null;   // null = 아직 받는 중
  error?: string;
  state: DemoState | null;
  busy: boolean;
  onOpen: () => void;                 // 메뉴를 열 때(시나리오를 아직 안 받았으면 받는다)
  onStart: (id: string, step: number) => void;   // step 0 = 처음부터(새 대화), 그 밖 = 지금 대화에서 그 단계부터
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const away = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    const esc = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", away);
    document.addEventListener("keydown", esc);
    return () => {
      document.removeEventListener("mousedown", away);
      document.removeEventListener("keydown", esc);
    };
  }, [open]);
  const go = (id: string, step: number) => {
    setOpen(false);
    onStart(id, step);
  };
  return (
    <div className="demo-menu" ref={ref}>
      <button type="button" className={`demo-toggle ${state ? "on" : ""}`} aria-expanded={open} aria-haspopup="dialog"
        onClick={() => { if (!open) onOpen(); setOpen((v) => !v); }}>
        시연 시나리오 <span aria-hidden>▾</span>
      </button>
      {open && (
        <div className="demo-pop" role="dialog" aria-label="시연 시나리오">
          {!scenarios && <p className="demo-pop-head">{error ? `시나리오를 읽지 못했습니다: ${error}` : "시나리오를 읽는 중"}</p>}
          <ol className="demo-list">
            {(scenarios ?? []).map((s, si) => {
              const cur = state?.id === s.id ? state.i : -1;
              return (
                <li key={s.id} className={cur >= 0 ? "active" : ""}>
                  <div className="demo-row">
                    <span className="demo-no">{si + 1}</span>
                    <strong>{s.title}</strong>
                    <button type="button" className="demo-start" disabled={busy} onClick={() => go(s.id, 0)}>{cur >= 0 ? "처음부터" : "시작"}</button>
                  </div>
                  <ul className="demo-needs" aria-label="고객 요건">
                    {s.needs.map((n) => <li key={n}>{n}</li>)}
                  </ul>
                  <ol className="demo-steps">
                    {s.steps.map((st, i) => (
                      <li key={i} className={cur > i ? "done" : cur === i ? "next" : ""}>
                        <button type="button" disabled={busy} onClick={() => go(s.id, i)} title="이 단계부터 지금 대화에서 이어서">
                          <span className="demo-mark" aria-hidden>{cur > i ? "✓" : i + 1}</span>
                          <span className="demo-ask">“{st.ask}”</span>
                          <span className="demo-shows">{st.shows}</span>
                        </button>
                      </li>
                    ))}
                  </ol>
                </li>
              );
            })}
          </ol>
        </div>
      )}
    </div>
  );
}

/** 시연 진행 막대(입력창 위). 현재 단계의 문장과 보여줄 내용을 보이고, 보내기·건너뛰기·끝내기를 제공한다. 시나리오를 마치면 다음 시나리오 버튼을 보인다.
 *  입력: scenarios — 전체 시나리오, state — 진행 상태, busy — 처리 중 여부, ready — 대화 준비 완료 여부, onSend — 현재 단계 보내기, onSkip — 건너뛰기, onNext — 다음 시나리오 id로 시작, onEnd — 끝내기  반환: 진행 막대 JSX */
export function DemoBar({ scenarios, state, busy, ready, onSend, onSkip, onNext, onEnd }: {
  scenarios: DemoScenario[];
  state: DemoState;
  busy: boolean;
  ready: boolean;                 // 대화 준비가 끝났는지(첫 화면 정보)
  onSend: () => void;
  onSkip: () => void;
  onNext: (id: string) => void;   // 다음 시나리오 처음부터
  onEnd: () => void;
}) {
  const idx = scenarios.findIndex((s) => s.id === state.id);
  const s = scenarios[idx];
  if (!s) {
    return <div className="chat-col demo-bar"><span className="demo-bar-title">시연 시나리오 준비 중</span><button type="button" className="link" onClick={onEnd}>끝내기</button></div>;
  }
  const st = s.steps[state.i];
  const next = scenarios[idx + 1];
  return (
    <div className="chat-col demo-bar" aria-label="시연 진행">
      <div className="demo-bar-head">
        <span className="demo-bar-title">시연 {idx + 1} · {s.title}</span>
        <span className="demo-dots" aria-label={`${Math.min(state.i, s.steps.length)}/${s.steps.length} 단계`}>
          {s.steps.map((_, i) => <i key={i} className={i < state.i ? "done" : i === state.i ? "next" : ""} />)}
        </span>
        <button type="button" className="link" onClick={onEnd}>끝내기</button>
      </div>
      {st ? (
        <div className="demo-bar-step">
          <span className="demo-bar-ask">“{st.ask}”</span>
          <span className="demo-shows">{st.shows}</span>
          <button type="button" className="demo-send" disabled={busy || !ready} onClick={onSend}>{ready ? "보내기" : "준비 중"}</button>
          <button type="button" className="link" disabled={busy} onClick={onSkip}>건너뛰기</button>
        </div>
      ) : (
        <div className="demo-bar-step">
          <span className="demo-bar-ask">이 시나리오를 마쳤습니다.</span>
          {next && <button type="button" className="demo-send" disabled={busy} onClick={() => onNext(next.id)}>다음: {next.title}</button>}
        </div>
      )}
    </div>
  );
}
