/**
 * 작업 데이터 패널: 분석에 실제로 쓴 데이터와 전처리 과정을 보여준다.
 * 용도: 적용한 범위·전처리 항목, 변수별 결측 대치 방법과 이유, 전처리 로그, 전처리한 데이터 표(채운 칸 강조)를 그린다.
 * 목적: 분석 결과가 어떤 데이터로 나왔는지 근거를 투명하게 보여주기 위함. 분석은 이 데이터로 실행된다.
 */
import type { WorkData } from "../types";
import { fmtCell } from "./LookupPanel";

/** 작업 데이터 패널: 적용한 범위·전처리, 변수별 결측 대치 방법, 전처리한 데이터(채운 칸 강조). 분석은 이 데이터로 실행된다. */
/** 작업 데이터 패널 본체. 적용 항목, 결측 대치 계획, 로그, 전처리한 데이터 표를 보여주고, 채운 칸은 강조한다.
 *  입력: data — 작업 데이터(제목·부제·적용 항목·결측 계획·로그·행·열·채운 칸 목록)  반환: 작업 데이터 패널 JSX */
export default function WorkPanel({ data }: { data: WorkData }) {
  const marked = new Set(data.filled.map(([r, c]) => `${r}:${c}`));
  return (
    <div className="work-panel">
      <div className="sp-head">
        <h2>{data.title}</h2>
        <p>{data.subtitle}</p>
      </div>
      <section className="applied" aria-label="적용한 범위·전처리">
        <div className="applied-head"><h3>적용한 범위·전처리</h3></div>
        <dl>{data.applied.map((a) => <div key={a.label}><dt>{a.label}</dt><dd>{a.value}</dd></div>)}</dl>
      </section>
      {data.plan.length > 0 && (
        <section aria-label="변수별 결측 대치">
          <h3>변수별 결측 대치</h3>
          <table className="miss-table">
            <thead><tr><th>변수</th><th>결측 비율</th><th>채운 방법</th><th>이유</th></tr></thead>
            <tbody>{data.plan.map((p) => <tr key={p.label}><td>{p.label}</td><td className="num">{p.missing}</td><td>{p.method}</td><td>{p.reason}</td></tr>)}</tbody>
          </table>
        </section>
      )}
      {data.log.length > 0 && <ul className="step-log">{data.log.map((l, i) => <li key={i}>{l}</li>)}</ul>}
      <h3>전처리한 데이터 <small>{data.n_rows.toLocaleString()}{data.unit} 중 {data.rows.length}{data.unit} 표시 · 채운 칸 {data.n_filled.toLocaleString()}개 강조(채운 칸이 있는 행 먼저)</small></h3>
      <div className="stats-table">
        <table>
          <thead><tr>{data.columns.map((c) => <th key={c}>{c}</th>)}</tr></thead>
          <tbody>
            {data.rows.map((r, i) => (
              <tr key={i}>{r.map((v, j) => <td key={j} className={marked.has(`${i}:${j}`) ? "filled" : ""} title={marked.has(`${i}:${j}`) ? "결측을 채운 값" : undefined}>{fmtCell(v)}</td>)}</tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
