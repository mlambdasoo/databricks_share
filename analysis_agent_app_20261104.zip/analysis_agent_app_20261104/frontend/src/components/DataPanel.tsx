/**
 * 데이터 패널: 분석 대상 테이블을 고르고, 이 대화 테이블의 기초 통계를 보여준다.
 * 용도: 등록 테이블 선택 카드와 기초 통계 표(컬럼별 분석 역할 · 결측 비율 · 값 요약)를 그린다. 통계는 서버가 전체 SQL로 집계한다.
 * 목적: 분석 전에 데이터 상태를 사용자가 직접 보고, 필요하면 테이블을 바로 고를 수 있게 함.
 */
import { useEffect, useState } from "react";
import { fetchStats } from "../api";
import type { Meta, Range, SourceItem, StatCol, TableStats } from "../types";

const num = (v: number | string | null | undefined) => (typeof v !== "number" ? "-" : Number(v.toPrecision(4)).toLocaleString());

/** 컬럼 역할(데이터 처리 첫 제안) → 분석에서 어떻게 쓰이는지. */
const ROLE: Record<string, string> = {
  y: "목표 지표 후보", x: "영향 요인 후보", result: "결과 뒤에 정해지는 값(요인에서 뺌)", dimension: "범위 구분(필터)", date: "날짜", id: "식별자", text: "메모",
};

const rangeText = (r: Range) =>
  !r ? "-" : r[0] != null && r[1] != null ? `${r[0]}~${r[1]}` : r[0] != null ? `${r[0]} 이상` : `${r[1]} 이하`;

/** 기초 통계 표의 "값" 칸: 수치 = 최소·평균·최대, 날짜 = 기간, 범주 = 값별 건수(종류가 많으면 고유값 수).
 *  분석 전에 공통으로 손보는 값(문자로 저장된 숫자의 숫자 아닌 값, 정상범위 밖 값)은 몇 건인지와 어떻게 처리되는지를 붙인다. */
function valueText(c: StatCol): string {
  if (c.kind === "num") {
    const tn = c.text_num;
    const bad = tn?.non_numeric
      ? ` · 문자로 저장된 숫자: 숫자가 아닌 값 ${tn.non_numeric.toLocaleString()}건(${tn.values.map(([v, n]) => `"${v}" ${n.toLocaleString()}`).join(" · ")})은 분석할 때 결측으로 처리`
      : tn ? " · 문자로 저장된 숫자(분석할 때 숫자로 변환)" : "";
    return `최소 ${num(c.min)} · 평균 ${num(c.mean)} · 최대 ${num(c.max)}` + bad +
      (c.out_of_range ? ` · 정상범위(${rangeText(c.normal ?? null)}) 밖 ${c.out_of_range.toLocaleString()}건(분석할 때 기본으로 결측 처리)` : "");
  }
  if (c.kind === "date") return `${String(c.min ?? "-").slice(0, 16)} ~ ${String(c.max ?? "-").slice(0, 16)}`;
  if (c.top?.length) {
    const head = c.top.slice(0, 6).map(([v, n]) => `${v} ${n.toLocaleString()}`).join(" · ");
    return c.top.length > 6 ? `${head} 외 ${c.top.length - 6}개` : head;
  }
  return `고유값 ${(c.distinct ?? 0).toLocaleString()}개`;
}

/** 데이터 패널: 분석 대상으로 등록한 테이블을 보고 직접 고르고(LLM 없이 바로 바뀜), 그 테이블의 기초 통계(전체 SQL 집계)를 본다.
 *  고르지 않으면 질문마다 맞는 테이블을 LLM이 고른다.
 *  입력: meta — 데이터 정보, sources — 등록 테이블 목록과 현재 테이블, chosen — 이 대화의 테이블이 정해졌는지, busy — 처리 중 여부, onPickSource — 테이블 선택 콜백  반환: 데이터 패널 JSX */
export default function DataPanel({ meta, sources, chosen, busy, onPickSource }: {
  meta: Meta | null;
  sources: { items: SourceItem[]; current: string } | null;
  chosen: boolean;   // 이 대화의 테이블이 정해졌는지(질문으로든 직접이든)
  busy: boolean;
  onPickSource: (name: string) => void;
}) {
  const items = sources?.items ?? meta?.sources ?? null;
  const ready = !!meta && !!items;
  const table = chosen ? sources?.current ?? meta?.source ?? null : null;
  const [st, setSt] = useState<TableStats | null>(null);
  const [stErr, setStErr] = useState<string | null>(null);
  useEffect(() => {  // 기초 통계: 이 패널에서 그 테이블을 볼 때만 계산한다(테이블마다 한 번, 서버가 기억)
    setSt(null);
    setStErr(null);
    if (!table) return;
    let live = true;
    fetchStats(table).then((d) => live && setSt(d)).catch((e) => live && setStErr(String(e.message || e)));
    return () => { live = false; };
  }, [table]);
  return (
    <div className="data-panel">
      <div className="sp-head">
        <h2>데이터</h2>
      </div>
      <section className="welcome-src" aria-label="분석할 데이터">
        {ready ? (
          <SourcePicker items={items} current={chosen ? sources?.current ?? meta?.source ?? null : null} busy={busy} onPick={onPickSource} />
        ) : (
          <p className="src-pick-note">{meta?.error ? `데이터를 불러오지 못했습니다: ${meta.error}` : "등록된 테이블을 불러오는 중"}</p>
        )}
      </section>
      {ready && table && (
        <section className="stats" aria-label="기초 통계">
          <div className="stats-head">
            <h3>기초 통계</h3>
            {st && <span>{st.rows.toLocaleString()}행 · 컬럼 {st.n_cols}개{st.date ? ` · ${st.date.label} ${st.date.min} ~ ${st.date.max}` : ""}</span>}
          </div>
          {st ? (
            <div className="stats-table">
              <table>
                <thead><tr><th>컬럼</th><th>분석에서</th><th>결측</th><th>값</th></tr></thead>
                <tbody>
                  {st.columns.map((c) => (
                    <tr key={c.col}>
                      <td>{c.label}<small>{c.category ? `${c.category} · ` : ""}{c.col}</small></td>
                      <td className="role">{ROLE[c.role ?? ""] ?? "-"}</td>
                      <td className="num">{c.missing ? `${(c.missing * 100).toFixed(c.missing < 0.01 ? 1 : 0)}%` : "-"}</td>
                      <td>{valueText(c)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="stats-loading">{stErr ? `기초 통계를 계산하지 못했습니다: ${stErr}` : "기초 통계를 계산하는 중"}</p>
          )}
        </section>
      )}
    </div>
  );
}

/** 데이터 선택기: Unity Catalog 태그로 등록한 테이블 카드 목록(이름 · 설명). 누르면 LLM을 거치지 않고 바로 이 대화의 테이블이 된다.
 *  입력: items — 등록 테이블 목록(null이면 불러오는 중), current — 이 대화의 테이블 이름(없으면 null), busy — 처리 중 여부, onPick — 테이블 이름을 받는 선택 콜백  반환: 카드 목록 JSX(목록이 비면 안내 문구) */
function SourcePicker({ items, current, busy, onPick }: {
  items: SourceItem[] | null;
  current: string | null;   // 이 대화의 테이블(정하지 않았으면 null — 질문에 맞게 자동 선택)
  busy: boolean;
  onPick: (name: string) => void;
}) {
  if (!items) return <p className="src-pick-note">등록된 테이블을 불러오는 중</p>;
  if (!items.length) return <p className="src-pick-note">등록된 테이블이 없습니다.</p>;
  return (
    <ul className="src-list" aria-label="분석할 데이터">
      {items.map((s) => (
        <li key={s.name}>
          <button type="button" className={`src-card ${s.name === current ? "on" : ""}`} aria-pressed={s.name === current} disabled={busy}
            onClick={() => s.name !== current && onPick(s.name)}>
            <strong>{s.short}{s.name === current && <em>이 대화의 테이블</em>}</strong>
            {s.comment && <span>{s.comment}</span>}
          </button>
        </li>
      ))}
    </ul>
  );
}
