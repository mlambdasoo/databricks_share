/**
 * 가운데 대화창: 대화 메시지와 오브젝트 카드(분석 설정 · 결과 · 조회 결과 · 데이터)를 시간순으로 그리고, 입력창을 보여준다.
 * 용도: 메시지 종류(user·assistant·tool·object·proposal·source·skill·file·notice)마다 다른 모양으로 그린다. 카드를 누르면 오른쪽 패널에 상세가 열린다. 입력창 위에 후속 질문 칩과 시연 진행 막대를 둔다.
 * 목적: 대화를 중심으로 분석을 진행하고, 자세한 근거는 패널로 나눠 대화가 길어져도 읽기 쉽게 함.
 */
import { useEffect, useRef, useState, type ReactNode } from "react";
import type { Artifact, Meta, UIMsg } from "../types";
import Markdown from "./Markdown";
import ActivityBar, { type Activity } from "./ActivityBar";
import { fmtCell } from "./LookupPanel";
import { ro } from "../data";

interface Props {
  msgs: UIMsg[];
  artifacts: Record<string, Artifact>;
  busy: boolean;
  meta: Meta | null;
  activity: Activity | null;
  openId: string | null;            // 지금 패널에 열린 오브젝트(카드 강조)
  onSend: (text: string) => void;
  onRunProposal: (msgId: string) => void;
  onOpen: (artifactId: string) => void;
  onOpenData: () => void;
  followups: string[];   // 후속 질문(입력창 위 칩, 누르면 보낸다)
  demoBar?: ReactNode;   // 시연 진행 막대(입력창 바로 위)
}

const KIND: Record<string, string> = { settings: "분석 설정", result: "결과", lookup: "원본 조회", work: "작업 데이터" };

function Elapsed({ running, ms }: { running: boolean; ms?: number }) {
  const [t, setT] = useState(0);
  useEffect(() => {
    if (!running) return;
    const start = performance.now();
    const h = setInterval(() => setT(performance.now() - start), 200);
    return () => clearInterval(h);
  }, [running]);
  const v = running ? t : ms ?? 0;
  return <span className="elapsed">{(v / 1000).toFixed(1)}초</span>;
}

/** 가운데 대화창 본체. 메시지를 시간순으로 그리고, 오브젝트 카드를 누르면 패널을 열고, 입력창과 후속 질문 칩을 보여준다.
 *  입력: msgs — 대화 메시지 목록, artifacts — 오브젝트 id별 데이터, busy — 처리 중 여부, meta — 데이터 정보, activity — 진행 상태(없으면 숨김), openId — 패널에 열린 오브젝트 id, onSend — 메시지 보내기, onRunProposal — 분석 설정 제안 실행(메시지 id), onOpen — 오브젝트 패널 열기(id), onOpenData — 데이터 패널 열기, followups — 후속 질문 목록, demoBar — 시연 진행 막대(입력창 위)  반환: 대화창 section JSX */
export default function ChatPane({ msgs, artifacts, busy, meta, activity, openId, onSend, onRunProposal, onOpen, onOpenData, followups, demoBar }: Props) {
  const [text, setText] = useState("");
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const el = listRef.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [msgs]);

  useEffect(() => {
    const el = inputRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 160) + "px";
    el.style.overflowY = el.scrollHeight > 160 ? "auto" : "hidden";
  }, [text]);

  const submit = () => {
    const v = text.trim();
    if (!v || busy) return;
    onSend(v);
    setText("");
  };

  return (
    <section className="chat" aria-label="대화">
      <div className="chat-list" ref={listRef} aria-live="polite">
        <div className="chat-col">
          {msgs.length === 0 && <Welcome meta={meta} busy={busy} onSend={onSend} onOpenData={onOpenData} />}
          {msgs.map((m) => {
            switch (m.role) {
              case "user":
                return (
                  <div key={m.id} className={`msg user ${m.system ? "system" : ""}`}>
                    <div className="bubble">{m.text}</div>
                  </div>
                );
              case "assistant":
                return (
                  <div key={m.id} className="msg assistant">
                    <Markdown text={m.text} />
                    {m.streaming && <span className="caret" aria-hidden />}
                  </div>
                );
              case "tool":
                return (
                  <div key={m.id} className={`tool-line ${m.status}`}>
                    <span className="tool-dot" aria-hidden />
                    <span className="tool-label">{m.label}{m.status === "running" && m.progress ? <small className="tool-progress"> · {m.progress}</small> : null}</span>
                    <Elapsed running={m.status === "running"} ms={m.ms} />
                    {m.status === "error" && m.error && <span className="tool-error">{m.error}</span>}
                  </div>
                );
              case "object": {
                const a = artifacts[m.artifactId];
                const lk = a?.kind === "lookup" ? a.data : null;
                return (
                  <button key={m.id} className={`object-card k-${m.kind} ${openId === m.artifactId ? "active" : ""}`} onClick={() => onOpen(m.artifactId)}>
                    <span className="obj-kind">{KIND[m.kind]}</span>
                    <span className="obj-title">{m.title}</span>
                    {m.detail && <span className="obj-detail">{m.detail}</span>}
                    {lk && lk.rows.length > 0 && (
                      <table className="obj-mini">
                        <thead><tr>{lk.columns.map((c) => <th key={c}>{c}</th>)}</tr></thead>
                        <tbody>{lk.rows.slice(0, 5).map((r, i) => <tr key={i}>{r.map((v, j) => <td key={j}>{fmtCell(v)}</td>)}</tr>)}</tbody>
                      </table>
                    )}
                    <span className="obj-open">{openId === m.artifactId ? "패널에 열림" : "눌러서 자세히 보기"}</span>
                  </button>
                );
              }
              case "proposal": {
                const rows = m.lines.filter((l) => l.startsWith("- "));
                return (
                  <div key={m.id} className={`object-card k-settings proposal ${openId === m.artifactId ? "active" : ""}`}>
                    <button className="proposal-head" onClick={() => onOpen(m.artifactId)}>
                      <span className="obj-kind">분석 설정{m.skillTitle ? ` · ${m.skillTitle}` : ""}</span>
                      <span className="obj-title">{m.lines[0]?.replace(/\*/g, "") || "이렇게 분석해 볼게요"}</span>
                    </button>
                    <ul>
                      {rows.map((l, i) => {
                        const body = l.slice(2);
                        const isRec = body.includes("(제안)");
                        const cut = body.indexOf(": ");
                        const head = cut > 0 ? body.slice(0, cut).replace(" (제안)", "") : "";
                        const rest = cut > 0 ? body.slice(cut + 2) : body;
                        return (
                          <li key={i} className={`${isRec ? "rec" : ""} ${body.startsWith("⚠") ? "warn" : ""}`}>
                            {head && <strong>{head}{isRec && <span className="tag requested">제안</span>}</strong>}
                            <span className="pre">{rest}</span>
                          </li>
                        );
                      })}
                    </ul>
                    <div className="proposal-foot">
                      <span>{m.footer}</span>
                      {m.decided ? (
                        <span className="decided">제안대로 실행함</span>
                      ) : (
                        <span className="proposal-actions">
                          <button className="secondary" disabled={busy} onClick={() => onOpen(m.artifactId)}>설정 열기</button>
                          <button className="primary" disabled={busy} onClick={() => onRunProposal(m.id)}>제안대로 실행</button>
                        </span>
                      )}
                    </div>
                  </div>
                );
              }
              case "source":
                return (
                  <div key={m.id} className="skill-line">
                    <span aria-hidden>▸</span> 데이터: {m.label.replace(/`/g, "")}
                  </div>
                );
              case "skill":
                return (
                  <div key={m.id} className="skill-line">
                    <span aria-hidden>▸</span> {ro(m.title)} 진행
                  </div>
                );
              case "file":
                return (
                  <a key={m.id} className="file-link" href={m.url} download={m.name}>
                    <span className="file-icon" aria-hidden>PDF</span>
                    <span><strong>리포트 내려받기</strong><small>{m.name}</small></span>
                  </a>
                );
              case "notice":
                return <div key={m.id} className={`notice ${m.level}`} role="alert">{m.text}</div>;
            }
          })}
          {activity && <ActivityBar a={activity} variant="chat" />}
        </div>
      </div>
      <form className="composer" onSubmit={(e) => { e.preventDefault(); submit(); }}>
        {!busy && msgs.length > 0 && followups.length > 0 && (
          <div className="chat-col followups" aria-label="이어서 물어보기">
            {followups.map((q) => (
              <button key={q} type="button" className="followup" onClick={() => onSend(q)}>{q}</button>
            ))}
          </div>
        )}
        {demoBar}
        <div className="chat-col composer-row">
          <textarea
            ref={inputRef}
            rows={1}
            value={text}
            placeholder={busy ? "분석 중입니다" : "무엇을 분석할지 말씀해 주세요 (예: 범위·지표·처리 방법)"}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
                e.preventDefault();
                submit();
              }
            }}
            aria-label="분석 요청 입력"
          />
          <button type="submit" className="send" disabled={busy || !text.trim()}>보내기</button>
        </div>
      </form>
    </section>
  );
}

/** 대화가 비어 있을 때 가운데에 보이는 안내: 테이블 보기 버튼(데이터 패널), 할 수 있는 분석, 예시 질문(그 테이블의 첫 제안이 이미 있을 때만).
 *  아무것도 계산하지 않는다 — 테이블은 질문에 맞게 LLM이 고른다.
 *  입력: meta — 데이터 정보(null이면 불러오는 중), busy — 처리 중 여부, onSend — 예시 질문을 보내는 콜백, onOpenData — 데이터 패널 열기 콜백  반환: 안내 화면 JSX */
function Welcome({ meta, busy, onSend, onOpenData }: {
  meta: Meta | null;
  busy: boolean;
  onSend: (text: string) => void;
  onOpenData: () => void;
}) {
  return (
    <div className="welcome">
      <h1>무엇을 분석할까요?</h1>
      <p className="welcome-sub">
        {!meta ? "데이터 정보를 불러오는 중" : !meta.chosen ? (
          <button type="button" className="welcome-btn" onClick={onOpenData}>테이블 보기 · 직접 고르기</button>
        ) : (
          <>
            지금 데이터: <strong>{meta.title || String(meta.source).split(".").pop()}</strong>{" "}
            <button type="button" className="welcome-btn" onClick={onOpenData}>기초 통계 보기 · 테이블 바꾸기</button>
          </>
        )}
      </p>
      {(meta?.skills ?? []).length > 0 && (
        <section className="howto">
          <h3>할 수 있는 분석</h3>
          <ul>
            {meta!.skills!.map((s) => (
              <li key={s.name}><strong>{s.title}</strong><span>{s.summary}</span></li>
            ))}
          </ul>
        </section>
      )}
      {(meta?.examples ?? []).length > 0 && (
        <section className="ask" aria-label="이렇게 물어보세요">
          <h3>이렇게 물어보세요</h3>
          <div className="example-list">
            {meta!.examples!.map((e) => (
              <button key={e} className="example" onClick={() => onSend(e)} disabled={busy}>{e}</button>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
