/**
 * 분석 설정 패널: 모든 skill이 같은 모양으로 쓰는 설정 화면.
 * 용도: 진단 지표·표(접힌 상자), 공통 단계 칸(데이터 범위 → 전처리 → 변수 선택)을 펼쳐 바꾼다. 이 분석의 설정 값은 보기만 하고, 분석에 특화된 설정은 대화로 바꾼다.
 * 목적: 칸을 바꿔도 진단 숫자는 패널을 연 때의 값 그대로 두고, 바뀐 설정은 실행할 때 계산한다. 칸을 채운 뒤 실행 버튼을 연다.
 */
import { useState } from "react";
import type { Cfg, PanelField, SettingsData } from "../types";
import { josa } from "../data";
import { Metrics, Sections } from "./Sections";

/** 칸 값 → cfg에 반영. key "filters.<컬럼>"은 cfg.filters, 나머지는 cfg[key]. */
function applyField(cfg: Cfg, f: PanelField, v: any): Cfg {
  const out: Cfg = { ...cfg, filters: { ...(cfg.filters || {}) } };
  if (f.key.startsWith("filters.")) {
    const col = f.key.slice(8);
    if (v?.length) out.filters[col] = v;
    else delete out.filters[col];
  } else if (f.type === "daterange") {
    out[f.key] = v?.start || v?.end ? { col: f.col, start: v.start || null, end: v.end || null } : null;
  } else if (f.type === "percent") {
    out[f.key] = Number(v) / 100;
  } else if (f.type === "choice") {
    out[f.key] = v === "" ? null : v;
  } else {
    out[f.key] = v;
  }
  return out;
}

function Control({ f, value, onChange }: { f: PanelField; value: any; onChange: (v: any) => void }) {
  switch (f.type) {
    case "multi": {
      const groups = f.groups ?? [{ label: "", options: f.options ?? [] }];
      const excluded = f.store === "excluded";
      const on = (v: any) => (excluded ? !(value || []).includes(v) : (value || []).includes(v));
      const toggle = (v: any) => onChange((value || []).includes(v) ? (value || []).filter((x: any) => x !== v) : [...(value || []), v]);
      return (
        <div className="chip-groups">
          {groups.map((g) => {
            const vals = g.options.map(([v]) => v);
            const allOn = vals.every(on);
            return (
              <div key={g.label || "_"} className="chip-group">
                {g.label && (
                  <div className="chip-group-head">
                    <span>{g.label} ({vals.filter(on).length}/{vals.length})</span>
                    {excluded && (
                      <button type="button" className="link" onClick={() => onChange(allOn ? Array.from(new Set([...(value || []), ...vals]))
                        : (value || []).filter((x: any) => !vals.includes(x)))}>{allOn ? "이 분류 모두 빼기" : "이 분류 모두 넣기"}</button>
                    )}
                  </div>
                )}
                <div className={`chips ${excluded ? "check" : ""}`} role="group" aria-label={g.label || f.label}>
                  {g.options.map(([v, l]) => (
                    <button key={String(v)} type="button" aria-pressed={on(v)} className={on(v) ? "on" : ""} onClick={() => toggle(v)}>
                      {excluded && <span aria-hidden className="tick">{on(v) ? "✓" : ""}</span>}{l}
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      );
    }
    case "choice":
      return (
        <div className="segmented" role="radiogroup" aria-label={f.label}>
          {(f.options ?? []).map(([v, l]) => (
            <button key={String(v)} type="button" role="radio" aria-checked={value === v} className={value === v ? "on" : ""} onClick={() => onChange(v)}>{l}</button>
          ))}
        </div>
      );
    case "number":
      return <input type="number" className="text num-in" value={value ?? ""} min={f.min} max={f.max} step={f.step}
        onChange={(e) => onChange(e.target.value === "" ? null : Number(e.target.value))} aria-label={f.label} />;
    case "percent":
      return (
        <div className="number-row">
          <input type="range" min={f.min as number} max={f.max as number} step={f.step} value={Math.round((value ?? 0) * 100)}
            onChange={(e) => onChange(Number(e.target.value))} aria-label={f.label} />
          <output>{f.max_label && Math.round((value ?? 0) * 100) >= (f.max as number) ? f.max_label : `${Math.round((value ?? 0) * 100)}${f.suffix ?? "%"}`}</output>
        </div>
      );
    case "daterange":
      return (
        <div className="date-range">
          <input type="date" value={value?.start ?? ""} min={f.min as string} max={f.max as string} onChange={(e) => onChange({ ...value, start: e.target.value || null })} />
          <span aria-hidden>~</span>
          <input type="date" value={value?.end ?? ""} min={f.min as string} max={f.max as string} onChange={(e) => onChange({ ...value, end: e.target.value || null })} />
          {(value?.start || value?.end) && <button type="button" className="link" onClick={() => onChange({ start: null, end: null })}>전체 기간</button>}
        </div>
      );
    case "rowchoice": {
      const cur: Record<string, any> = value || {};
      const set = (k: string, nv: any) => {
        const next = { ...cur };
        if (nv === undefined) delete next[k]; else next[k] = nv;
        onChange(next);
      };
      return (
        <table className="miss-table">
          <thead><tr>{(f.columns ?? ["항목", "", "방법"]).map((c) => <th key={c}>{c}</th>)}</tr></thead>
          <tbody>
            {(f.rows ?? []).map((r) => {
              const v = cur[r.key];
              const mode = v === undefined ? "" : typeof v === "number" ? "__value" : v;
              return (
                <tr key={r.key}>
                  <td>{r.label}</td>
                  <td className="num">{r.info}</td>
                  <td>
                    <select aria-label={`${r.label} ${f.label}`} value={mode}
                      onChange={(e) => set(r.key, e.target.value === "" ? undefined : e.target.value === "__value" ? 0 : e.target.value)}>
                      <option value="">{v === undefined ? r.default : "추천으로 되돌리기"}</option>
                      {(f.options ?? []).map(([ov, ol]) => <option key={String(ov)} value={ov}>{ol}</option>)}
                    </select>
                    {typeof v === "number" && (
                      <input type="number" className="inline-val" value={v} aria-label={`${r.label} 채울 값`} onChange={(e) => set(r.key, Number(e.target.value))} />
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      );
    }
  }
}

/** 칸의 화면 값(cfg에 있는 값 → 칸 형식). */
function valueOf(cfg: Cfg, f: PanelField): any {
  if (f.key.startsWith("filters.")) return (cfg.filters || {})[f.key.slice(8)] ?? [];
  const v = cfg[f.key];
  if (f.type === "daterange") return { start: v?.start ?? null, end: v?.end ?? null };
  if (f.type === "choice" && (v === null || v === undefined)) return f.value ?? "";
  return v === undefined ? f.value : v;
}

/** 분석 설정 패널 본체. 단계를 펼쳐 칸을 바꾸고, 필수 칸(최소 개수)을 채운 경우에만 실행 버튼을 연다. 실행하면 현재 cfg와 실행할 도구 이름을 넘긴다.
 *  입력: data — 설정 데이터(진단·단계·cfg 등), busy — 처리 중 여부, onRun — (cfg, 도구 이름)을 받는 실행 콜백, onBack — 결과로 돌아가기(없으면 버튼 없음)  반환: 설정 패널 JSX */
export default function SettingsPanel({ data, busy, onRun, onBack }: {
  data: SettingsData;
  conversationId: string | null;
  busy: boolean;
  onRun: (cfg: Cfg, tool: string) => void;
  onBack?: () => void;   // 결과의 [설정 수정]으로 열었으면 결과로 돌아가기
}) {
  const view = data;  // 칸을 바꿔도 다시 계산하지 않는다 — 바뀐 설정은 실행할 때 계산된다(진단 숫자는 패널을 연 때의 값)
  const [cfg, setCfg] = useState<Cfg>(() => structuredClone(data.cfg));
  const [open, setOpen] = useState<string | null>(null);
  const [edited, setEdited] = useState<Set<string>>(new Set());

  const change = (stepId: string, f: PanelField, v: any) => {
    setCfg((prev) => applyField(prev, f, v));
    setEdited((prev) => new Set(prev).add(stepId));
  };

  const short = view.steps.flatMap((s) => s.fields).filter((f) => f.type === "multi" && f.store !== "excluded" && Number(f.min)
    && ((valueOf(cfg, f) || []).length < Number(f.min)));
  const canRun = !busy && (edited.size > 0 || view.can_run) && short.length === 0;  // 고친 뒤에는 처음 경고에 막지 않는다(잘못된 값은 실행 때 알린다)
  const foot = short.length ? `${josa(short.map((f) => f.label).join(", "), "을를")} 하나 이상 고르세요`
    : edited.size ? "" : view.blockers[0] ?? "";

  return (
    <div className="settings-panel">
      <div className="sp-head">
        <h2>{view.title}</h2>
        {onBack && <button type="button" className="link back" onClick={onBack}>결과로 돌아가기</button>}
      </div>
      <div className="sp-diag">
        <Metrics items={view.metrics} />
        {view.sections.length > 0 && (
          <details className="sp-sections">
            <summary>데이터 진단 자세히</summary>
            <Sections items={view.sections} />
          </details>
        )}
      </div>
      <h3 className="sp-part">데이터 처리</h3>
      <ol className="steps">
        {view.steps.map((s, i) => (
          <li key={s.id} className={`step ${open === s.id ? "open" : ""} ${s.warn ? "warn" : ""}`}>
            <button type="button" className="step-head" aria-expanded={open === s.id} onClick={() => setOpen(open === s.id ? null : s.id)}>
              <span className="step-no">{i + 1}</span>
              <span className="step-main">
                <span className="step-title">{s.label} {edited.has(s.id) && <span className="tag edited">바꿈</span>}</span>
                <span className="step-summary">{s.summary}</span>
              </span>
              <span className="step-caret" aria-hidden />
            </button>
            {open === s.id && (
              <div className="step-body">
                <p className="step-q">{s.question}</p>
                {s.fields.map((f) => (
                  <div key={f.key} className="field">
                    <span className="field-label">{f.label}</span>
                    <div className="field-body"><Control f={f} value={valueOf(cfg, f)} onChange={(v) => change(s.id, f, v)} /></div>
                    {f.hint && <span className="field-hint">{f.hint}</span>}
                    {f.detail && f.detail.rows.length > 0 && (
                      <details className="field-detail">
                        <summary>{f.detail.summary}</summary>
                        <table className="miss-table">
                          <thead><tr>{f.detail.columns.map((c) => <th key={c}>{c}</th>)}</tr></thead>
                          <tbody>{f.detail.rows.map((r, k) => <tr key={k}>{r.map((v, j) => <td key={j} className={j > 0 ? "num" : undefined}>{v}</td>)}</tr>)}</tbody>
                        </table>
                      </details>
                    )}
                  </div>
                ))}
                {s.notes && s.notes.length > 0 && <ul className="step-log">{s.notes.map((n, k) => <li key={k}>{n}</li>)}</ul>}
              </div>
            )}
          </li>
        ))}
      </ol>
      <div className="sheet-foot">
        <span className={`foot-note ${short.length || (!edited.size && view.blockers.length) ? "warn" : ""}`}>{foot}</span>
        <button className="primary" disabled={!canRun} onClick={() => onRun(cfg, view.run_tool)}>
          {view.from_result ? "이 설정으로 다시 실행" : "이대로 실행"}
        </button>
      </div>
    </div>
  );
}
