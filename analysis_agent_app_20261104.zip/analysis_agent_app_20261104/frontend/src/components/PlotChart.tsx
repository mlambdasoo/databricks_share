/**
 * 차트 그림: 차트 spec(공통 계약)과 데이터셋을 Plotly 그림으로 바꿔 그린다.
 * 용도: bar·line·scatter·box·hist·bin·corr·beeswarm·waterfall 등 spec.type별 그림을 만든다. id_field가 있으면 점을 누를 때 행 id를 위로 올린다. 결과 PDF용 차트 이미지 캡처(captureCharts)도 제공한다.
 * 목적: skill은 spec만 주면 되게 하고, 색 규칙을 한곳에서 지키기 위함. 색은 기본 블루, 계열 색은 고정 순서, 빨강은 이상 신호 전용.
 */
import { useEffect, useRef, useState } from "react";
import Plotly from "plotly.js-cartesian-dist-min";
import type { ChartSpec, Dataset, Field } from "../types";
import { aggregate, bucketOf, isNum, loadDataset, quantileBins, rowIndex, spearman, unit, type Table } from "../data";

export const SERIES = ["#006ECD", "#FF9700", "#00843D", "#6B4FA3", "#00A0B0", "#B35A1F"];
const SIGNAL = "#EF151E";
const SPEC = "#E5721A";
const MUTED = "#8A9097";
const GRID = "#ECECEC";
const INK2 = "#4d4d4d";
const VALUE_SCALE: [number, string][] = [[0, "#006ECD"], [0.5, "#D9D9D9"], [1, "#E5721A"]];
const CORR_SCALE: [number, string][] = [[0, "#E5721A"], [0.5, "#FFFFFF"], [1, "#006ECD"]];

interface Props {
  spec: ChartSpec;
  dataset?: Dataset;
  height?: number;
  onPick?: (p: { id: string; x: any; y: any }) => void;
}

type Fig = { data: any[]; layout: any };

const lab = (fields: Field[], k?: string) => (k ? fields.find((f) => f.key === k)?.label ?? k : "");
const ftype = (fields: Field[], k?: string) => fields.find((f) => f.key === k)?.type;

function axis(title: string, extra: any = {}) {
  return { title: { text: title, font: { size: 11, color: INK2 } }, gridcolor: GRID, zeroline: false, linecolor: "#D0D0D0",
           tickfont: { size: 10, color: INK2 }, automargin: true, ...extra };
}

function baseLayout(height: number, extra: any = {}) {
  return {
    height, autosize: true, margin: { l: 52, r: 14, t: 10, b: 40 }, paper_bgcolor: "rgba(0,0,0,0)", plot_bgcolor: "rgba(0,0,0,0)",
    font: { family: '"IBM Plex Sans KR", "Apple SD Gothic Neo", sans-serif', size: 11, color: "#1d1d1b" },
    showlegend: false, legend: { orientation: "h", y: 1.14, x: 0, font: { size: 10.5 } }, hovermode: "closest",
    hoverlabel: { font: { family: '"IBM Plex Sans KR", sans-serif', size: 11 } }, bargap: 0.35, ...extra,
  };
}

const hline = (y: number, color: string, dash = "solid", width = 1) =>
  ({ type: "line", xref: "paper", x0: 0, x1: 1, y0: y, y1: y, line: { color, width, dash } });

function groupKeys(vals: any[]): string[] {
  return [...new Set(vals.map((v) => String(v ?? "-")))].sort();
}

/** spec.type에 맞는 Plotly 데이터와 레이아웃을 만든다. 행 선택·집계·계열 나누기를 여기서 처리하고, 알 수 없는 타입이면 빈 그림을 돌려준다.
 *  입력: spec — 차트 spec, t — 로드한 테이블(열 단위), fields — 필드 목록, height — 높이(px), idKey — 점 id로 쓸 열(없으면 null)  반환: { data, layout } (Plotly 그림) */
function build(spec: ChartSpec, t: Table, fields: Field[], height: number, idKey?: string | null): Fig {
  const idx = rowIndex(t, spec);
  const col = (k?: string) => (k ? idx.map((i) => t.columns[k]?.[i]) : []);
  const idv = idKey && t.columns[idKey] ? col(idKey).map((v) => String(v)) : null;  // 점 하나 = 행 하나 (눌러서 설명)
  const xs = col(spec.x), ys = col(spec.y), cs = spec.color ? col(spec.color) : null;
  const xl = lab(fields, spec.x), yl = lab(fields, spec.y);
  const pct = spec.fmt === "pct";

  if (spec.type === "bar") {
    const xT = ftype(fields, spec.x);
    const xv = xT === "date" ? xs.map((d) => bucketOf(d, spec.bucket ?? "month")) : xs.map((v) => String(v ?? "-"));
    const groups = cs ? groupKeys(cs) : [""];
    const cats = spec.horizontal || !spec.agg ? [...new Set(xv)] : [...new Set(xv)].sort();
    const data = groups.map((g, gi) => {
      const vals = cats.map((c) => {
        const pick = idx.map((_, j) => j).filter((j) => xv[j] === c && (!cs || String(cs[j] ?? "-") === g));
        if (!spec.y || spec.agg === "count") return pick.length;
        return aggregate(pick.map((j) => ys[j]), spec.agg ?? "sum");  // 집계 미지정 = 이미 집계된 표(행 하나)
      });
      const colors = spec.sign_color ? vals.map((v) => (v >= 0 ? SERIES[0] : SPEC)) : SERIES[gi % SERIES.length];
      const tpl = pct ? "%{value:.1%}" : "%{value:.4~g}";
      return spec.horizontal
        ? { type: "bar", orientation: "h", y: cats, x: vals, name: g || yl, marker: { color: colors },
            hovertemplate: `%{y}<br>${g ? g + " · " : ""}${tpl}<extra></extra>` }
        : { type: "bar", x: cats, y: vals, name: g || yl, marker: { color: colors },
            hovertemplate: `%{x}<br>${g ? g + " · " : ""}${tpl}<extra></extra>` };
    });
    const vTitle = spec.y ? (spec.agg && spec.agg !== "count" ? `${yl} (${{ mean: "평균", median: "중앙값", sum: "합계" }[spec.agg]})` : yl) : `${unit()} 수`;
    const valAxis = axis(vTitle, pct ? { tickformat: ".0%" } : {});
    const catAxis = axis(spec.horizontal ? "" : xl, spec.horizontal ? { autorange: "reversed" } : { type: "category" });
    const h = spec.horizontal ? Math.max(height, cats.length * (groups.length > 1 ? 30 : 22) + 70) : height;
    return { data, layout: baseLayout(h, { barmode: "group", showlegend: groups.length > 1,
      xaxis: spec.horizontal ? valAxis : catAxis, yaxis: spec.horizontal ? catAxis : valAxis,
      shapes: spec.sign_color ? [{ type: "line", yref: "paper", y0: 0, y1: 1, x0: 0, x1: 0, line: { color: MUTED, width: 1 } }] : [] }) };
  }

  if (spec.type === "line") {
    const isDate = ftype(fields, spec.x) === "date";
    const groups = cs ? groupKeys(cs) : [""];
    const data = groups.map((g, gi) => {
      const pick = idx.map((_, j) => j).filter((j) => !cs || String(cs[j] ?? "-") === g);
      if (spec.bucket || spec.agg) {
        const m = new Map<string, number[]>();
        for (const j of pick) {
          const k = isDate ? bucketOf(xs[j], spec.bucket) : String(xs[j]);
          if (!m.has(k)) m.set(k, []);
          m.get(k)!.push(ys[j]);
        }
        const keys = [...m.keys()].sort();
        return { type: "scatter", mode: "lines+markers", x: keys, y: keys.map((k) => aggregate(m.get(k)!, spec.agg ?? "mean")), name: g || yl,
                 line: { width: 2, color: SERIES[gi % SERIES.length] }, marker: { size: 7, color: SERIES[gi % SERIES.length] } };
      }
      const order = pick.filter((j) => xs[j] != null && isNum(ys[j])).sort((a, b) => (xs[a] < xs[b] ? -1 : xs[a] > xs[b] ? 1 : 0));
      return { type: order.length > 1500 ? "scattergl" : "scatter", mode: "lines+markers", x: order.map((j) => xs[j]), y: order.map((j) => ys[j]),
               customdata: idv ? order.map((j) => idv[j]) : undefined,
               name: g || yl, line: { width: 1.5, color: SERIES[gi % SERIES.length] }, marker: { size: 4, color: SERIES[gi % SERIES.length] } };
    });
    return { data, layout: baseLayout(height, { showlegend: groups.length > 1, xaxis: axis(xl), yaxis: axis(spec.agg && spec.agg !== "mean" ? yl : yl) }) };
  }

  if (spec.type === "scatter") {
    const ok = idx.map((_, j) => j).filter((j) => isNum(xs[j]) && isNum(ys[j]));
    const gl = ok.length > 1500 ? "scattergl" : "scatter";
    let data: any[];
    const cT = ftype(fields, spec.color);
    if (cs && cT === "num") {
      data = [{ type: gl, mode: "markers", x: ok.map((j) => xs[j]), y: ok.map((j) => ys[j]), customdata: idv ? ok.map((j) => idv[j]) : undefined,
                marker: { size: 6, opacity: 0.75, color: ok.map((j) => cs[j]), colorscale: VALUE_SCALE, showscale: true,
                          colorbar: { thickness: 8, title: { text: lab(fields, spec.color), side: "right", font: { size: 10 } } } },
                hovertemplate: `${idv ? "%{customdata}<br>" : ""}${xl} %{x:.4~g}<br>${yl} %{y:.4~g}<extra></extra>` }];
    } else {
      const groups = cs ? groupKeys(cs) : [""];
      data = groups.map((g, gi) => {
        const p = ok.filter((j) => !cs || String(cs[j] ?? "-") === g);
        return { type: gl, mode: "markers", name: g || yl, x: p.map((j) => xs[j]), y: p.map((j) => ys[j]), customdata: idv ? p.map((j) => idv[j]) : undefined,
                 marker: { size: 6, opacity: 0.6, color: SERIES[gi % SERIES.length], line: { width: 0.5, color: "#fff" } },
                 hovertemplate: `${idv ? "%{customdata}<br>" : ""}${g ? g + "<br>" : ""}${xl} %{x:.4~g}<br>${yl} %{y:.4~g}<extra></extra>` };
      });
    }
    const shapes = (spec.refs ?? []).map((r) => (r.axis === "y" ? hline(r.value, MUTED) :
      { type: "line", yref: "paper", y0: 0, y1: 1, x0: r.value, x1: r.value, line: { color: MUTED, width: 1 } }));
    return { data, layout: baseLayout(height, { showlegend: !!cs && cT !== "num", xaxis: axis(xl), yaxis: axis(yl), shapes }) };
  }

  if (spec.type === "box") {
    const xT = ftype(fields, spec.x);
    const xv = spec.x ? xs.map((v) => (xT === "num" && new Set(xs).size <= 2 ? (v ? "해당" : "아님") : String(v ?? "-"))) : null;
    const cats = xv ? [...new Set(xv)].sort() : [""];
    const data = cats.map((c) => {
      const p = idx.map((_, j) => j).filter((j) => isNum(ys[j]) && (!xv || xv[j] === c));
      return { type: "box", name: c || yl, y: p.map((j) => ys[j]), boxpoints: false, marker: { color: SERIES[0] },
               line: { width: 1.5, color: SERIES[0] }, fillcolor: "rgba(0,110,205,0.14)" };
    });
    const shapes = (spec.refs ?? []).filter((r) => r.axis === "y").map((r) => hline(r.value, MUTED));
    return { data, layout: baseLayout(height, { xaxis: axis(xl, { type: "category" }), yaxis: axis(yl), shapes }) };
  }

  if (spec.type === "hist") {
    const groups = cs ? groupKeys(cs) : [""];
    const data = groups.map((g, gi) => ({
      type: "histogram", name: g || xl, x: idx.map((_, j) => j).filter((j) => isNum(xs[j]) && (!cs || String(cs[j] ?? "-") === g)).map((j) => xs[j]),
      nbinsx: spec.bins ?? 30, opacity: groups.length > 1 ? 0.6 : 0.9, marker: { color: SERIES[gi % SERIES.length] },
    }));
    const shapes = (spec.refs ?? []).filter((r) => r.axis === "x").map((r) => ({ type: "line", yref: "paper", y0: 0, y1: 1, x0: r.value, x1: r.value,
      line: { color: SIGNAL, width: 2 } }));
    const annotations = (spec.refs ?? []).filter((r) => r.axis === "x" && r.label).map((r) => ({ x: r.value, yref: "paper", y: 1, yanchor: "bottom",
      text: r.label, showarrow: false, font: { size: 10, color: SIGNAL } }));
    return { data, layout: baseLayout(height, { barmode: "overlay", bargap: 0.04, showlegend: groups.length > 1, xaxis: axis(xl), yaxis: axis(`${unit()} 수`),
      shapes, annotations, margin: { l: 52, r: 14, t: 18, b: 40 } }) };
  }

  if (spec.type === "bin") {
    const { labels, bin } = quantileBins(xs, spec.bins ?? 5);
    const stats = labels.map((_, b) => {
      const v = idx.map((_, j) => j).filter((j) => bin[j] === b && isNum(ys[j])).map((j) => ys[j] as number);
      const m = v.reduce((s, a) => s + a, 0) / (v.length || 1);
      const sd = v.length > 1 ? Math.sqrt(v.reduce((s, a) => s + (a - m) ** 2, 0) / (v.length - 1)) : 0;
      return { m, ci: (1.96 * sd) / Math.sqrt(Math.max(1, v.length)), n: v.length };
    });
    const lo = Math.min(...stats.map((s) => s.m - s.ci)), hi = Math.max(...stats.map((s) => s.m + s.ci));
    const pad = (hi - lo) * 0.2 || 1;
    return {
      data: [{ type: "scatter", mode: "lines+markers", x: labels, y: stats.map((s) => s.m), customdata: stats.map((s) => [s.ci, s.n]),
               error_y: { type: "data", array: stats.map((s) => s.ci), color: SERIES[0], thickness: 1.5, width: 4 },
               line: { color: "#BFD8F2", width: 2 }, marker: { size: 9, color: SERIES[0], line: { width: 2, color: "#fff" } },
               hovertemplate: `${xl} %{x}<br>${yl} 평균 %{y:.4~g} ± %{customdata[0]:.3~g}<br>%{customdata[1]}${unit()}<extra></extra>` }],
      layout: baseLayout(height, { xaxis: axis(`${xl} 5분위`, { type: "category", tickangle: -25 }), yaxis: axis(`${yl} 평균`, { range: [lo - pad, hi + pad] }) }),
    };
  }

  if (spec.type === "corr") {
    const fs = (spec.fields ?? []).filter((f) => t.columns[f]);
    const labels = fs.map((f) => lab(fields, f));
    const z = fs.map((a) => fs.map((b) => (a === b ? 1 : spearman(col(a), col(b)))));
    const h = Math.min(560, Math.max(height, fs.length * 30 + 110));
    return {
      data: [{ type: "heatmap", z, x: labels, y: labels, zmin: -1, zmax: 1, colorscale: CORR_SCALE, texttemplate: "%{z:.2f}",
               textfont: { size: 9.5 }, xgap: 2, ygap: 2, colorbar: { thickness: 8, len: 0.8 },
               hovertemplate: "%{y} · %{x}<br>%{z:.2f}<extra></extra>" }],
      layout: baseLayout(h, { margin: { l: 130, r: 10, t: 10, b: 110 }, xaxis: axis("", { tickangle: -40, showgrid: false }),
                              yaxis: axis("", { autorange: "reversed", showgrid: false }) }),
    };
  }

  if (spec.type === "beeswarm") {
    const fs = (spec.fields ?? []).filter((f) => t.columns[`shap:${f}`]);
    const X: number[] = [], Y: number[] = [], Cc: (number | null)[] = [], H: string[] = [], ID: string[] = [];
    fs.forEach((f, k) => {
      const s = col(`shap:${f}`), v = col(f);
      const step = Math.max(1, Math.floor(s.length / 900));
      const pts = s.map((x, j) => [x, j] as [number, number]).filter((p, j) => isNum(p[0]) && j % step === 0);
      const vs = pts.map(([, j]) => v[j]).filter(isNum).sort((a, b) => a - b);
      const pctOf = (x: number) => {
        let lo = 0, hi = vs.length;
        while (lo < hi) { const m = (lo + hi) >> 1; if (vs[m] < x) lo = m + 1; else hi = m; }
        return vs.length > 1 ? lo / (vs.length - 1) : 0.5;
      };
      const mn = Math.min(...pts.map((p) => p[0])), mx = Math.max(...pts.map((p) => p[0]));
      const nb = 70, w = (mx - mn) / nb || 1;
      const counts = new Map<number, number>();
      const maxc = Math.max(1, ...pts.reduce((m, [x]) => { const b = Math.floor((x - mn) / w); m.set(b, (m.get(b) ?? 0) + 1); return m; }, new Map<number, number>()).values());
      const amp = 0.36 / Math.max(1, maxc / 2);
      for (const [x, j] of pts) {
        const b = Math.floor((x - mn) / w);
        const c = counts.get(b) ?? 0;
        counts.set(b, c + 1);
        X.push(x);
        Y.push(k + (c % 2 ? 1 : -1) * Math.ceil(c / 2) * amp);
        Cc.push(isNum(v[j]) ? pctOf(v[j]) : null);
        H.push(`${idv ? idv[j] + "<br>" : ""}${lab(fields, f)}<br>값 ${isNum(v[j]) ? (+v[j]).toPrecision(4) : "-"} · 기여 ${x.toPrecision(3)}`);
        ID.push(idv ? idv[j] : "");
      }
    });
    const h = Math.max(height, fs.length * 30 + 70);
    return {
      data: [{ type: "scattergl", mode: "markers", x: X, y: Y, text: H, customdata: idv ? ID : undefined, hovertemplate: "%{text}<extra></extra>",
               marker: { size: 4.5, color: Cc, colorscale: VALUE_SCALE, cmin: 0, cmax: 1, opacity: 0.85,
                         colorbar: { thickness: 8, len: 0.6, tickvals: [0, 1], ticktext: ["낮음", "높음"], title: { text: "변수 값", side: "right", font: { size: 10 } } } } }],
      layout: baseLayout(h, { margin: { l: 150, r: 10, t: 10, b: 40 }, xaxis: axis("SHAP 기여 (목표 지표 단위)"),
                              yaxis: axis("", { tickvals: fs.map((_, k) => k), ticktext: fs.map((f) => lab(fields, f)), autorange: "reversed", showgrid: false }),
                              shapes: [{ type: "line", yref: "paper", y0: 0, y1: 1, x0: 0, x1: 0, line: { color: MUTED, width: 1 } }] }),
    };
  }

  if (spec.type === "waterfall") {
    const labels = xs.map((v) => String(v)), vals = ys.map((v) => Number(v) || 0);
    const start: number[] = [];
    let acc = spec.base ?? 0;
    for (const v of vals) { start.push(acc); acc += v; }
    const cats = ["평균 예측", ...labels, `이 ${unit()} 예측`];
    const fmt = (v: number) => (Math.abs(v) >= 100 ? v.toFixed(1) : v.toPrecision(3));
    const data: any[] = [
      { type: "bar", orientation: "h", y: cats, x: [spec.base ?? 0, ...vals.map(() => 0), spec.total ?? acc], base: 0,
        marker: { color: ["#BDBDBD", ...vals.map(() => "rgba(0,0,0,0)"), "#1d1d1b"] }, hoverinfo: "skip",
        text: [fmt(spec.base ?? 0), ...vals.map(() => ""), fmt(spec.total ?? acc)], textposition: "outside", cliponaxis: false },
      { type: "bar", orientation: "h", y: labels, x: vals, base: start, marker: { color: vals.map((v) => (v >= 0 ? SERIES[0] : SPEC)) },
        text: vals.map((v) => (v >= 0 ? "+" : "") + fmt(v)), textposition: "outside", cliponaxis: false,
        hovertemplate: "%{y}<br>기여 %{x:+.3~g}<extra></extra>" },
    ];
    const lo = Math.min(spec.base ?? 0, ...start, ...start.map((s0, k) => s0 + vals[k]), spec.total ?? acc);
    const hi = Math.max(spec.base ?? 0, ...start, ...start.map((s0, k) => s0 + vals[k]), spec.total ?? acc);
    const pad = (hi - lo) * 0.18 || 1;
    return { data, layout: baseLayout(Math.max(height, cats.length * 30 + 60), { barmode: "overlay", margin: { l: 150, r: 30, t: 10, b: 36 },
      xaxis: axis("예측 값", { range: [lo - pad, hi + pad] }), yaxis: axis("", { type: "category", categoryorder: "array", categoryarray: cats, autorange: "reversed" }) }) };
  }
  return { data: [], layout: baseLayout(height) };
}

/** 결과창에 보이는 차트를 그대로 이미지로 (PDF에 넣기 위해). */
export async function captureCharts(root: ParentNode): Promise<{ title: string; data_url: string }[]> {
  const out: { title: string; data_url: string }[] = [];
  for (const card of Array.from(root.querySelectorAll<HTMLElement>(".plot-card")).slice(0, 30)) {
    const el = card.querySelector<HTMLElement>(".plot");
    if (!el || !(el as any)._fullLayout || card.querySelector(".plot-state")) continue;
    try {
      const url = await Plotly.toImage(el as any, { format: "png", width: Math.max(480, el.clientWidth), height: Math.max(260, el.clientHeight), scale: 1.6 } as any);
      out.push({ title: card.querySelector("figcaption strong")?.textContent ?? "", data_url: url });
    } catch {
      /* 그리지 못한 차트는 건너뜀 */
    }
  }
  return out;
}

/** 차트 한 장. 데이터셋을 읽어 그림을 그리고, 로딩·빈 값·오류 상태 문구를 보인다. 점 클릭은 onPick으로 올린다.
 *  입력: spec — 차트 spec, dataset — 데이터셋 정의(없으면 오류 표시), height — 높이(px, 기본 260), onPick — 점 클릭 시 (id, x, y)를 받는 콜백  반환: 차트 JSX */
export default function PlotChart({ spec, dataset, height = 260, onPick }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const pickRef = useRef(onPick);
  pickRef.current = onPick;
  const [state, setState] = useState<"loading" | "ok" | "empty" | "error">("loading");
  const [err, setErr] = useState("");

  useEffect(() => {
    let alive = true;
    if (!dataset) {
      setState("error");
      setErr("데이터셋이 없습니다");
      return;
    }
    setState("loading");
    loadDataset(dataset)
      .then((t) => {
        if (!alive || !ref.current) return;
        const fig = build(spec, t, dataset.fields, height, dataset.id_field);
        const empty = !fig.data.length || fig.data.every((d) => !(d.x?.length || d.y?.length || d.z?.length));
        setState(empty ? "empty" : "ok");
        Plotly.react(ref.current, fig.data, fig.layout, {
          displaylogo: false, responsive: true, displayModeBar: "hover",
          modeBarButtonsToRemove: ["lasso2d", "select2d", "autoScale2d", "toggleSpikelines", "hoverCompareCartesian"],
          toImageButtonOptions: { filename: spec.title || spec.id, scale: 2 },
        } as any);
        const gd = ref.current as any;
        gd.removeAllListeners?.("plotly_click");
        if (dataset.id_field) gd.on?.("plotly_click", (ev: any) => {
          const pt = ev?.points?.[0];
          if (pt && typeof pt.customdata === "string" && pt.customdata) pickRef.current?.({ id: pt.customdata, x: pt.x, y: pt.y });
        });
      })
      .catch((e) => {
        if (!alive) return;
        setState("error");
        setErr(String(e?.message || e));
      });
    return () => {
      alive = false;
    };
  }, [spec, dataset, height]);

  useEffect(() => {
    const el = ref.current;
    // 카드 폭이 바뀌면(열 수 변경·대화창 크기 조절) 다시 맞춘다 — 창 크기 변화만 보는 responsive로는 부족
    let raf = 0;
    const ro = new ResizeObserver(() => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        if (el && (el as any)._fullLayout) Plotly.Plots.resize(el);
      });
    });
    if (el) ro.observe(el.parentElement ?? el);
    return () => {
      ro.disconnect();
      cancelAnimationFrame(raf);
      if (el) Plotly.purge(el);
    };
  }, []);

  return (
    <div className={`plot-wrap ${onPick && dataset?.id_field ? "pickable" : ""}`} style={{ minHeight: height }}>
      <div ref={ref} className="plot" />
      {state === "loading" && <div className="plot-state">차트를 그리는 중</div>}
      {state === "empty" && <div className="plot-state">표시할 값이 없습니다. 축이나 필터를 바꿔 보세요.</div>}
      {state === "error" && <div className="plot-state error">{err}</div>}
    </div>
  );
}
