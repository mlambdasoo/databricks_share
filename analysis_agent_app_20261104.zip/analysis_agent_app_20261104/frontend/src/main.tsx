/**
 * 앱 진입점: React 화면을 #root 요소에 붙인다.
 * 용도: 한국어 웹폰트와 전역 스타일을 불러오고, App 컴포넌트를 StrictMode로 렌더링한다.
 * 목적: 화면 시작 설정(폰트·CSS)과 실제 화면(App)을 나눠 두기 위함.
 */
import React from "react";
import ReactDOM from "react-dom/client";
import "@fontsource/ibm-plex-sans-kr/400.css";
import "@fontsource/ibm-plex-sans-kr/500.css";
import "@fontsource/ibm-plex-sans-kr/600.css";
import "./styles.css";
import App from "./App";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
