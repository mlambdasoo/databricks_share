/**
 * 화면이 받는 JSON 형식(공유 타입) 정의.
 * 용도: 분석 설정 패널·분석 결과·차트·대화 메시지 등 서버 응답과 화면 상태의 모양을 TypeScript 타입으로 정한다.
 * 목적: 기준은 app/common/ui_schema.json(블록 카탈로그)이다. 새 블록 종류는 카탈로그·이 파일·렌더러를 함께 고친다.
 */
export type Cfg = Record<string, any>;

/** 분석 설정 패널의 칸 하나 (skill이 정함, app/common/result_format.py의 field·step과 같은 형태). */
export interface PanelField {
  key: string;  // "filters.<컬럼>"이면 필터, 그 밖은 cfg 키
  label: string;
  type: "multi" | "choice" | "number" | "percent" | "daterange" | "rowchoice";
  value: any;
  options?: [any, string][];
  groups?: { label: string; options: [any, string][] }[];   // multi: 묶음별 칩
  store?: "excluded";                                        // multi: 값 = 뺀 것(칩이 켜져 있으면 사용)
  hint?: string;
  col?: string;
  min?: string | number;
  max?: string | number;
  step?: number;
  suffix?: string;
  max_label?: string;   // percent: 최댓값일 때 숫자 대신 보일 말(예: 빼지 않음)
  detail?: { summary: string; columns: string[]; rows: (string | number)[][] } | null;   // 칸 아래 펼쳐 보는 읽기 전용 표
  rows?: { key: string; label: string; info?: string; default?: string }[];   // rowchoice
  columns?: string[];
}

export interface SettingsStep {
  id: string;
  label: string;
  question: string;
  summary: string;
  fields: PanelField[];
  notes?: string[];
  tag?: string;
  warn?: boolean;
}

/** 분석 설정 패널 = 진단(지표·표) + 단계별 칸. 칸을 바꾸면 cfg를 보내 다시 받는다. */
export interface SettingsData {
  skill: string;
  run_tool: string;
  cfg: Cfg;
  title: string;
  subtitle: string;
  metrics: Metric[];
  sections: Section[];
  steps: SettingsStep[];      // 공통 단계(데이터 범위 → 전처리 → 변수 선택): 칸으로 바꾼다
  can_run: boolean;
  blockers: string[];
  from_result: boolean;
}

/** Genie 조회 결과(표·SQL). */
export interface Lookup {
  id: string;
  question: string;
  title: string;
  description?: string | null;
  sql?: string | null;
  columns: string[];
  rows: (string | number | null)[][];
  n_rows: number;
}

/** 작업 데이터(범위 + 공통 전처리를 적용한 데이터). 채운 칸 위치(filled: [행, 열])를 함께 보낸다. */
export interface WorkData {
  id: string;
  title: string;
  subtitle: string;
  applied: { label: string; value: string }[];
  log: string[];
  plan: { label: string; missing: string; method: string; reason: string }[];
  columns: string[];
  rows: (string | number | null)[][];
  filled: [number, number][];
  n_rows: number;
  n_filled: number;
  unit: string;
}

// ---------- 분석 결과 화면 형식 (모든 skill 공통, app/common/result_format.py와 같은 형태) ----------
export type Tone = "good" | "mid" | "bad" | "up" | "down" | "mixed" | "warn" | "info";

export interface Metric {
  label: string;
  value: string | number;
  unit?: string;
  note?: string;
  tone?: Tone;
}

export interface Col {
  key: string;
  label: string;
  type: "text" | "num" | "pct" | "bar" | "badge" | "rank";
  sub?: string;
  tone?: string;
  digits?: number;
  series?: number;
}

export type Section =
  | { type: "table"; id?: string; title?: string; columns: Col[]; rows: Record<string, any>[]; variant?: "ranking" | "matrix"; collapsed?: boolean }
  | { type: "cards"; title?: string; cards: { title: string; items?: { label: string; value: string }[]; error?: string }[] }
  | { type: "text"; title?: string; text: string; tone?: Tone };

export interface Field {
  key: string;
  label: string;
  type: "num" | "cat" | "date";
}

export interface Dataset {
  fields: Field[];
  url?: string;
  rows?: Record<string, any>[];
  editable?: boolean;
  id_field?: string | null;
}

export type ChartType = "bar" | "line" | "scatter" | "box" | "hist" | "bin" | "corr" | "beeswarm" | "waterfall";

export interface ChartSpec {
  id: string;
  type: ChartType;
  title?: string;
  dataset: string;
  x?: string;
  y?: string;
  color?: string;
  agg?: "mean" | "median" | "sum" | "count";
  bins?: number;
  bucket?: "day" | "week" | "month" | "quarter";
  fields?: string[];
  horizontal?: boolean;
  sign_color?: boolean;
  fmt?: "pct";
  span?: 1 | 2 | 3;
  refs?: { axis: "x" | "y"; value: number; label?: string }[];
  filter?: Record<string, string[]>;
  group?: string;
  tone?: Tone;
  base?: number;
  total?: number;
}

export interface ChartGroup {
  id: string;
  title: string;
  cols: number;
  note?: string;
  sections?: Section[];   // 대화로 덧붙인 묶음의 표(add_section)
  user?: boolean;         // 대화로 덧붙인 묶음
}

export interface View {
  id: string;
  label: string;
  sub?: string | null;
  run_id?: string;
  metrics: Metric[];
  sections: Section[];
  charts: ChartSpec[];
  chart_groups?: ChartGroup[];
  dataset?: string;
}

export interface Callout {
  tone: Tone;
  text: string;
  action?: { label: string; message: string };
}

export interface AnalysisResult {
  skill: string;
  skill_title?: string;   // 화면 이름표(skill 제목, 앱이 붙임)
  tag?: string;           // skill이 정한 이름표(예: 배치 설명)
  kind: "run" | "explain";
  run_id: string;
  title: string;
  subtitle: string;
  badge?: string;
  metrics: Metric[];
  callouts: Callout[];
  sections: Section[];
  views: View[];
  log: { label: string; detail: string }[];
  warnings: string[];
  cfg: Cfg;
  datasets: Record<string, Dataset>;
  pdf: boolean;
  settings: boolean;
  interpretation?: string;
  short?: string;
  compared_to?: string | null;
  target_label?: string | null;
  applied?: { label: string; value: string }[];   // 적용된 설정 (결과 맨 위)
  run_tool?: string;                              // 설정을 바꿔 다시 실행할 도구
}

export interface SourceItem {
  no?: number;
  name: string;
  short: string;
  kind: string;
  rows: number | null;
  n_cols: number | null;
  comment: string;
  label?: string;
  title?: string;
  meta?: string;
}

/** 첫 화면 기초 통계의 컬럼 한 줄(테이블 전체 SQL 집계). */
export interface StatCol {
  col: string;
  label: string;
  category?: string | null;
  role?: string | null;
  kind: "num" | "date" | "cat";
  missing: number;
  min?: number | string | null;
  mean?: number | null;
  max?: number | string | null;
  distinct?: number;
  top?: [string, number][];
  out_of_range?: number;          // 첫 제안 정상범위 밖 값 수
  normal?: [number, number];
  text_num?: { non_numeric: number; values: [string, number][] };  // 문자로 저장된 숫자: 숫자로 읽히지 않는 값 수와 값별 건수
}

export interface TableStats {
  rows: number;
  n_cols: number;
  date: { col: string; label: string; min: string; max: string } | null;
  columns: StatCol[];
}

/** 사용자가 바꾼 차트 배치 (기본 배치 위에 덮어씀). */
export interface Layout {
  removed: string[];
  overrides: Record<string, Partial<ChartSpec>>;
  added: ChartSpec[];
  cols: Record<string, number>;
}

/** 범위 [하한, 상한](한쪽은 null 가능). */
export type Range = [number | null, number | null] | null;

export interface Meta {
  conversation_id?: string;
  chosen?: boolean;            // 이 대화가 테이블을 정했는지(아니면 질문에 맞게 고른다)
  error?: string | null;
  source: string;
  model: string;
  title?: string;
  source_label?: string;
  unit?: string;
  ys?: string[];
  default_y: string;
  rows: number | null;
  dims: { col: string; label: string; values: string[] }[];
  date_dims: { col: string; label: string; min: string; max: string }[];
  skills?: { name: string; title: string; summary: string }[];
  sources?: SourceItem[];      // 등록 테이블 목록(Unity Catalog 메타데이터)
  examples?: string[];   // 첫 화면 예시 질문(그 테이블의 첫 제안이 있을 때만)
}

/** 시연 시나리오 하나: 고객 요건과, 순서대로 보낼 요청(이 테이블의 실제 값으로 채운 문장). */
export interface DemoScenario {
  id: string;
  title: string;
  needs: string[];
  steps: { ask: string; shows: string }[];
}

/** 오른쪽 패널에 여는 것: 대화에 오브젝트로 뜬 분석 설정·결과·조회 결과. */
export type Artifact =
  | { id: string; kind: "settings"; data: SettingsData; skill: string; from?: string }
  | { id: string; kind: "result"; data: AnalysisResult; layouts?: Record<string, Layout> }
  | { id: string; kind: "lookup"; data: Lookup }
  | { id: string; kind: "work"; data: WorkData };

/** 오른쪽 패널: 데이터(테이블 목록·기초 통계) 또는 오브젝트 하나. */
export type Panel = { kind: "data" } | { kind: "artifact"; id: string };

export type UIMsg =
  | { id: string; role: "user"; text: string; system?: boolean }
  | { id: string; role: "assistant"; text: string; streaming: boolean }
  | { id: string; role: "tool"; name: string; label: string; status: "running" | "done" | "error"; ms?: number; error?: string; progress?: string }
  | { id: string; role: "object"; artifactId: string; kind: "settings" | "result" | "lookup" | "work"; title: string; detail: string }
  | { id: string; role: "skill"; title: string }
  | { id: string; role: "source"; label: string; rows: number; unit?: string }
  | { id: string; role: "file"; name: string; url: string }
  | { id: string; role: "proposal"; artifactId: string; lines: string[]; skill: string; skillTitle?: string; runTool: string; cfg: Cfg;
      footer?: string; decided?: "run" }
  | { id: string; role: "notice"; level: "warn" | "error"; text: string };
