/**
 * 차트용 데이터 계산 유틸.
 * 용도: 결과 데이터셋(서버 URL 또는 인라인 행)을 컬럼형으로 읽고, 필터·집계·날짜 구간·분위 구간·상관을 계산한다.
 * 목적: 차트 설정을 바꿀 때마다 서버를 다시 부르지 않고, 화면에서 바로 계산하기 위함.
 * 끝부분: 화면 문구의 행 단위(unit)와 한국어 조사(josa · ro) 도우미.
 */
import type { ChartSpec, Dataset } from "./types";

export type Columns = Record<string, any[]>;
export interface Table {
  n: number;
  columns: Columns;
}

const cache = new Map<string, Promise<Table>>();

/** 데이터셋을 컬럼형 Table로 읽는다. 인라인 행은 바로 바꾸고, URL은 한 번만 받아 캐시에 둔다.
 *  입력: ds — 데이터셋(URL 또는 인라인 행)  반환: Table을 담은 Promise */
export function loadDataset(ds: Dataset): Promise<Table> {
  if (ds.rows) {
    const columns: Columns = {};
    for (const f of ds.fields) columns[f.key] = ds.rows.map((r) => r[f.key]);
    return Promise.resolve({ n: ds.rows.length, columns });
  }
  const url = ds.url!;
  if (!cache.has(url)) {
    cache.set(
      url,
      fetch(url).then(async (r) => {
        if (!r.ok) throw new Error(`데이터를 불러오지 못했습니다 (HTTP ${r.status})`);
        return (await r.json()) as Table;
      }),
    );
    cache.get(url)!.catch(() => cache.delete(url));
  }
  return cache.get(url)!;
}

/** spec.filter({필드: [값]})에 맞는 행 번호를 모은다.
 *  입력: t — 컬럼형 테이블, spec — 차트 설정(filter 사용)  반환: 조건에 맞는 행 번호 배열 */
export function rowIndex(t: Table, spec: ChartSpec): number[] {
  const idx: number[] = [];
  const f = Object.entries(spec.filter ?? {});
  outer: for (let i = 0; i < t.n; i++) {
    for (const [k, vals] of f) if (!vals.includes(String(t.columns[k]?.[i]))) continue outer;
    idx.push(i);
  }
  return idx;
}

export const isNum = (v: any) => typeof v === "number" && Number.isFinite(v);

/** 값 배열을 집계한다. count는 전체 개수, 그 밖은 숫자 값만 쓴다.
 *  입력: vals — 값 배열, how — "count"·"sum"·"median", 그 밖은 평균  반환: 집계 값 (숫자가 하나도 없으면 NaN) */
export function aggregate(vals: number[], how: string): number {
  const v = vals.filter(isNum);
  if (how === "count") return vals.length;
  if (!v.length) return NaN;
  if (how === "sum") return v.reduce((a, b) => a + b, 0);
  if (how === "median") {
    const s = [...v].sort((a, b) => a - b);
    const m = Math.floor(s.length / 2);
    return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
  }
  return v.reduce((a, b) => a + b, 0) / v.length;
}

/** 날짜 문자열을 구간 이름으로 바꾼다. 주는 그 주 월요일 날짜, 분기는 "2026 Q1" 형식.
 *  입력: d — 날짜 문자열, b — 구간 "week"·"month"·"quarter"(없거나 "day"면 그대로)  반환: 구간 문자열 */
export function bucketOf(d: string, b?: string): string {
  if (!d || !b || b === "day") return d;
  const dt = new Date(d + (d.length <= 10 ? "T00:00:00" : ""));
  const y = dt.getFullYear();
  const m = dt.getMonth();
  if (b === "month") return `${y}-${String(m + 1).padStart(2, "0")}`;
  if (b === "quarter") return `${y} Q${Math.floor(m / 3) + 1}`;
  const day = (dt.getDay() + 6) % 7;
  const mon = new Date(dt);
  mon.setDate(dt.getDate() - day);
  return mon.toISOString().slice(0, 10);
}

/** 수치 값을 q개 분위 구간으로 나눈다(pandas qcut과 같은 방식, 중복 경계는 제거).
 *  입력: x — 값 배열, q — 구간 수  반환: 구간 이름 목록(labels)과 행마다 구간 번호(bin, 숫자가 아니면 null) */
export function quantileBins(x: number[], q: number): { labels: string[]; bin: (number | null)[] } {
  const s = x.filter(isNum).sort((a, b) => a - b);
  if (!s.length) return { labels: [], bin: x.map(() => null) };
  const at = (p: number) => {
    const pos = (s.length - 1) * p;
    const lo = Math.floor(pos);
    return s[lo] + (s[Math.min(lo + 1, s.length - 1)] - s[lo]) * (pos - lo);
  };
  const edges = [...new Set(Array.from({ length: q + 1 }, (_, i) => at(i / q)))];
  const fmt = (v: number) => (Math.abs(v) >= 100 ? v.toFixed(0) : Math.abs(v) >= 10 ? v.toFixed(1) : v.toPrecision(3));
  const labels = edges.slice(1).map((e, i) => `${fmt(edges[i])}–${fmt(e)}`);
  const bin = x.map((v) => {
    if (!isNum(v)) return null;
    for (let i = 1; i < edges.length; i++) if (v <= edges[i]) return i - 1;
    return edges.length - 2;
  });
  return { labels, bin };
}

function ranks(v: number[]): number[] {
  const order = v.map((x, i) => [x, i] as const).sort((a, b) => a[0] - b[0]);
  const r = new Array(v.length);
  for (let i = 0; i < order.length; ) {
    let j = i;
    while (j + 1 < order.length && order[j + 1][0] === order[i][0]) j++;
    for (let k = i; k <= j; k++) r[order[k][1]] = (i + j) / 2;
    i = j + 1;
  }
  return r;
}

function pearson(a: number[], b: number[]): number {
  const n = a.length;
  if (n < 3) return NaN;
  const ma = a.reduce((s, v) => s + v, 0) / n;
  const mb = b.reduce((s, v) => s + v, 0) / n;
  let num = 0, da = 0, db = 0;
  for (let i = 0; i < n; i++) {
    num += (a[i] - ma) * (b[i] - mb);
    da += (a[i] - ma) ** 2;
    db += (b[i] - mb) ** 2;
  }
  return da && db ? num / Math.sqrt(da * db) : NaN;
}

/** 두 컬럼 모두 값이 있는 행으로 Spearman 상관계수를 구한다.
 *  입력: x, y — 컬럼 값 배열  반환: 상관계수(-1~1) 또는 NaN */
export function spearman(x: any[], y: any[]): number {
  const a: number[] = [], b: number[] = [];
  for (let i = 0; i < x.length; i++) if (isNum(x[i]) && isNum(y[i])) { a.push(x[i]); b.push(y[i]); }
  return pearson(ranks(a), ranks(b));
}

// ----------------------------------------------------------------------------- 화면 문구: 행 단위 · 조사

/** 지금 고른 테이블의 행 단위(식별자 컬럼 표시명에서, 예: "배치 ID" → "배치". 없으면 "행").
 *  화면 문구는 데이터마다 다를 수 있어 고정 단어 대신 이 값을 쓴다. App이 첫 화면 정보를 받을 때 정한다. */
let UNIT = "행";
export const setUnit = (u?: string | null) => { UNIT = u || "행"; };
export const unit = () => UNIT;

/** 받침에 맞는 조사: josa("배치", "을를") → "배치를", josa("수율(%)", "이가") → "수율(%)이". 끝의 괄호(단위)는 건너뛰고 본다. */
export function josa(word: string, pair: string): string {
  const base = word.replace(/\s*\([^()]*\)\s*$/, "").trim() || word;
  const ch = base[base.length - 1] ?? " ";
  const code = ch.charCodeAt(0);
  const has = code >= 0xac00 && code <= 0xd7a3 ? (code - 0xac00) % 28 > 0 : "013678LMNRlmnr".includes(ch);
  return word + (has ? pair[0] : pair[1]);
}

/** "(으)로": 받침이 없거나 ㄹ 받침이면 "로", 아니면 "으로". ro("평균") → "평균으로", ro("상수") → "상수로". */
export function ro(word: string): string {
  const base = word.replace(/\s*\([^()]*\)\s*$/, "").trim() || word;
  const ch = base[base.length - 1] ?? " ";
  const code = ch.charCodeAt(0);
  const jong = code >= 0xac00 && code <= 0xd7a3 ? (code - 0xac00) % 28 : "036MNmn".includes(ch) ? 1 : 0;  // 1·7·8·L·R은 ㄹ 소리
  return word + (jong === 0 || jong === 8 ? "로" : "으로");
}
