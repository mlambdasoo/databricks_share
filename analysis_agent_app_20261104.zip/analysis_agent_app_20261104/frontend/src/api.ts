/**
 * 서버 호출 모음 (API 클라이언트).
 * 용도: /responses 스트리밍 대화 호출과, 분석 설정·데이터 목록·첫 화면 정보 같은 화면용 REST 호출을 담당한다.
 * 목적: URL과 요청 형식을 화면 코드가 몰라도 되도록 한 곳에 모은다.
 */
import type { Cfg, DemoScenario, Meta, SettingsData, SourceItem, TableStats } from "./types";

export type ServerEvent = { type: string; [k: string]: any };

/** 에이전트를 스트리밍으로 호출한다(표준 ResponsesAgent 엔드포인트 /responses). 글은 표준 이벤트(response.output_text.delta)로,
 *  화면에만 필요한 것(제안 카드·결과·진행 상태 등)은 같은 스트림의 사용자 정의 이벤트(type "ui")로 온다 — 화면 이벤트 형식으로 바꿔 넘긴다.
 *  입력: body — 대화 id·메시지 또는 action·화면 상태, onEvent — 이벤트마다 불리는 콜백, signal — 중단 신호(선택)  반환: 스트림이 끝나면 완료 */
export async function streamChat(
  body: { conversation_id?: string | null; message?: string; action?: Record<string, any>; screen?: Record<string, any> | null; label?: string },
  onEvent: (ev: ServerEvent) => void,
  signal?: AbortSignal,
): Promise<void> {
  const res = await fetch("/responses", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      input: [{ role: "user", content: body.message ?? body.label ?? "[화면에서 실행]" }],
      custom_inputs: { conversation_id: body.conversation_id, action: body.action, screen: body.screen, followups: true },
      stream: true,
    }),
    signal,
  });
  if (!res.ok || !res.body) throw new Error(`요청이 실패했습니다 (HTTP ${res.status})`);
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  let item: string | null = null;  // 지금 받는 글 항목(새 항목이면 새 답 말풍선)
  const handle = (ch: any) => {
    if (ch.type === "ui") onEvent(ch.ui);
    else if (ch.type === "response.output_text.delta") {
      if (ch.item_id !== item) {
        item = ch.item_id;
        onEvent({ type: "assistant_start" });
      }
      onEvent({ type: "text", text: ch.delta });
    } else if (ch.error) onEvent({ type: "error", message: String(ch.error) });
  };
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    let idx: number;
    while ((idx = buf.indexOf("\n\n")) >= 0) {
      const block = buf.slice(0, idx);
      buf = buf.slice(idx + 2);
      const line = block.split("\n").find((l) => l.startsWith("data:"));
      if (!line) continue;
      const data = line.slice(5).trim();
      if (data === "[DONE]") return;
      handle(JSON.parse(data));
    }
  }
}

async function postJson<T>(url: string, body: unknown): Promise<T> {
  const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  if (!res.ok) {
    let msg = `HTTP ${res.status}`;
    try {
      const j = await res.json();
      msg = j?.detail?.message || j?.detail || msg;
    } catch {
      /* 본문 없음 */
    }
    throw new Error(String(msg));
  }
  return res.json();
}

/** 분석 설정 패널을 이 cfg로 다시 계산한다(칸을 바꿀 때마다, 결과의 [설정 수정]).
 *  입력: conversation_id — 대화 id, skill — 분석 종류, cfg — 현재 설정, from_result — 결과에서 열었는지  반환: 설정 패널 데이터 Promise */
export const fetchSettings = (conversation_id: string | null, skill: string, cfg: Cfg, from_result = false) =>
  postJson<SettingsData>("/api/settings", { conversation_id, skill, cfg, from_result });

/** 결과 하나를 PDF 리포트로 만든다.
 *  입력: conversation_id — 대화 id, run_id — 결과 실행 id, images — 화면 차트 이미지 목록(제목·data URL, 선택)  반환: 파일 이름과 다운로드 URL의 Promise */
export const makePdf = (conversation_id: string, run_id: string, images: { title: string; data_url: string }[] = []) =>
  postJson<{ name: string; url: string; screen_charts: number }>("/api/pdf", { conversation_id, run_id, images });

/** 대화의 첫 화면 정보. 대화 id가 없으면 새 대화를 만든다(source를 주면 그 데이터로). 응답의 conversation_id를 계속 쓴다.
 *  입력: conversation_id — 대화 id 또는 null, source — 처음 고를 테이블(선택)  반환: 첫 화면 정보 Promise */
export const fetchMeta = async (conversation_id: string | null, source?: string | null): Promise<Meta> => {
  const q = new URLSearchParams();
  if (conversation_id) q.set("conversation_id", conversation_id);
  else if (source) q.set("source", source);
  const res = await fetch(`/api/meta${q.toString() ? `?${q}` : ""}`);
  if (!res.ok) throw new Error(`데이터 정보를 불러오지 못했습니다 (HTTP ${res.status})`);
  return res.json();
};

/** 데이터 선택기: Unity Catalog 태그로 등록한 테이블·파일 목록을 LLM 없이 받는다.
 *  입력: conversation_id — 대화 id(현재 선택 표시용, 없으면 null)  반환: 현재·기본 테이블, 태그, 목록의 Promise */
export const fetchSources = async (conversation_id: string | null) => {
  const res = await fetch(`/api/sources${conversation_id ? `?conversation_id=${encodeURIComponent(conversation_id)}` : ""}`);
  if (!res.ok) throw new Error(`데이터 목록을 불러오지 못했습니다 (HTTP ${res.status})`);
  return (await res.json()) as { current: string; default: string; tags: string[]; items: SourceItem[] };
};

/** 고른 소스로 대화를 바꾼다(대화 id가 없으면 새 대화). 그 소스의 첫 화면 정보와 소스 줄 이벤트를 받는다.
 *  입력: conversation_id — 대화 id 또는 null, source — 고른 테이블 이름  반환: 대화 id·첫 화면 정보·소스 줄의 Promise */
export const pickSource = (conversation_id: string | null, source: string) =>
  postJson<{ conversation_id: string; meta: Meta; event: { label: string; key: string; rows: number; unit?: string; examples?: string[] } | null }>(
    "/api/source", { conversation_id, source });

/** 데이터 패널의 기초 통계. 그 테이블을 볼 때만 서버가 전체 SQL로 집계한다.
 *  입력: table — 테이블 이름  반환: 기초 통계의 Promise */
export const fetchStats = async (table: string): Promise<TableStats> => {
  const res = await fetch(`/api/stats?table=${encodeURIComponent(table)}`);
  if (!res.ok) throw new Error(`기초 통계를 계산하지 못했습니다 (HTTP ${res.status})`);
  return res.json();
};

/** 시연 시나리오(서버의 demo_scenarios.yaml 대본). 계산 없이 바로 온다.
 *  입력 없음  반환: 시나리오 목록의 Promise */
export const fetchDemo = async (): Promise<{ scenarios: DemoScenario[] }> => {
  const res = await fetch("/api/demo");
  if (!res.ok) throw new Error(`시연 시나리오를 읽지 못했습니다 (HTTP ${res.status})`);
  return res.json();
};
