"""Genie Agent 호출: 기본 데이터 조회 · 집계(건수 · 평균 · 추이 · 순위 · 목록)를 전처리 없이 Genie가 SQL로 답하게 한다.

용도:
- Genie Agent에 질문을 보내고 완료될 때까지 기다린 뒤, 답 문장 · 실행된 SQL · 결과 행을 돌려준다.
- 앱 서비스 주체 권한으로 호출한다(Genie Agent CAN_RUN, 테이블 SELECT). Agent id는 앱 설정 GENIE_SPACE_ID.

목적: 원본 테이블 조회는 Genie가 맡고, 전처리 · 분석이 필요한 질문은 작업 데이터 쪽 skill이 맡는다(work.py 참고).

    ask(question, conversation_id=None) -> {"conversation_id", "text", "sql", "description", "columns", "rows", "n_rows", "status"}
"""
from __future__ import annotations

import os
import time

from databricks.sdk import WorkspaceClient

SPACE_ID = os.environ.get("GENIE_SPACE_ID", "")
MAX_ROWS = 200  # 화면·LLM에 넘길 최대 행 수 (전체 행 수는 따로 알림)
_W: WorkspaceClient | None = None


def _w() -> WorkspaceClient:
    global _W
    if _W is None:
        _W = WorkspaceClient()
    return _W


def ask(question: str, conversation_id: str | None = None, timeout: int = 180) -> dict:
    """Genie Agent에 질문을 보내고 답이 끝날 때까지 2초 간격으로 기다려 결과를 정리한다. 질문 하나에 보통 10~30초 걸린다.

    입력: question — 자연어 질문 · conversation_id — 이어 묻는 Genie 대화 id(없으면 새 대화) · timeout — 기다릴 최대 초(기본 180)
    반환: {"conversation_id", "status"(COMPLETED · FAILED · CANCELLED · QUERY_RESULT_EXPIRED · TIMEOUT), "text"(답 문장, 완료되지 않았으면 오류 또는 상태 문구), "sql"(실행한 SQL 또는 None), "description", "columns"(열 이름 목록), "rows"(최대 MAX_ROWS행), "n_rows"(전체 행 수)}
    예외: GENIE_SPACE_ID가 없으면 RuntimeError
    """
    if not SPACE_ID:
        raise RuntimeError("Genie Agent가 설정되지 않았습니다(GENIE_SPACE_ID).")
    w = _w()
    if conversation_id:
        m = w.genie.create_message(SPACE_ID, conversation_id, question)
    else:
        m = w.genie.start_conversation(SPACE_ID, question)
    cid, mid = m.conversation_id, m.message_id
    t0 = time.time()
    while True:  # 완료될 때까지 기다린다(질문 하나에 보통 10~30초)
        msg = w.genie.get_message(SPACE_ID, cid, mid)
        st = getattr(msg.status, "value", str(msg.status))
        if st in ("COMPLETED", "FAILED", "CANCELLED", "QUERY_RESULT_EXPIRED"):
            break
        if time.time() - t0 > timeout:
            st = "TIMEOUT"
            break
        time.sleep(2)
    out = {"conversation_id": cid, "status": st, "text": "", "sql": None, "description": None, "columns": [], "rows": [], "n_rows": 0}
    if st != "COMPLETED":
        out["text"] = (getattr(msg, "error", None) and str(msg.error)) or f"Genie 응답 상태: {st}"
        return out
    for a in msg.attachments or []:
        if a.text and a.text.content:
            out["text"] = (out["text"] + "\n" + a.text.content).strip()
        if a.query:
            out["sql"], out["description"] = a.query.query, a.query.description
            res = w.genie.get_message_attachment_query_result(SPACE_ID, cid, mid, a.attachment_id)
            sr = res.statement_response
            cols = [c.name for c in (sr.manifest.schema.columns or [])] if sr and sr.manifest and sr.manifest.schema else []
            data = (sr.result.data_array or []) if sr and sr.result else []
            out["columns"], out["rows"] = cols, data[:MAX_ROWS]
            out["n_rows"] = (sr.manifest.total_row_count if sr and sr.manifest and sr.manifest.total_row_count is not None else len(data))
    return out
