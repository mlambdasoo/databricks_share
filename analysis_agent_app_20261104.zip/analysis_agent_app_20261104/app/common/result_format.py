"""화면에 보이는 공통 값(여러 skill이 같이 쓰는 것)을 만드는 도우미 모듈.

용도:
- 적용된 설정의 공통 앞부분(데이터 · 필터 · 기간), 설정 패널의 데이터 범위 칸, 요청 요약 문장.
- 데이터셋 필드 목록, 사용자·LLM이 만든 차트 spec 검증, 설정 패널 묶음, 제안 카드.
목적: 화면 형식은 블록 카탈로그(app/common/ui_schema.json), 화면 구성은 skill마다 layout.yaml(app/common/layout.py가 그린다).
이 모듈은 값만 만든다. 여기 있는 값이 화면마다 달라지지 않게 한곳에서 관리한다.
"""
from __future__ import annotations

import json
import math

import numpy as np
import pandas as pd

from .data import IMPUTE_LABELS, is_datetime, is_num, label, na_rule_text


def grade_tone(grade):
    return {"양호": "good", "보통": "mid", "낮음": "bad"}.get(grade)


def field_type(s: pd.Series) -> str:
    if is_datetime(s):
        return "date"
    if is_num(s) or pd.api.types.is_bool_dtype(s):
        return "num"
    return "cat"


def fields_of(df: pd.DataFrame, smap, labels: dict | None = None) -> list:
    """데이터셋 필드 목록(화면의 필드 선택용)을 만든다. 표시 이름은 labels가 우선이고, 없으면 label()로 만든다.

    입력: df — 데이터, smap — {컬럼: 컬럼 정보 행}, labels — {컬럼: 표시 이름} 덮어쓰기(선택)
    반환: [{key, label, type}] list (type은 field_type 결과)
    """
    labels = labels or {}
    return [{"key": c, "label": labels.get(c) or label(c, smap), "type": field_type(df[c])} for c in df.columns]


def _clean(v):
    if v is None:
        return None
    if isinstance(v, (float, np.floating)):
        if math.isnan(v) or math.isinf(v):
            return None
        return float(f"{float(v):.6g}")
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (pd.Timestamp,)):
        return v.strftime("%Y-%m-%d") if v.hour == 0 and v.minute == 0 else v.isoformat()
    if hasattr(v, "isoformat"):
        return v.isoformat()
    if isinstance(v, (np.bool_,)):
        return bool(v)
    return v


def columnar(df: pd.DataFrame) -> dict:
    """데이터를 {컬럼: [값, ...]} 열 단위 dict로 바꾼다. NaN은 null, 실수는 유효숫자 6자리, 날짜는 ISO 문자열(날짜 열은 YYYY-MM-DD).

    입력: df — 데이터 DataFrame
    반환: {컬럼 이름: 값 list} dict
    """
    out = {}
    for c in df.columns:
        s = df[c]
        if pd.api.types.is_datetime64_any_dtype(s):
            out[c] = [None if pd.isna(v) else pd.Timestamp(v).strftime("%Y-%m-%d") for v in s]
        else:
            out[c] = [_clean(v) for v in s.tolist()]
    return out


EDITABLE_TYPES = {"bar", "line", "scatter", "box", "hist", "bin", "corr"}


def validate_chart(spec: dict, fields: list) -> list:
    """사용자·LLM이 만든 차트 spec을 데이터셋 필드로 검증한다. 통과하면 빈 list를 돌려준다.

    라벨 이름(예: "수율(%)")으로 쓴 x·y·color·fields는 필드 키로 바꿔 spec을 고친다. 바 · 선 차트에 y는 있는데
    agg가 없으면 agg="mean"을 넣는다(배치 단위 데이터는 평균으로 집계). fields는 키 목록 또는 None으로 정리한다.
    입력: spec — 차트 spec dict(type, x, y, color, fields, agg), fields — 데이터셋 필드 목록(fields_of 결과)
    반환: 오류 문장 list(없으면 통과). 부작용: spec을 위와 같이 고친다.
    """
    errs = []
    keys = {f["key"]: f for f in fields}
    by_label = {f["label"]: f["key"] for f in fields}
    t = spec.get("type")
    if t not in EDITABLE_TYPES:
        errs.append(f"차트 종류 '{t}'는 추가할 수 없습니다. 가능: {sorted(EDITABLE_TYPES)}")
    for k in ("x", "y", "color"):
        v = spec.get(k)
        if v and v not in keys:
            if v in by_label:
                spec[k] = by_label[v]
            else:
                import difflib
                near = difflib.get_close_matches(str(v), list(keys) + list(by_label), n=3, cutoff=0.3)
                errs.append(f"{k} 필드 '{v}'가 없습니다. 비슷한 필드: {near}")
    for v in spec.get("fields") or []:
        if v not in keys and v not in by_label:
            errs.append(f"fields의 '{v}'가 없습니다.")
    spec["fields"] = [by_label.get(v, v) for v in spec.get("fields") or []] or None
    if t in ("bar", "line") and spec.get("y") and not spec.get("agg"):
        spec["agg"] = "mean"  # 배치 단위 데이터는 기본 평균으로 집계
    need = {"bar": ["x"], "line": ["x", "y"], "scatter": ["x", "y"], "box": ["y"], "hist": ["x"], "bin": ["x", "y"],
            "corr": ["fields"]}.get(t, [])
    for k in need:
        if not spec.get(k):
            errs.append(f"{t} 차트에는 {k}가 필요합니다.")
    return errs


# ----------------------------------------------------------------------------- 요청 이해·결과 이름 (화면 표시용)

def period_text(d) -> str | None:
    """기간 조건을 짧은 표현으로 바꾼다. 같은 해 안에서 연도·분기·반기 단위면 "2026년", "2026년 3분기"처럼 줄이고,
    그 밖이면 양끝을 "2026-01-01–2026-06-30"처럼 쓴다. 끝이 없으면 "처음"·"끝"으로 채운다.

    입력: d — date_filter dict(start, end 키는 없어도 됨), 또는 None
    반환: 문자열, d가 없으면 None
    """
    if not d:
        return None
    s, e = d.get("start"), d.get("end")
    if s and e and s[:4] == e[:4]:
        y = s[:4]
        if s[5:] == "01-01" and e[5:] == "12-31":
            return f"{y}년"
        q = {("01-01", "03-31"): 1, ("04-01", "06-30"): 2, ("07-01", "09-30"): 3, ("10-01", "12-31"): 4}.get((s[5:], e[5:]))
        if q:
            return f"{y}년 {q}분기"
        if s[5:] == "01-01" and e[5:] == "06-30":
            return f"{y}년 상반기"
        if s[5:] == "07-01" and e[5:] == "12-31":
            return f"{y}년 하반기"
    return f"{s or '처음'}–{e or '끝'}"




# ----------------------------------------------------------------------------- 적용된 설정(결과 맨 위) · 설정 패널의 범위 칸

def applied_scope(cfg: dict, smap, source_name: str, period_label: str = "기간") -> list:
    """적용된 설정의 앞부분(모든 분석 공통)인 데이터 · 필터 · 기간 칸을 만든다.

    입력: cfg — 설정 dict(filters, date_filter), smap — {컬럼: 컬럼 정보 행}, source_name — 소스 표시 이름,
          period_label — 기간 칸의 이름(기본 "기간")
    반환: [{label, value}] 3개 list(데이터 · 필터 · 기간)
    """
    f = cfg.get("filters") or {}
    d = cfg.get("date_filter")
    return [{"label": "데이터", "value": source_name},
            {"label": "필터", "value": " · ".join(f"{label(c, smap)} {', '.join(map(str, v))}" for c, v in f.items()) or "없음 (전체)"},
            {"label": period_label, "value": f"{d.get('start') or '처음'} ~ {d.get('end') or '끝'} ({label(d['col'], smap)})" if d else "전체 기간"}]


# ----------------------------------------------------------------------------- 분석 설정 패널 (모든 skill 공통)
# 단계·칸 구성은 skill의 layout.yaml(settings), 칸 종류는 ui_schema.json의 field. 칸 key가 "filters.<컬럼>"이면 cfg.filters[컬럼].

def settings_payload(skill, run_tool, cfg, title, subtitle, metrics, steps, sections=None, can_run=True, blockers=None,
                     from_result=False) -> dict:
    """설정 패널 전체 dict를 만든다. steps는 공통 단계(칸으로 바꾼다). 분석에 특화된 설정은 LLM이 정하며 패널에 보이지 않는다.

    cfg는 화면이 칸을 바꿀 때마다 고쳐 다시 보내는 값이다(진단이 다시 계산된다).
    입력: skill — skill 이름, run_tool — 실행 도구 이름, cfg — 설정 dict, title · subtitle — 패널 제목 문장,
          metrics — 지표 목록, steps — 공통 단계 목록, sections — 추가 구역 목록(선택), can_run — 실행 가능 여부,
          blockers — 실행을 막는 이유 문장 목록(선택), from_result — 결과 화면에서 열었는지
    반환: 패널 dict. cfg는 JSON 왕복으로 복사되어(문자열로 바꿀 수 없는 값은 str) 담긴다.
    """
    out = {"skill": skill, "run_tool": run_tool, "cfg": json.loads(json.dumps(cfg, default=str)), "title": title, "subtitle": subtitle,
           "metrics": metrics, "sections": sections or [], "steps": steps, "can_run": bool(can_run), "blockers": blockers or [],
           "from_result": from_result}
    return out


def proposal(view: dict, head="이렇게 분석해 볼게요", extra=None) -> dict:
    """제안 카드를 만든다. 설정 패널(view)을 줄인 것으로, 공통 단계 요약과 막는 이유, 지표 요약을 담는다.

    제안 이유는 LLM이 답 글에서 한 문장으로 따로 쓴다. 카드는 같은 패널 내용을 쓴다.
    입력: view — settings_payload 결과, head — 카드 제목 문장, extra — 제목 아래 덧붙일 줄 list(선택)
    반환: dict(skill, run_tool, cfg, lines, settings(= view), footer).
          lines는 제목 · extra · 단계 요약("- 라벨: 요약") · 막는 이유("- ⚠ …") 순서이고,
          footer는 지표 최대 3개를 "라벨 값단위"로 이어 붙인 문자열이다.
    """
    lines = [f"**{head}**"] + list(extra or [])
    lines += [f"- {s['label']}: {s['summary']}" for s in view.get("steps", [])]
    lines += [f"- ⚠ {b}" for b in view.get("blockers") or []]
    footer = " · ".join(f"{m['label']} {m['value']}{m.get('unit') or ''}" for m in view.get("metrics", [])[:3])
    return {"skill": view["skill"], "run_tool": view["run_tool"], "cfg": view["cfg"], "lines": lines, "settings": view, "footer": footer}
