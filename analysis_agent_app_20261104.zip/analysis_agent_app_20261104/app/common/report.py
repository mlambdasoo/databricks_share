"""PDF 리포트 — 앱에서 PDF를 만드는 곳은 여기 하나뿐이다.

용도: 실행기의 PDF 도구(save_pdf · 화면의 [PDF 저장])가 결과 하나를 A4 세로 보고서로 만든다.
  제목 · 부제 → 핵심 지표 · 적용된 설정(표) → 해석(마크다운: 굵은 제목 · bullet · 하위 bullet) → 표들 → 그림(한 쪽에 2개).
목적: 결과 종류(분석 · 한 건 설명 · 덧붙인 표)와 무관하게 같은 모양으로 만든다. skill은 PDF를 만들지 않고 넣을 표 · 그림만 넘긴다(tools.py의 report_parts).

    build(path, doc) -> path
    doc = {"title", "subtitle", "items": [(이름, 값)], "blocks": [
        {"type": "md", "title", "text"},                       # 해석 글(마크다운)
        {"type": "table", "title", "columns": [..], "rows": [[..]]},
        {"type": "images", "title", "paths": [..]}]}
"""
from __future__ import annotations

import re
import unicodedata

from common.plot import setup_font

W, H = 8.27, 11.69            # A4 세로(인치)
LEFT, RIGHT, TOP, BOTTOM = 0.07, 0.93, 0.95, 0.06   # 그림 좌표(0~1)
INK, INK2, LINE, HEAD_BG, ACCENT = "#1d1d1b", "#5a5a5a", "#d9d9d9", "#f2f2f2", "#006ecd"


_GLYPH = str.maketrans({"\u2212": "-", "\u2013": "-", "\u2014": "—", "\u00a0": " "})  # 폰트에 없는 기호 → 있는 기호


def _clean(s) -> str:
    return str(s).translate(_GLYPH)


def _units(s: str) -> float:
    """글자 폭(대략): 한글 · 전각 1, 그 밖 0.55."""
    return sum(1.0 if unicodedata.east_asian_width(ch) in "WF" else 0.55 for ch in s)


def _wrap(s: str, size: float, width: float) -> list:
    """폭(그림 좌표)에 맞게 줄을 나눈다. 띄어쓰기에서 먼저 끊고, 한 단어가 너무 길면 글자에서 끊는다."""
    per = width * W * 72 / (size * 1.02)   # 한 줄에 들어가는 글자 폭(한글 기준)
    out, cur = [], ""
    for word in s.split(" "):
        cand = (cur + " " + word) if cur else word
        if _units(cand) <= per:
            cur = cand
            continue
        if cur:
            out.append(cur)
        while _units(word) > per:   # 긴 단어
            k = 1
            while _units(word[:k + 1]) <= per:
                k += 1
            out.append(word[:k])
            word = word[k:]
        cur = word
    out.append(cur)
    return out


class _Doc:
    """쪽을 넘기며 위에서 아래로 그린다(y는 그림 좌표, 위가 1)."""

    def __init__(self, pdf):
        self.pdf, self.fig, self.y, self.page = pdf, None, TOP, 0
        self._new()

    def _new(self):
        import matplotlib.pyplot as plt
        if self.fig is not None:
            self._footer()
            self.pdf.savefig(self.fig)
            plt.close(self.fig)
        self.fig = plt.figure(figsize=(W, H))
        self.page += 1
        self.y = TOP

    def _footer(self):
        self.fig.text(RIGHT, 0.03, str(self.page), ha="right", fontsize=8, color=INK2)

    def need(self, h: float):
        if self.y - h < BOTTOM:
            self._new()

    def gap(self, h: float):
        self.y -= h

    def line(self, s: str, size=10, weight="normal", color=INK, x=LEFT, width=None, bold_head: str | None = None):
        """한 문단(자동 줄바꿈). bold_head가 있으면 첫 줄 앞에 굵게 붙인다."""
        width = width or (RIGHT - x)
        lh = size * 1.55 / 72 / H
        s, bold_head = _clean(s), (_clean(bold_head) if bold_head else None)
        text = (bold_head + " " if bold_head else "") + s
        rows = _wrap(text, size, width)
        for i, r in enumerate(rows):
            self.need(lh)
            if i == 0 and bold_head and r.startswith(bold_head):
                t = self.fig.text(x, self.y, bold_head, fontsize=size, weight="bold", color=color, va="top")
                w = t.get_window_extent(self.fig.canvas.get_renderer()).width / (W * self.fig.dpi)
                self.fig.text(x + w + 0.006, self.y, r[len(bold_head):].strip(), fontsize=size, weight=weight, color=color, va="top")
            else:
                self.fig.text(x, self.y, r, fontsize=size, weight=weight, color=color, va="top")
            self.y -= lh

    def heading(self, s: str, size=12.5):
        self.need(0.06)
        self.gap(0.012)
        self.line(s, size=size, weight="bold")
        self.fig.add_artist(_hline(self.fig, self.y + 0.004))
        self.gap(0.01)

    def table(self, columns: list, rows: list, size=8.5):
        """표: 머리 줄 회색, 열 폭은 내용 길이로 나눈다(긴 칸은 줄을 나눈다)."""
        cols = [_clean(c) for c in columns]
        cells = [["-" if v is None else _clean(v) for v in r] for r in rows]
        need = [max([_units(cols[j])] + [_units(r[j]) for r in cells if j < len(r)]) for j in range(len(cols))]
        need = [min(max(n, 3), 28) for n in need]
        total = RIGHT - LEFT
        widths = [total * n / sum(need) for n in need]
        lh = size * 1.45 / 72 / H
        for k, r in enumerate([cols] + cells):
            wrapped = [_wrap(r[j] if j < len(r) else "", size, widths[j] - 0.01) for j in range(len(cols))]
            h = lh * max(len(w) for w in wrapped) + 0.008
            self.need(h)
            if k == 0:
                self.fig.add_artist(_rect(self.fig, LEFT, self.y - h, total, h, HEAD_BG))
            x = LEFT
            for j, w in enumerate(wrapped):
                for i, part in enumerate(w):
                    self.fig.text(x + 0.005, self.y - 0.004 - i * lh, part, fontsize=size, va="top",
                                  weight="bold" if k == 0 else "normal", color=INK2 if k == 0 else INK)
                x += widths[j]
            self.y -= h
            self.fig.add_artist(_hline(self.fig, self.y))
        self.gap(0.012)

    def images(self, paths: list):
        """그림: 폭에 맞추고, 한 쪽에 두 장까지(세로가 긴 그림은 한 장)."""
        import matplotlib.image as mpimg
        for p in paths:
            img = mpimg.imread(p)
            ih, iw = img.shape[:2]
            w = RIGHT - LEFT
            h = w * (ih / iw) * (W / H)
            max_h = (TOP - BOTTOM) / 2 - 0.02
            if h > max_h:   # 키 큰 그림은 높이에 맞춘다
                w, h = w * max_h / h, max_h
            self.need(h + 0.01)
            ax = self.fig.add_axes([LEFT + (RIGHT - LEFT - w) / 2, self.y - h, w, h])
            ax.imshow(img)
            ax.axis("off")
            self.y -= h + 0.015

    def close(self):
        import matplotlib.pyplot as plt
        self._footer()
        self.pdf.savefig(self.fig)
        plt.close(self.fig)


def _hline(fig, y):
    from matplotlib.lines import Line2D
    return Line2D([LEFT, RIGHT], [y, y], transform=fig.transFigure, color=LINE, lw=0.6)


def _rect(fig, x, y, w, h, color):
    from matplotlib.patches import Rectangle
    return Rectangle((x, y), w, h, transform=fig.transFigure, color=color, lw=0, zorder=0)


def _md(d: _Doc, text: str):
    """해석 마크다운을 그린다: '**제목**' 줄 → 소제목, '- ' → bullet, '  - ' → 하위 bullet, '|' 줄 묶음 → 표. 코드 울타리는 뺀다."""
    lines = [l for l in text.splitlines() if not l.strip().startswith("```")]
    i = 0
    while i < len(lines):
        raw = lines[i].rstrip()
        if raw.strip().startswith("|"):  # 마크다운 표
            block = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                if not re.match(r"^\|?\s*:?-{2,}", lines[i].strip()):
                    block.append([c.strip() for c in lines[i].strip().strip("|").split("|")])
                i += 1
            if block:
                d.table(block[0], block[1:])
            continue
        i += 1
        if not raw.strip():
            d.gap(0.006)
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        s = raw.strip()
        m = re.match(r"^\*\*(.+?)\*\*\s*(.*)$", s)
        if m and not m.group(2):  # 굵은 줄만 = 소제목
            d.gap(0.006)
            d.line(m.group(1), size=10.5, weight="bold", color=ACCENT)
            continue
        bullet = s.startswith(("- ", "* "))
        if bullet:
            s = s[2:]
        head = None
        m = re.match(r"^\*\*(.+?)\*\*\s*(.*)$", s)
        if m:
            head, s = m.group(1), m.group(2)
        s = re.sub(r"\*\*|`|^#+\s*", "", s)
        level = 1 if bullet and indent >= 2 else 0
        x = LEFT + (0.035 + 0.03 * level if bullet else 0)
        if bullet:
            d.need(0.02)
            d.fig.text(x - 0.018, d.y, "•" if level == 0 else "–", fontsize=9.5, color=INK2, va="top")
        d.line(s, size=9.5 if bullet else 10, x=x, bold_head=head, color=INK if level == 0 else INK2)


def build(path: str, doc: dict) -> str:
    """doc 내용으로 PDF를 만든다.

    입력: path — 저장 경로, doc — {"title", "subtitle", "items": [(이름, 값)], "blocks": [...]}(모듈 설명 참고)
    반환: path. 빈 블록(표에 행이 없음 · 그림이 없음 · 글이 빔)은 건너뛴다.
    """
    from matplotlib.backends.backend_pdf import PdfPages
    setup_font()
    with PdfPages(path) as pdf:
        d = _Doc(pdf)
        d.line(doc.get("title") or "분석 결과", size=16, weight="bold")
        if doc.get("subtitle"):
            d.line(doc["subtitle"], size=9.5, color=INK2)
        d.gap(0.01)
        if doc.get("items"):
            d.heading("분석 개요")
            d.table(["항목", "내용"], [[a, b] for a, b in doc["items"]], size=8.5)
        for b in doc.get("blocks") or []:
            if b["type"] == "md" and (b.get("text") or "").strip():
                d.heading(b.get("title") or "해석")
                _md(d, b["text"])
            elif b["type"] == "table" and b.get("rows"):
                d.heading(b.get("title") or "표", size=11.5)
                d.table(b["columns"], b["rows"])
            elif b["type"] == "images" and b.get("paths"):
                d.heading(b.get("title") or "차트")
                d.images(b["paths"])
        d.close()
    return path
