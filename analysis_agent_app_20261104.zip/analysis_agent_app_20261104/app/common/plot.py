"""PDF·정적 차트용 matplotlib 공통 설정 (화면 차트는 프론트엔드가 데이터로 직접 그린다).

용도:
- 한글 폰트 등록(설치된 폰트 → 동봉 폰트 순), 차트 격자 크기 계산, PNG 저장.
- PDF 페이지 추가: 텍스트 페이지, 이미지 한 장씩 한 쪽, 이미지 여러 장을 한 쪽에 격자로.
목적: matplotlib은 PDF 보고서 출력에서만 쓴다. 화면 차트는 데이터로 프론트엔드가 그리므로 이 모듈과 무관하다.
"""
from __future__ import annotations

import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))

# 기본 블루 #006ECD(기본 계열) · 오렌지 #FF9700 · 레드 #EF151E(이상 신호·경고 전용, 계열 색으로 쓰지 않음)
PALETTE = {"bar": "#006ECD", "low": "#006ECD", "mid": "#E3E3E3", "high": "#E5721A", "neg": "#E5721A",
           "signal": "#EF151E", "muted": "#9AA0A6",
           "groups": ["#006ECD", "#FF9700", "#00843D", "#6B4FA3", "#00A0B0", "#B35A1F"]}
KOREAN_FONTS = ["NanumGothic", "NanumBarunGothic", "Noto Sans CJK KR", "Noto Sans KR",
                "Malgun Gothic", "AppleGothic", "Apple SD Gothic Neo"]
_FONT_OK = None


def setup_font():
    """matplotlib에 한글 폰트를 등록한다. 한 번 정하면 결과를 캐시한다.

    순서: 시스템에 설치된 한글 폰트 → 동봉 폰트(fonts/NanumGothic-subset.ttf, 앱 컨테이너에는 한글 폰트가 없다).
    음수 기호는 유니코드 대신 하이픈(-)으로 쓴다.
    입력: 없음
    반환: 한글 폰트를 등록했으면 True, 실패하면 False. 부작용: matplotlib 백엔드를 Agg로 바꾸고 rcParams를 설정한다.
    """
    global _FONT_OK
    if _FONT_OK is not None:
        return _FONT_OK
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    plt.rcParams["axes.unicode_minus"] = False
    names = {f.name for f in font_manager.fontManager.ttflist}
    for f in KOREAN_FONTS:
        if f in names:
            plt.rcParams["font.family"] = f
            _FONT_OK = True
            return True
    try:
        ttf = os.path.join(HERE, "fonts", "NanumGothic-subset.ttf")
        font_manager.fontManager.addfont(ttf)
        plt.rcParams["font.family"] = font_manager.FontProperties(fname=ttf).get_name()
        _FONT_OK = True
    except Exception:
        _FONT_OK = False
    return _FONT_OK


def grid(n, ncols=3):
    return max(1, int(np.ceil(n / ncols))), min(ncols, max(n, 1))


def save(fig, outdir, name):
    import matplotlib.pyplot as plt
    path = os.path.join(outdir, name)
    fig.savefig(path, dpi=130, bbox_inches="tight")
    plt.close("all")
    return path
