"""모든 분석 skill이 같이 쓰는 데이터 모듈: 소스 로드 · 필터 검증 · 컬럼 정보 · 공통 정리(문자열 숫자 변환, 정상범위, 결측 대치).

용도:
- 테이블(SQL 웨어하우스)이나 Volume 파일(CSV · parquet · xlsx · pkl)을 읽어 필터·기간 조건대로 자른다.
- 컬럼 정보(표시명 · 단위 · 역할 · 정상범위)를 읽어 변수 역할과 정상범위 규칙을 제공한다.
- 결측 대치, 화면 문구용 라벨, 조사(josa) 같은 공통 도우미를 함께 둔다.
목적: 분석마다 다른 것(X/Y 선택, 모델, 관리 한계 등)은 각 skill의 engine.py에 두고, 여기에는 같은 데이터라면
어떤 분석이든 같은 결과가 나와야 하는 부분만 둔다.
"""
from __future__ import annotations

import datetime as _dt
import difflib
import importlib.util
import io
import json
import threading
import os
import pickle
import re
import subprocess
import sys

import numpy as np
import pandas as pd

_CACHE: dict = {}


class PipelineError(Exception):
    """사용자에게 그대로 보여줄 수 있는 오류 (detail에 선택지·제안 포함).

    용도: 파이프라인 어디서든 사용자가 고칠 수 있는 문제를 알릴 때 던진다. 화면은 message를 보여 준다.
    주요 필드: message(표시 문장), detail(dict — hint · suggestions · available_columns 등 선택지와 제안).
    """

    def __init__(self, message, detail=None):
        super().__init__(message)
        self.detail = detail or {}


class SqlBackend:
    """Spark 세션이 없는 환경(Databricks Apps 등)용 데이터 어댑터.

    용도: 테이블은 SQL 웨어하우스(파라미터 바인딩)로, Volume 파일은 Files API로 읽는다.
    주요 필드: config(Databricks SDK 설정), warehouse_id(SQL 웨어하우스 ID).
    """

    _IDENT = re.compile(r"^[A-Za-z0-9_`\-]+(\.[A-Za-z0-9_`\-]+){2}$")

    def __init__(self, warehouse_id: str, config=None):
        from databricks.sdk.core import Config
        self.config = config or Config()
        self.warehouse_id = warehouse_id

    def _table(self, name):
        if not self._IDENT.match(name):
            raise PipelineError(f"테이블 이름 형식 오류: {name}", {"hint": "catalog.schema.table"})
        return ".".join(f"`{p.strip('`')}`" for p in name.split("."))

    def query(self, stmt, params=None) -> pd.DataFrame:
        """SQL 웨어하우스에 문장을 실행하고 결과를 pandas로 돌려준다. 연결은 호출할 때마다 열고 닫는다.

        입력: stmt — SQL 문(:이름 형식 파라미터 포함), params — 파라미터 값 dict(없으면 빈 dict)
        반환: 결과 DataFrame
        """
        from databricks import sql
        with sql.connect(server_hostname=self.config.host,
                         http_path=f"/sql/1.0/warehouses/{self.warehouse_id}",
                         credentials_provider=lambda: self.config.authenticate) as conn:
            with conn.cursor() as cur:
                cur.execute(stmt, params or {})
                return cur.fetchall_arrow().to_pandas()

    def columns(self, table) -> list:
        return list(self.query(f"SELECT * FROM {self._table(table)} LIMIT 0").columns)

    def table_df(self, table, filters, date_filter) -> pd.DataFrame:
        """필터와 기간 조건을 WHERE 절로 걸어 테이블을 읽는다. 값 비교는 문자열(CAST) 기준이다.

        입력: table — 테이블 이름, filters — {컬럼: [허용 값, ...]}, date_filter — {col, start, end} 또는 None
              (start·end는 없어도 된다. 날짜 기준으로 포함 범위를 건다)
        반환: 조건에 맞는 행 DataFrame
        """
        where, params = [], {}
        for i, (c, vals) in enumerate(filters.items()):
            marks = []
            for j, v in enumerate(vals):
                params[f"f{i}_{j}"] = str(v)
                marks.append(f":f{i}_{j}")
            where.append(f"CAST(`{c}` AS STRING) IN ({', '.join(marks)})")
        if date_filter:
            if date_filter.get("start"):
                params["d_start"] = date_filter["start"]
                where.append(f"to_date(`{date_filter['col']}`) >= to_date(:d_start)")
            if date_filter.get("end"):
                params["d_end"] = date_filter["end"]
                where.append(f"to_date(`{date_filter['col']}`) <= to_date(:d_end)")
        stmt = f"SELECT * FROM {self._table(table)}" + (" WHERE " + " AND ".join(where) if where else "")
        return self.query(stmt, params)

    def distinct(self, table, col, limit=500) -> list:
        df =self.query(f"SELECT DISTINCT CAST(`{col}` AS STRING) AS v FROM {self._table(table)} LIMIT {int(limit)}")
        return df["v"].dropna().tolist()

    def read_bytes(self, path) -> bytes:
        from databricks.sdk import WorkspaceClient
        return WorkspaceClient(config=self.config).files.download(path).contents.read()


# ----------------------------------------------------------------------------- config

def normalize_common(cfg: dict) -> dict:
    """공통 키를 정리한다: source 필수, filters 값은 목록으로, 빈 값(None · "" · [])인 필터는 뺀다.

    빈 목록 = 필터 없음(앞선 범위를 푸는 표현). date_filter가 있으면 col이 있어야 한다.
    입력: cfg — 설정 dict(source, filters, date_filter)
    반환: 정리된 같은 cfg 객체(filters를 바꿔 넣는다). source가 없거나 date_filter 형식이 틀리면 PipelineError.
    """
    if not cfg.get("source"):
        raise PipelineError("데이터 소스(source)가 없습니다.", {"hint": "{'table': 'c.s.t'} 또는 {'path': '...'}"})
    cfg["filters"] = {c: (v if isinstance(v, list) else [v]) for c, v in (cfg.get("filters") or {}).items()
                      if v not in (None, "", [])}  # 빈 목록 = 필터 없음(앞선 범위를 푸는 표현)
    d = cfg.get("date_filter")
    if d is not None and (not isinstance(d, dict) or not d.get("col")):
        raise PipelineError("date_filter 형식 오류", {"hint": "{'col': 컬럼, 'start': 'YYYY-MM-DD', 'end': 'YYYY-MM-DD'}"})
    return cfg


# ----------------------------------------------------------------------------- load

SPEC_COLS = ["column_name", "display_name", "unit", "category", "role", "normal_min", "normal_max", "spec_min", "spec_max", "description"]
UC_SPEC = "uc:"  # spec_table = "uc:<catalog.schema.table>": 그 테이블의 컬럼 정보 · 첫 제안
# 공급자: 데이터 처리 skill의 첫 제안(proposal.py)이 끼운다. spec_frame(table) → 컬럼 정보 표 또는 None, table_meta(table) → {title, default_y, row_unit},
# key(table) → 캐시 키(제안이 오면 바뀐다). 공급자가 없거나 제안이 없으면 컬럼 설명만 담은 표(역할·범위 없음)를 쓴다.
spec_provider = None


def _comments_only(table: str, backend) -> pd.DataFrame:
    """첫 제안이 없을 때의 컬럼 정보 표: 컬럼 이름과 설명만. Unity Catalog REST로 읽는다(information_schema SQL보다 빠르다)."""
    cat, sch, tbl = [p.strip("`") for p in table.split(".")]
    try:
        from databricks.sdk import WorkspaceClient
        info = WorkspaceClient(config=backend.config).tables.get(f"{cat}.{sch}.{tbl}")
        rows = [(c.name, c.comment) for c in info.columns or []]
    except Exception:  # noqa: BLE001  (REST를 못 쓰면 SQL로)
        cols = backend.query(f"SELECT column_name, comment FROM `{cat}`.information_schema.columns "
                             "WHERE table_schema = :s AND table_name = :t ORDER BY ordinal_position", {"s": sch, "t": tbl})
        rows = [(r.column_name, r.comment) for r in cols.itertuples()]
    return pd.DataFrame([{"column_name": n, "description": c or None} for n, c in rows], columns=SPEC_COLS)


def load_spec(cfg, backend) -> pd.DataFrame:
    """설정의 spec_table로 컬럼 정보 표를 얻는다. 공급자(첫 제안)의 표를 우선 쓰고, 없으면 컬럼 설명만 담은 표를 쓴다.

    캐시 키에 제안 여부가 들어가므로 제안이 생기면 표를 새로 만든다.
    입력: cfg — 설정 dict(spec_table 키, "uc:" 접두사는 있어도 된다), backend — 데이터 어댑터
    반환: SPEC_COLS 형식 DataFrame(spec_table이 없으면 빈 표). 같은 키면 _CACHE를 재사용한다.
    """
    if not cfg.get("spec_table"):
        return pd.DataFrame(columns=SPEC_COLS)
    table = str(cfg["spec_table"]).removeprefix(UC_SPEC)
    key = ("spec", table, spec_provider.key(table) if spec_provider else None)
    if key in _CACHE:
        return _CACHE[key]
    spec = spec_provider.spec_frame(table) if spec_provider else None
    _CACHE[key] = spec if spec is not None else _comments_only(table, backend)
    return _CACHE[key]


def bounds(r) -> tuple | None:
    """컬럼 정보 한 줄에서 정상범위를 뽑는다.

    입력: r — 컬럼 정보 한 행(normal_min · normal_max 속성), None 가능
    반환: (하한, 상한) 실수 튜플(한쪽만 있으면 그쪽은 None). 둘 다 없거나 r이 None이면 None.
    """
    if r is None:
        return None
    lo, hi = (None if pd.isna(v) else float(v) for v in (r.normal_min, r.normal_max))
    return None if lo is None and hi is None else (lo, hi)


def out_of(s: pd.Series, rng) -> pd.Series:
    """정상범위 (하한, 상한) 밖인 값을 표시한다. 한쪽이 None이면 그쪽은 보지 않는다. 결측은 표시하지 않는다.

    입력: s — 수치 Series, rng — (하한, 상한)
    반환: 범위 밖이면 True인 bool Series
    """
    lo, hi = rng
    bad = pd.Series(False, index=s.index)
    if lo is not None:
        bad |= s < lo
    if hi is not None:
        bad |= s > hi
    return s.notna() & bad


def bounds_of(col, smap, overrides: dict | None = None) -> tuple | None:
    """변수 하나의 정상범위를 정한다. 대화에서 고친 범위가 있으면 그 값, 없으면 첫 제안(컬럼 정보)을 쓴다.

    overrides는 cfg normal_by_col이다({컬럼: [하한, 상한]}, null이면 범위 없음). 형식이 틀린 값도 범위 없음으로 본다.
    입력: col — 컬럼 이름, smap — {컬럼: 컬럼 정보 행}, overrides — normal_by_col dict 또는 None
    반환: (하한, 상한) 튜플. 범위가 없으면 None.
    """
    if overrides and col in overrides:
        rng = overrides[col]
        if not isinstance(rng, (list, tuple)) or len(rng) != 2 or all(v is None for v in rng):
            return None
        return tuple(None if v is None else float(v) for v in rng)
    return bounds(smap.get(col))


def roles(smap, cfg) -> dict:
    """컬럼마다 역할을 정한다. 대화에서 고친 역할(cfg var_roles)이 첫 제안 위에 덮인다.

    역할 값: id(식별자) · date(날짜) · dimension(범위 구분) · x(영향 요인) · y(목표 지표 후보) · result(결과 뒤 값) · text(메모).
    입력: smap — {컬럼: 컬럼 정보 행}, cfg — 설정 dict(var_roles 키는 선택)
    반환: {컬럼: 역할 문자열 또는 None}
    """
    out = {c: getattr(r, "role", None) for c, r in smap.items()}
    out = {c: (v if isinstance(v, str) and v else None) for c, v in out.items()}
    out.update({c: v for c, v in ((cfg or {}).get("var_roles") or {}).items() if v})
    return out


def range_text(rng) -> str:
    lo, hi = rng
    return f"{lo:g}~{hi:g}" if lo is not None and hi is not None else f"{lo:g} 이상" if lo is not None else f"{hi:g} 이하"


def ensure_pkg(name):
    if importlib.util.find_spec(name) is not None:
        return
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--timeout", "15", name], check=True,
                       timeout=60, capture_output=True)
        importlib.invalidate_caches()
    except Exception:
        pass
    if importlib.util.find_spec(name) is None:
        raise PipelineError(f"'{name}' 패키지가 없어 이 파일 형식을 읽을 수 없습니다.",
                            {"hint": "CSV 또는 parquet으로 저장해 다시 올려주세요."})


_SUPPORTED = [".pkl", ".parquet", ".csv", ".xlsx"]


def read_path(path, backend):
    """파일 하나를 DataFrame으로 읽는다.

    로컬 경로는 바로 읽는다. 원격 경로(/Volumes/, dbfs:, s3://, abfss://, gs:// 또는 로컬에 없는 경로)는 backend 방식으로 읽는다.
    로컬 CSV는 UTF-8을 먼저 시도하고 실패하면 cp949로 다시 읽는다. pickle은 신뢰할 수 있는 출처의 파일만 쓴다.
    입력: path — 파일 경로, backend — SqlBackend 또는 Spark 세션을 감싼 어댑터
    반환: DataFrame. 지원하지 않는 확장자면 PipelineError.
    """
    ext = os.path.splitext(path)[1].lower()
    remote = path.startswith(("/Volumes/", "dbfs:", "s3://", "abfss://", "gs://")) or not os.path.exists(path)
    if ext not in (".pkl", ".pickle", ".parquet", ".csv", ".xlsx", ".xls"):
        raise PipelineError(f"지원하지 않는 파일 형식: {ext}", {"supported": _SUPPORTED})
    if not remote:
        if ext in (".pkl", ".pickle"):
            return pd.read_pickle(path)
        if ext == ".parquet":
            return pd.read_parquet(path)
        if ext in (".xlsx", ".xls"):
            ensure_pkg("openpyxl")
            return pd.read_excel(path)
        try:
            return pd.read_csv(path, encoding="utf-8-sig")
        except UnicodeDecodeError:
            return pd.read_csv(path, encoding="cp949")
    if isinstance(backend, SqlBackend):
        data = io.BytesIO(backend.read_bytes(path))
        if ext in (".pkl", ".pickle"):
            return pickle.loads(data.getvalue())  # 신뢰할 수 있는 출처의 파일만 사용
        if ext == ".parquet":
            return pd.read_parquet(data)
        if ext == ".csv":
            return pd.read_csv(data, encoding="utf-8-sig")
        ensure_pkg("openpyxl")
        return pd.read_excel(data)
    if ext == ".parquet":
        return backend.read.parquet(path).toPandas()
    if ext == ".csv":
        return backend.read.option("header", True).option("inferSchema", True).csv(path).toPandas()
    content = backend.read.format("binaryFile").load(path).select("content").head()[0]
    if ext in (".pkl", ".pickle"):
        return pickle.loads(bytes(content))  # 신뢰할 수 있는 출처의 파일만 사용
    ensure_pkg("openpyxl")
    return pd.read_excel(io.BytesIO(bytes(content)))


def check_filter_values(available: dict, cfg):
    """필터 값이 실제 값과 정확히 일치하는지 확인하고, 불일치 시 유사값을 제안한다.

    입력: available — {컬럼: 실제 값 목록}, cfg — 설정 dict(filters 사용)
    반환: {컬럼: {requested: 못 찾은 값, suggestions: {값: 유사값 최대 3개}, available: 값 최대 50개}}. 문제가 없으면 빈 dict.
    """
    problems = {}
    for col, vals in cfg["filters"].items():
        avail = [str(a) for a in available.get(col, [])]
        miss = [v for v in vals if str(v) not in avail]
        if miss:
            problems[col] = {"requested": miss,
                             "suggestions": {m: difflib.get_close_matches(str(m), avail, n=3, cutoff=0.3) for m in miss},
                             "available": avail[:50]}
    return problems


def require_cols(cols, available):
    missing = [c for c in cols if c not in available]
    if missing:
        raise PipelineError(f"데이터에 없는 컬럼: {missing}",
                            {"suggestions": {m: difflib.get_close_matches(m, available, n=3) for m in missing},
                             "available_columns": available})


def load(cfg, backend):
    """소스를 읽어 필터·기간 조건대로 행을 자른다. 같은 조건이면 _CACHE를 재사용한다. 필터 값이 틀린 결과는 캐시하지 않는다.

    입력: cfg — 정리된 설정(source, filters, date_filter), backend — 데이터 어댑터(SqlBackend 또는 Spark 세션)
    반환: (DataFrame, 필터 값 불일치 dict). 필터 컬럼이나 기간 컬럼이 데이터에 없으면 PipelineError.
    """
    key = ("data", json.dumps(cfg["source"], sort_keys=True), json.dumps(cfg["filters"], sort_keys=True),
           json.dumps(cfg.get("date_filter"), sort_keys=True))
    with _LOAD_LOCK:  # 같은 조건을 읽는 중이면(미리 읽기) 그것을 기다린다
        lock = _LOADING.setdefault(key, threading.Lock())
    with lock:
        if key in _CACHE:
            return _CACHE[key]
        return _load(cfg, key, backend)


_LOAD_LOCK = threading.Lock()
_LOADING: dict = {}


def _load(cfg, key, backend):
    src, dflt = cfg["source"], cfg.get("date_filter")
    fcols = list(cfg["filters"]) + ([dflt["col"]] if dflt else [])
    if "table" in src and isinstance(backend, SqlBackend):
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=2 + len(cfg["filters"])) as ex:  # 컬럼 · 필터 값 · 데이터를 동시에(SQL마다 연결을 열어 차례로 하면 느리다)
            fc = ex.submit(backend.columns, src["table"])
            fv = {c: ex.submit(backend.distinct, src["table"], c) for c in cfg["filters"]}
            fd = ex.submit(backend.table_df, src["table"], cfg["filters"], dflt)
            require_cols(fcols, fc.result())
            available = {c: f.result() for c, f in fv.items()}
            problems = check_filter_values(available, cfg)
            df = fd.result()
    elif "table" in src:
        from pyspark.sql import functions as F
        sdf = backend.table(src["table"])
        require_cols(fcols, sdf.columns)
        available = {c: [r[0] for r in sdf.select(c).distinct().limit(500).collect()] for c in cfg["filters"]}
        problems = check_filter_values(available, cfg)
        for c, vals in cfg["filters"].items():
            sdf = sdf.filter(F.col(c).cast("string").isin([str(v) for v in vals]))
        if dflt:
            if dflt.get("start"):
                sdf = sdf.filter(F.to_date(F.col(dflt["col"])) >= F.lit(dflt["start"]).cast("date"))
            if dflt.get("end"):
                sdf = sdf.filter(F.to_date(F.col(dflt["col"])) <= F.lit(dflt["end"]).cast("date"))
        df = sdf.toPandas()
    else:
        raw = read_path(src["path"], backend)
        require_cols(fcols, list(raw.columns))
        available = {c: sorted(raw[c].dropna().astype(str).unique().tolist())[:500] for c in cfg["filters"]}
        problems = check_filter_values(available, cfg)
        mask = pd.Series(True, index=raw.index)
        for c, vals in cfg["filters"].items():
            mask &= raw[c].astype(str).isin([str(v) for v in vals])
        if dflt:
            dcol = pd.to_datetime(raw[dflt["col"]], errors="coerce")
            if dflt.get("start"):
                mask &= dcol >= pd.Timestamp(dflt["start"])
            if dflt.get("end"):
                mask &= dcol < pd.Timestamp(dflt["end"]) + pd.Timedelta(days=1)
        df = raw[mask].reset_index(drop=True)
    out = (df, problems)
    if not problems:
        _CACHE[key] = out
    return out


# ----------------------------------------------------------------------------- spec helpers

EQUIP_CATS = {"설비", "장비", "equipment"}  # 분류가 이 값인 차원 = 설비 단위


def scope_dims(df, smap, exclude=()) -> list:
    """범위를 나누는 차원 컬럼 목록: 역할이 dimension이고, 날짜가 아니며, 값 종류가 2~50개인 컬럼.

    입력: df — 데이터, smap — {컬럼: 컬럼 정보 행}, exclude — 제외할 컬럼 목록(선택)
    반환: 컬럼 이름 list
    """
    return [c for c, r in smap.items() if getattr(r, "role", None) == "dimension" and c in df.columns and c not in exclude
            and not is_datetime(df[c]) and 2 <= df[c].nunique() <= 50]


def top_scope_dims(df, smap, exclude=()) -> list:
    """최상위 범위 차원만 고른다. 설비 분류 차원은 뺀다. 나머지 중에서도 다른 차원의 하위 구분
    (값마다 상위 값이 하나로 정해지고, 종류가 더 많은 차원)은 뺀다.

    입력: df — 데이터, smap — {컬럼: 컬럼 정보 행}, exclude — 제외할 컬럼 목록(선택, scope_dims와 같음)
    반환: 최상위 범위 차원 컬럼 list
    """
    dims = [c for c in scope_dims(df, smap, exclude) if str(getattr(smap.get(c), "category", "") or "").lower() not in EQUIP_CATS]
    nu = {c: df[c].nunique() for c in dims}
    return [c for c in dims if not any(o != c and 1 < nu[o] < nu[c] and int(df.groupby(c)[o].nunique().max()) == 1 for o in dims)]


def josa(word: str, pair: str) -> str:
    """받침 유무에 맞는 조사를 붙인다. 끝의 괄호(단위)는 건너뛰고, 숫자·영문은 읽는 소리로 본다
    (0·1·3·6·7·8은 받침 있음, L·M·N·R도 받침 있음).

    예: josa("공장", "과와") → "공장과", josa("수율(%)", "이가") → "수율(%)이".
    입력: word — 명사(단위 괄호는 있어도 된다), pair — 받침 있을 때·없을 때 조사 두 글자(예: "이가")
    반환: word에 맞는 조사를 붙인 문자열
    """
    base = re.sub(r"\s*\([^()]*\)\s*$", "", word or "").strip() or (word or " ")
    ch = base[-1]
    has = (ord(ch) - 0xAC00) % 28 > 0 if 0xAC00 <= ord(ch) <= 0xD7A3 else ch in "013678LMNRlmnr"
    return (word or "") + (pair[0] if has else pair[1])


def nested_parents(col, df, smap, candidates) -> list:
    """설비 차원 col의 같은 값 이름이 다른 범위 차원 값마다 따로 쓰이면, 그 범위 차원들을 돌려준다.

    예: 공장마다 매긴 설비 번호. 이 경우 col만으로 묶으면 서로 다른 설비가 한 묶음이 되므로 그 차원과 함께 묶어야 한다.
    입력: col — 설비 차원 컬럼, df — 데이터, smap — {컬럼: 컬럼 정보 행}, candidates — 범위 차원 목록(범위 차원만 넘긴다)
    반환: 함께 묶어야 하는 범위 차원 컬럼 list(해당 없으면 빈 list)
    """
    r = smap.get(col)
    if str(getattr(r, "category", "") or "").lower() not in EQUIP_CATS or col not in df.columns:
        return []
    return [p for p in candidates if p != col and p in df.columns and df[p].nunique() > 1 and int(df.groupby(col)[p].nunique().max()) > 1]


def spec_map(spec):
    return {r.column_name: r for r in spec.itertuples()} if len(spec) else {}


def label(col, smap):
    """화면 표시용 이름을 만든다. 표시명 + 단위, "컬럼=값" 형식이면 값까지 붙인다.

    예: 표시명 "수율", 단위 "%" → "수율(%)". "공장=A" → "공장=A"(값이 있으면 단위는 붙이지 않는다).
    입력: col — 컬럼 이름("=" 뒤는 값), smap — {컬럼: 컬럼 정보 행}
    반환: 문자열. 표시명이 없으면 컬럼 이름을 쓴다.
    """
    base, _, val = str(col).partition("=")
    r = smap.get(base)
    name = r.display_name if r is not None and isinstance(r.display_name, str) and r.display_name else base
    unit = r.unit if r is not None and isinstance(r.unit, str) and r.unit else ""
    if val:
        return f"{name}={val}"
    return f"{name}({unit})" if unit else name


def row_unit(cfg, smap) -> str:
    """행 하나를 부르는 말을 정한다. 순서: 첫 제안의 행 단위 → 식별자 컬럼 표시명에서 끝의 ID·번호·코드를 뗀 것("배치 ID" → "배치") → "행".

    입력: cfg — 설정 dict(source.table, id_col 사용), smap — {컬럼: 컬럼 정보 행}
    반환: 문자열(예: "배치", "행")
    """
    table = ((cfg or {}).get("source") or {}).get("table")
    unit = (spec_provider.table_meta(table).get("row_unit") if spec_provider and table else None)
    if unit:
        return unit
    c = (cfg or {}).get("id_col")
    r = smap.get(c) if c else None
    name = r.display_name if r is not None and isinstance(r.display_name, str) and r.display_name else ""
    return re.sub(r"\s*(ID|id|번호|코드)$", "", name).strip() or "행"


def is_num(s):
    return pd.api.types.is_numeric_dtype(s) and not pd.api.types.is_bool_dtype(s)


def is_datetime(s):
    if pd.api.types.is_datetime64_any_dtype(s):
        return True
    sample = s.dropna().head(20)
    return len(sample) > 0 and all(isinstance(v, (_dt.date, _dt.datetime, pd.Timestamp)) for v in sample)


def cfg_lines(cfg, smap):
    """설정의 소스 이름과 범위 요약 문장을 만든다.

    예: "공장 A공장 · 제품 L-라이신 · 배치 시작일 2026-07-01~2026-09-30". 조건이 없으면 "전체".
    입력: cfg — 정리된 설정(source, filters, date_filter), smap — {컬럼: 컬럼 정보 행}
    반환: (소스 이름(table 또는 path), 범위 요약 문자열)
    """
    parts = [f"{label(c, smap)} {'/'.join(map(str, v))}" for c, v in cfg["filters"].items()]
    if cfg.get("date_filter"):
        d = cfg["date_filter"]
        parts.append(f"{label(d['col'], smap)} {d.get('start') or '처음'}~{d.get('end') or '끝'}")
    src = cfg["source"].get("table") or cfg["source"].get("path")
    return src, " · ".join(parts) or "전체"


# ----------------------------------------------------------------------------- 공통 정리 단계

def string_numeric(X: pd.DataFrame, min_ratio: float, smap) -> tuple[pd.DataFrame, dict | None]:
    """문자열 컬럼 중 숫자로 읽히는 비율이 min_ratio 이상인 것을 숫자형으로 바꾼다.

    쉼표와 공백을 지우고 읽으며, 읽히지 않는 값은 결측이 된다.
    입력: X — 변수 DataFrame, min_ratio — 숫자로 읽혀야 하는 비율(예: 0.8), smap — {컬럼: 컬럼 정보 행}
    반환: (변환한 복사본 DataFrame, 처리 기록 dict 또는 None — 바뀐 컬럼이 없으면 None)
    """
    X = X.copy()
    conv = []
    for c in X.columns:
        if X[c].dtype == object or pd.api.types.is_string_dtype(X[c]):
            nn = X[c].notna().sum()
            parsed = pd.to_numeric(X[c].astype(str).str.replace(",", "", regex=False).str.strip(), errors="coerce")
            parsed[X[c].isna()] = np.nan
            if nn and parsed.notna().sum() / nn >= min_ratio:
                conv.append((c, int(nn - parsed.notna().sum())))
                X[c] = parsed
    if not conv:
        return X, None
    return X, {"step": "string_numeric", "columns": [c for c, _ in conv],
               "detail": ", ".join(f"{label(c, smap)}: 숫자가 아닌 값 {n}건을 결측으로 바꿔 숫자형으로 변환" for c, n in conv)}


def normal_range(X: pd.DataFrame, mode: str, overrides: dict, smap):
    """정상범위(대화에서 고친 변수별 범위 overrides → 첫 제안) 밖 값을 처리한다.

    mode: nan(범위 밖 값을 결측으로) | drop_row(범위 밖 행을 표시만 한다) | off(검사하지 않는다).
    입력: X — 변수 DataFrame, mode — 위 세 값 중 하나, overrides — cfg normal_by_col, smap — {컬럼: 컬럼 정보 행}
    반환: (X, 범위 밖 행 마스크, 컬럼별 건수, 로그 항목 또는 None). 부작용: 없음(X는 복사본).
          drop_row일 때 행 제거는 호출한 쪽이 한다.
    """
    X = X.copy()
    bad_rows = pd.Series(False, index=X.index)
    hits = {}
    if mode == "off":
        return X, bad_rows, hits, None
    for c in X.columns:
        if not is_num(X[c]):
            continue
        rng = bounds_of(c, smap, overrides)
        if rng is None:
            continue
        out = out_of(X[c], rng)
        if out.any():
            hits[c] = int(out.sum())
            if mode == "nan":
                X.loc[out, c] = np.nan
            else:
                bad_rows |= out
    if not hits:
        return X, bad_rows, hits, None
    how = "결측 처리" if mode == "nan" else f"해당 {int(bad_rows.sum())}행 제거"
    return X, bad_rows, hits, {"step": "normal_range", "columns": list(hits), "count": sum(hits.values()),
                               "detail": f"범위 밖 값 {sum(hits.values())}건 {how}: " +
                                         ", ".join(f"{label(c, smap)} {n}건" for c, n in hits.items())}



def is_categorical(s: pd.Series) -> bool:
    return not (is_num(s) or pd.api.types.is_bool_dtype(s))


def run_id(prefix: str = "") -> str:
    import uuid
    return prefix + _dt.datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:4]


# ----------------------------------------------------------------------------- 결측 대치 (모든 분석·작업 데이터 공통)

# 화면 · 요약 문장에 쓰는 처리 방법 이름(모든 파일이 이것을 쓴다)
RANGE_LABELS = {"nan": "그 값만 지움", "drop_row": "그 행 제외", "off": "그대로 둠"}  # 정상범위 밖 값(설정 칸 선택지)
RANGE_TEXT = {"nan": "정상범위 밖 값은 지우고 결측으로 처리", "drop_row": "정상범위 밖 값이 있는 행 제외", "off": "정상범위 밖 값 그대로"}  # 요약 문장
CAT_LABELS = {"exclude": "분석에서 뺌", "onehot": "값마다 0/1로 넣음"}  # 범주형(글자) 변수
IMPUTE_LABELS = {"auto": "변수별 자동", "mean": "평균", "median": "중앙값", "constant": "상수", "mode": "최빈값", "knn": "KNN",
                 "none": "채우지 않음"}  # none: 결측 그대로 둔다(트리 모델이 결측을 그대로 다룬다)


def na_rule_text(r) -> str:
    """결측 비율 기준 한 구절. 1(100%) 이상이면 결측 비율로는 빼지 않는다."""
    return "결측 비율로 빼지 않음" if float(r) >= 1 else f"결측 {float(r):.0%} 넘는 변수 제외"


def unique_rule_text(n) -> str:
    """고유값 기준 한 구절. 1 이하면 값 종류로는 빼지 않는다."""
    return "값 종류로 빼지 않음" if int(n) <= 1 else f"값 종류 {int(n)}개 미만 제외"


def auto_impute(s: pd.Series) -> tuple[str, str]:
    """결측 대치 방법을 변수 분포로 정한다(결정적: 같은 데이터면 같은 결과).

    규칙: 값 종류가 10개 이하인 정수형 → 최빈값, |왜도| > 1(한쪽으로 치우침) → 중앙값, 그 밖 → 평균.
    입력: s — 변수 Series
    반환: (방법 이름 "mode" | "median" | "mean", 이유 문장)
    """
    v = s.dropna()
    if len(v) and v.nunique() <= 10 and bool((v == v.round()).all()):
        return "mode", "값 종류가 적은 정수형"
    sk = float(v.skew()) if len(v) > 2 else 0.0
    if abs(sk) > 1:
        return "median", f"분포가 한쪽으로 치우침(왜도 {sk:.1f})"
    return "mean", "분포가 대칭에 가까움"


def impute_methods(X: pd.DataFrame, cfg: dict, smap) -> tuple[dict, list]:
    """결측이 있는 컬럼마다 대치 방법을 정한다. impute_by_col(직접 지정)이 우선, 없으면 impute(auto면 컬럼 분포로 정함).

    입력: X — 수치 변수 DataFrame, cfg — 설정(impute, impute_by_col), smap — {컬럼: 컬럼 정보 행}
    반환: (방법 {컬럼: 방법}, 화면용 계획 list[{col, label, ratio, method, value, reason}]). 결측이 없는 컬럼은 빠진다.
    """
    by = cfg.get("impute_by_col") or {}
    methods, reasons = {}, {}
    for c in X.columns:
        if not X[c].isna().any():
            continue
        if c in by:
            methods[c], reasons[c] = by[c], "직접 지정"
        elif cfg.get("impute", "auto") == "auto":
            methods[c], reasons[c] = auto_impute(X[c])
        else:
            methods[c], reasons[c] = cfg["impute"], "요청한 방법"
    plan = [{"col": c, "label": label(c, smap), "ratio": round(float(X[c].isna().mean()), 4),
             "method": m if isinstance(m, str) else "value", "value": m if not isinstance(m, str) else None, "reason": reasons[c]}
            for c, m in methods.items()]
    return methods, plan


def apply_impute(X: pd.DataFrame, methods: dict, cfg: dict) -> pd.DataFrame:
    """방법대로 결측을 채운다. KNN은 다른 컬럼으로 이웃을 찾아 그 컬럼만 채운다(수치 컬럼만). none은 채우지 않는다.

    입력: X — 수치 변수 DataFrame, methods — impute_methods가 준 {컬럼: 방법}, cfg — 설정(knn_k, impute_constant)
    반환: 채운 복사본 DataFrame(입력 X는 바꾸지 않는다)
    """
    X, Xo = X.copy(), X.copy()
    knn = None
    if any(m == "knn" for m in methods.values()):
        from sklearn.impute import KNNImputer
        knn = pd.DataFrame(KNNImputer(n_neighbors=int(cfg.get("knn_k", 5))).fit_transform(Xo), columns=X.columns, index=X.index)
    for c, m in methods.items():
        col = Xo[c]
        if m == "none":
            continue
        if m == "knn":
            X[c] = knn[c]
        elif m == "constant":
            X[c] = col.fillna(float(cfg.get("impute_constant", 0)))
        elif isinstance(m, (int, float)):
            X[c] = col.fillna(float(m))
        elif m == "mode":
            X[c] = col.fillna(col.mode().iloc[0] if col.notna().any() else 0.0)
        else:
            X[c] = col.fillna(getattr(col, m)())
    return X


def impute_entry(methods: dict, cfg: dict, smap, n_missing: int, applied: bool) -> dict:
    """결측 대치 처리 기록 한 줄(변수별 방법, 채우지 않는 변수는 따로)을 만든다.

    입력: methods — {컬럼: 방법}, cfg — 설정(knn_k, impute_constant), smap — {컬럼: 컬럼 정보 행},
          n_missing — 채울 결측 칸 수(채우지 않는 변수 제외), applied — 실제로 채웠는지(False면 "실행할 때 적용" 표시)
    반환: dict(step, detail, count, by_col)
    """
    name = lambda m: f"값 {m:g}" if isinstance(m, (int, float)) else IMPUTE_LABELS[m] + (  # noqa: E731
        f"(k={cfg.get('knn_k', 5)})" if m == "knn" else f"(값={cfg.get('impute_constant', 0)})" if m == "constant" else "")
    parts = [f"{label(c, smap)} {name(m)}" for c, m in methods.items() if m != "none"]
    keep = [label(c, smap) for c, m in methods.items() if m == "none"]
    short = lambda xs: ", ".join(xs[:8]) + (f" 외 {len(xs) - 8}개" if len(xs) > 8 else "")  # noqa: E731
    detail = " · ".join(([f"남은 결측 {n_missing}칸을 변수별로 채움: {short(parts)}" + ("" if applied else " (실행할 때 적용)")] if parts else [])
                        + ([f"결측 그대로(채우지 않음): {short(keep)}"] if keep else []))
    return {"step": "impute", "detail": detail, "count": n_missing, "by_col": {c: name(m) for c, m in methods.items()}}
