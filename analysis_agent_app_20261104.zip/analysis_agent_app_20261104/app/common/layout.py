"""화면 양식(skill의 layout.yaml) + 데이터(tools.py가 계산한 값) → 화면 JSON을 만드는 렌더러.

용도:
- layout.yaml을 읽고, 쓴 블록 종류가 블록 카탈로그(app/common/ui_schema.json)에 있는지 검사한다.
- 양식의 "{a.b}" 같은 자리를 데이터 값으로 채워 화면 JSON을 만든다.
- 차트 묶음(chart_groups)은 보기의 charts 목록으로 펼치고 group을 붙인다.
목적: tools.py는 화면을 모르고 값만 넘기며, 화면 모양은 양식(YAML)으로만 바꾼다.
화면 형식 = 블록 카탈로그, 화면 구성 = skill마다 layout.yaml.

양식 문법 (YAML 값 안에서만):
  "{a.b}"          값 하나만 있으면 그 값 그대로(목록·숫자·None 포함)
  "{a.b:.0%} 텍스트"  글자 안에 끼우면 문자열(파이썬 형식 지정자 사용 가능)
  each: a.b, as: t  목록의 항목마다 이 노드를 하나씩(목록 안에서는 펼쳐 넣음)
  when: a.b         값이 참일 때만 넣음(거짓이면 빠짐)
  first: [{when: a, value: …}, {value: …}]   조건이 맞는 첫 값
  chart_groups[].charts  묶음 안에 쓴 차트는 보기의 charts로 펼치고 group을 붙인다
차트·지표·설정 칸·단계(charts·metrics·fields·steps 아래 항목)는 값이 None인 키를 뺀다.

    L = load(__file__)                 # skill 폴더의 layout.yaml
    ui = render(L["result"]["run"], data)
"""
from __future__ import annotations

import json
import os
import re
import string

import yaml

_SCHEMA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ui_schema.json")
COMPACT = {"charts", "metrics", "fields", "steps"}   # 이 키 아래 항목은 None 값 키를 뺀다
_WHOLE = re.compile(r"^\{([A-Za-z_][\w.]*)\}$")
_SKIP = object()


def load(module_file: str) -> dict:
    """skill 폴더(모듈 파일 옆)의 layout.yaml을 읽고 블록 종류를 카탈로그로 검사한다.

    입력: module_file — 호출하는 모듈의 __file__
    반환: 양식 dict(layout.yaml 내용). 블록 종류 오류가 있으면 ValueError.
    """
    return load_file(os.path.join(os.path.dirname(os.path.abspath(module_file)), "layout.yaml"))


def load_file(path: str) -> dict:
    """양식 파일 하나(skill의 layout.yaml, 공통 단계 common/steps.yaml)를 읽고 블록 종류를 카탈로그로 검사한다.

    입력: path — 양식 파일 경로
    반환: 양식 dict. 블록 종류 오류가 있으면 ValueError(처음 8개 오류를 메시지에 담는다).
    """
    with open(path, encoding="utf-8") as fp:
        lay = yaml.safe_load(fp)
    errs = check(lay)
    if errs:
        raise ValueError(f"{path}: 화면 양식 오류 — " + "; ".join(errs[:8]))
    return lay


def catalog() -> dict:
    with open(_SCHEMA_PATH, encoding="utf-8") as fp:
        return json.load(fp)


def check(lay: dict) -> list:
    """양식에 쓴 블록 종류(차트·본문·설정 칸)가 카탈로그에 있는지 본다.

    값이 "{…}"이면 실행할 때 정해지므로 검사하지 않고 넘어간다.
    입력: lay — 양식 dict
    반환: 오류 문장 list(없으면 빈 list)
    """
    d = catalog()["$defs"]
    kinds = {"charts": set(d["chart"]["properties"]["type"]["enum"]), "fields": set(d["field"]["properties"]["type"]["enum"]),
             "sections": {s["properties"]["type"]["const"] for s in d["section"]["oneOf"]}}
    errs = []

    def walk(node, parent, path):
        if isinstance(node, dict):
            t = node.get("type")
            if parent in kinds and isinstance(t, str) and "{" not in t and t not in kinds[parent]:
                errs.append(f"{path}: {parent}에 없는 종류 '{t}'")
            for k, v in node.items():
                walk(v, k if isinstance(v, list) else parent, f"{path}.{k}")
        elif isinstance(node, list):
            for i, v in enumerate(node):
                walk(v, parent, f"{path}[{i}]")
    walk(lay, None, "")
    return errs


def validate(screen: dict, kind: str) -> list:
    """완성된 화면 JSON을 카탈로그 형식으로 검사한다(검증 도구·테스트용). jsonschema 패키지가 필요하다.

    입력: screen — 완성된 화면 dict, kind — 카탈로그 $defs 안의 정의 이름
    반환: 오류 메시지 list(없으면 빈 list)
    """
    import jsonschema
    sch = catalog()
    v = jsonschema.Draft202012Validator({"$defs": sch["$defs"], "$ref": f"#/$defs/{kind}"})
    return [f"{'/'.join(map(str, e.absolute_path))}: {e.message[:160]}" for e in v.iter_errors(screen)]


class _Fmt(string.Formatter):
    def get_field(self, field_name, args, kwargs):
        return lookup(kwargs, field_name), field_name


_F = _Fmt()


def lookup(data: dict, path: str):
    """점으로 이은 이름("r.ds", "t.share")을 데이터에서 찾는다. 목록은 숫자 인덱스로 찾는다.

    입력: data — 데이터 dict, path — 점으로 이은 이름
    반환: 찾은 값. 중간에 없거나 값이 None이면 None.
    """
    cur = data
    for part in path.split("."):
        if isinstance(cur, dict):
            cur = cur.get(part)
        elif isinstance(cur, (list, tuple)) and part.isdigit():
            cur = cur[int(part)] if int(part) < len(cur) else None
        else:
            return None
        if cur is None:
            return None
    return cur


def render(node, data: dict, parent: str | None = None):
    """양식 노드 하나를 데이터로 채운다. 조건이 거짓인 노드는 목록·dict 안에서 빠진다.

    입력: node — 양식 노드(문자열 · 목록 · dict · 그 밖의 값), data — 데이터 dict,
          parent — 바로 위 키 이름(COMPACT 판정에 쓴다, 최상위 호출은 None)
    반환: 채운 값(문자열 자리는 값으로 바꾼다. 조건이 거짓이면 내부 표식이라 상위에서 뺀다)
    """
    if isinstance(node, str):
        m = _WHOLE.match(node)
        if m:
            return lookup(data, m.group(1))
        return _F.vformat(node, (), data) if "{" in node else node
    if isinstance(node, list):
        out = []
        for item in node:
            if isinstance(item, dict) and "each" in item:
                out.extend(_each(item, data, parent))
                continue
            v = render(item, data, parent)
            if v is not _SKIP:
                out.append(v)
        return out
    if isinstance(node, dict):
        if set(node) == {"first"}:  # 조건이 맞는 첫 값: first: [{when: a, value: …}, {value: …}]
            for opt in node["first"]:
                if "when" not in opt or _truthy(lookup(data, opt["when"])):
                    return render(opt.get("value"), data, parent)
            return None
        if "when" in node and not _truthy(lookup(data, node["when"])):
            return _SKIP
        if "each" in node:  # 목록 밖(값 자리)에 쓴 each는 목록을 만든다
            return _each(node, data, parent)
        out = {}
        for k, v in node.items():
            if k in ("when",):
                continue
            if k == "chart_groups":
                groups, charts = _groups(v, data)
                out["chart_groups"] = groups
                out["charts"] = (out.get("charts") or []) + charts
                continue
            rv = render(v, data, k if isinstance(v, list) else parent)
            if rv is _SKIP:
                continue
            if rv is None and parent in COMPACT:
                continue
            out[k] = rv
        return out
    return node


def _truthy(v) -> bool:
    return bool(v) if not isinstance(v, (int, float)) or isinstance(v, bool) else True


def _each(node: dict, data: dict, parent):
    """each 노드: 목록 항목마다 본문을 하나씩 채운다. as로 항목 이름을 정하고, limit로 개수를 제한하며, when이 거짓인 항목은 뺀다.

    입력: node — {each, as(기본 "it"), limit, 나머지는 본문}, data — 데이터 dict, parent — 바로 위 키 이름
    반환: 채운 항목 list
    """
    items = lookup(data, node["each"]) or []
    name = node.get("as", "it")
    limit = node.get("limit")
    if isinstance(limit, str):
        limit = render(limit, data)
    body = {k: v for k, v in node.items() if k not in ("each", "as", "limit")}
    out = []
    for item in (items[:limit] if limit else items):
        v = render(body, {**data, name: item}, parent)
        if v is not _SKIP:
            out.append(v)
    return out


def _groups(spec: list, data: dict):
    """차트 묶음 목록을 (묶음 메타 목록, 차트 목록)으로 나눈다. 묶음 안 charts는 순서대로 펼치고 group에 묶음 id를 붙인다.

    입력: spec — chart_groups 양식 목록(각 항목: id 등 메타, charts, 선택적 when), data — 데이터 dict
    반환: (묶음 메타 list, 차트 list). when이 거짓인 묶음은 빠진다.
    """
    groups, charts = [], []
    for x in spec:
        if isinstance(x, dict) and "when" in x and not _truthy(lookup(data, x["when"])):
            continue
        meta = render({k: v for k, v in x.items() if k not in ("charts", "when")}, data, "chart_groups")
        groups.append(meta)
        for c in render(x.get("charts") or [], data, "charts"):
            charts.append({**c, "group": meta["id"]})
    return groups, charts
