"""공정 데이터 분석 에이전트의 실행기: 대화 상태 · skill 레지스트리 · 실행기 도구 · 시스템 프롬프트 · 한 턴 스트리밍. app.py가 이를 MLflow ResponsesAgent(/responses)로 내보낸다.

용도:
- 테이블: LLM이 질문에 맞는 등록 테이블을 골라 도구 cfg의 source에 넣으면 대화의 테이블이 바뀐다.
- 실행기 도구(이 파일): 데이터 조회(Genie Agent) · PDF · 차트 편집 · 표·차트 덧붙이기 · skill 열기(load_skill). 쓰는 법은 prompt_app.md.
- skill(skills/<이름>/): SKILL.md 지침 + tools.py(도구, NULLABLE_KEYS, FROM_RESULT_TOOLS) + 계산(engine.py) + 화면 양식(layout.yaml).
  metadata.always: true인 skill은 늘 열려 있고, 그 밖의 분석 skill의 도구는 load_skill로 연 뒤에만 보인다.
- 한 턴: 결과가 나온 뒤 처음 쓴 글이 그 결과의 해석(PDF에 들어감). 턴이 끝나면 후속 질문 3개를 만든다.

목적: 분석 방법·진행·해석은 skill(SKILL.md)과 LLM에 맡긴다. 이 파일은 skill 이름과 도구 이름을 모른 채 공통 흐름만 맡으므로, skill을 추가해도 이 파일은 고치지 않는다.
골라야 할 것은 LLM이 글로 묻고, 답 후보는 후속 질문 칩이 보여 준다.
"""
from __future__ import annotations

import asyncio
import contextlib
import glob
import importlib.util
import json
import os
import re
import sys
import threading
import time
import uuid
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from agents import Agent, FunctionTool, ItemHelpers, ModelSettings, RunConfig, RunHooks, Runner
from agents import set_default_openai_api, set_default_openai_client, set_trace_processors, set_tracing_disabled
import httpx
from openai import AsyncOpenAI

HERE = os.path.dirname(os.path.abspath(__file__))
SKILLS_DIR = os.path.join(HERE, "skills")
sys.path.insert(0, HERE)  # common/ (모든 skill이 같이 쓰는 모듈)
sys.path.insert(0, os.path.join(SKILLS_DIR, "data-prep"))  # 기본 skill(데이터 처리): work · sources — 모든 분석이 이 데이터를 쓴다

from common import result_format as C  # noqa: E402
from common import data as cd  # noqa: E402
from common import layout as Lay  # noqa: E402

import genie as G  # noqa: E402
import work as W  # noqa: E402
import sources as S  # noqa: E402

MODEL = os.getenv("SERVING_ENDPOINT", "databricks-claude-sonnet-5-5")
WAREHOUSE_ID = W.WAREHOUSE_ID
OUTPUT_DIR = os.path.join(HERE, "outputs")
ENGINE_LOCK = threading.Lock()  # matplotlib·캐시 보호(엔진 계산은 한 번에 하나)
MAX_STEPS = 12
FOLLOWUP_MODEL = os.getenv("FOLLOWUP_MODEL") or MODEL
# MLflow 추적: 배포 앱(앱 리소스로 실험 연결)에서만 켠다. 한 턴 = trace 하나(LLM 호출 · 도구 호출이 span). 로컬은 기록 파일을 남기지 않게 끈다.
TRACE = os.getenv("MLFLOW_TRACKING_URI", "").startswith("databricks") and bool(os.getenv("MLFLOW_EXPERIMENT_ID"))



# ----------------------------------------------------------------------------- skill registry

@dataclass
class Skill:
    """분석 skill 하나의 등록 정보(discover_skills가 만든다).

    필드: name — 이름 · title — 화면 제목 · description — SKILL.md 설명 · path — skill 폴더 · module — tools.py 모듈 · tools — 도구 정의 목록 ·
    labels — 도구 이름표 · summary — 화면용 한 줄 설명(metadata.summary) · order — 목록 순서(metadata.order) · always — 항상 열림(metadata.always)
    """
    name: str
    title: str
    description: str
    path: str
    module: object
    tools: list
    labels: dict
    summary: str = ""   # 화면용 한 줄 설명 (metadata.summary)
    order: int = 99     # 화면·목록 순서 (metadata.order)
    always: bool = False  # 항상 열림(metadata.always)

    @property
    def tool_names(self):
        return [t["function"]["name"] for t in self.tools]


def _frontmatter(text: str) -> tuple[dict, str]:
    """SKILL.md 머리말(Agent Skills 규격: name·description, 그 밖의 값은 metadata 아래 한 단계)."""
    m = re.match(r"^---\n(.*?)\n---\n(.*)$", text, re.S)
    if not m:
        return {}, text
    meta, nested = {}, None
    for line in m.group(1).splitlines():
        if not line.strip():
            continue
        k, _, v = line.strip().partition(":")
        if line.startswith((" ", "\t")) and nested is not None:
            meta[nested][k.strip()] = v.strip()
        elif not v.strip():
            nested = k.strip()
            meta[nested] = {}
        else:
            nested = None
            meta[k.strip()] = v.strip()
    return meta, m.group(2)


def discover_skills() -> dict:
    """skills/*/SKILL.md를 모두 찾아 skill 레지스트리를 만든다. 폴더 이름이 _로 시작하거나 AVAILABLE이 False인 skill은 건너뛴다.
    각 tools.py는 모듈로 실행해 읽는다.

    입력: 없음
    반환: {이름: Skill} dict(order → 이름 순 정렬). 부작용: 각 skill의 tools.py를 import한다.
    """
    out = {}
    for d in sorted(glob.glob(os.path.join(SKILLS_DIR, "*", "SKILL.md"))):
        path = os.path.dirname(d)
        if os.path.basename(path).startswith("_"):
            continue
        meta, _ = _frontmatter(open(d, encoding="utf-8").read())
        name = meta.get("name") or os.path.basename(path)
        spec = importlib.util.spec_from_file_location(f"skill_{name.replace('-', '_')}_tools", os.path.join(path, "tools.py"))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        if getattr(mod, "AVAILABLE", True) is False:
            continue
        md = meta.get("metadata") or {}
        desc = meta.get("description", "")
        out[name] = Skill(name, md.get("title") or name, desc, path, mod, mod.TOOLS, getattr(mod, "LABELS", {}),
                          md.get("summary") or desc.split(". ")[0], int(md.get("order") or 99), str(md.get("always")).lower() == "true")
    return dict(sorted(out.items(), key=lambda kv: (kv[1].order, kv[0])))


SKILLS = discover_skills()
TOOL_OWNER = {t: s.name for s in SKILLS.values() for t in s.tool_names}


def capabilities() -> list:
    """사용자에게 보이는 '할 수 있는 일' 목록(첫 화면·예시·후속 질문 힌트). Genie 공간이 있으면 '데이터 조회'를 먼저 넣고 그 뒤에 skill을 잇는다.

    입력: 없음
    반환: [(제목, 한 줄 설명), ...]
    """
    look = [("데이터 조회", "건수·평균·추이·순위 같은 기본 조회와 집계에 바로 답합니다")] if G.SPACE_ID else []
    return look + [(s.title, s.summary) for s in SKILLS.values()]


def skill_doc(name: str) -> str:
    """SKILL.md 본문(머리말 제외) 그대로. skill에 필요한 지침은 모두 SKILL.md 한 파일에 있다."""
    with open(os.path.join(SKILLS[name].path, "SKILL.md"), encoding="utf-8") as f:
        return _frontmatter(f.read())[1].strip()


# ----------------------------------------------------------------------------- skill cfg 합치기

def merged_cfg(skill: str, cfg: dict | None, conv=None) -> dict:
    """skill의 최종 cfg를 만든다. 우선순위: 소스 기본값(식별자 · 날짜 · 컬럼 정보 · 기본 지표) → 작업 데이터(공통 데이터 처리) → 요청 cfg.
    이 skill(ENGINE_DEFAULTS)이 아는 키만 반영한다. 기간만 말하면 소스의 날짜 컬럼을 넣는다.
    null은 '해제'로 받는 키(date_filter와 NULLABLE_KEYS)에만 반영하고, 그 밖의 null은 무시한다.

    입력: skill — skill 이름, cfg — 요청 cfg(dict 또는 None), conv — 대화(없을 수 있음)
    반환: 병합된 cfg dict(output_dir 포함). 모르는 키가 있으면 cd.PipelineError를 던진다.
    """
    keys = SKILLS[skill].module.ENGINE_DEFAULTS
    cfg = dict(cfg or {})
    src = cfg.get("source") or (conv.source if conv else None) or W.default_source()
    d = S.describe(src, W.backend())
    base = {k: v for k, v in d["guess"].items() if k in keys and v}
    if d.get("spec_table") and "spec_table" in keys:
        base["spec_table"] = d["spec_table"]
    if "y" in keys and not base.get("y"):
        py = (W.source_profile(src).get("y") or {}).get("col")
        if py:
            base["y"] = py
    base["source"] = src
    base.update({k: v for k, v in W.work_of(conv, src).items() if k in keys and k in W.KEYS})
    nullable = {"date_filter"} | set(getattr(SKILLS[skill].module, "NULLABLE_KEYS", ()))  # null로 보내면 '해제'인 키(그 밖의 null은 무시)
    base.update({k: v for k, v in cfg.items() if k in keys and (v is not None or k in nullable)})
    if isinstance(base.get("date_filter"), dict) and not base["date_filter"].get("col") and d["guess"]["date_col"]:
        base["date_filter"] = {**base["date_filter"], "col": d["guess"]["date_col"]}  # 기간만 말하면 소스의 날짜 컬럼
    unknown = [k for k in cfg if k not in keys]
    if unknown:
        raise cd.PipelineError(f"알 수 없는 설정 키: {unknown}", {"valid_keys": sorted(k for k in keys if k != "output_dir")})
    base["output_dir"] = OUTPUT_DIR
    return base


# ----------------------------------------------------------------------------- conversation

@dataclass
class Conversation:
    """대화 하나의 상태. 턴마다 같은 객체를 쓴다.

    필드: id — 대화 id · messages — LLM 대화 기록 · loaded — 연 분석 skill 이름 목록 · runs — 실행 결과(run_id → 상태) ·
    interpretations — run_id → 해석 글(PDF용) · last_preview — skill → 마지막 제안 cfg · source — 이 대화의 테이블 ·
    screen — 화면이 알려준 현재 결과·보기 · last_run_id — 마지막 실행 id · genie_cid — Genie 대화 id · work — 작업 데이터 ·
    lookups — 조회 결과(Genie 응답) · meta — 첫 화면 정보 · lock — 턴 동시 실행 방지 잠금
    """
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    messages: list = field(default_factory=list)
    loaded: list = field(default_factory=list)          # 연 skill(항상 열린 skill 제외)
    runs: dict = field(default_factory=dict)             # run_id → {skill, res, ui, frames, output_dir}
    interpretations: dict = field(default_factory=dict)  # run_id → 해석 글(PDF)
    last_preview: dict = field(default_factory=dict)     # skill → 제안 cfg
    source: dict | None = None                           # 이 대화의 테이블(질문에 맞게 LLM이 고르거나 데이터 패널에서 고른다)
    screen: dict | None = None                           # 화면이 알려준 현재 결과·보기·차트 배치
    last_run_id: str | None = None
    genie_cid: str | None = None                         # Genie 대화(이어지는 조회는 같은 대화로)
    work: dict | None = None                             # 작업 데이터: {"source": 소스 키, 공통 데이터 처리 키}
    lookups: dict = field(default_factory=dict)          # 조회 결과 id → Genie 응답
    meta: dict | None = None                             # 첫 화면 정보
    lock: threading.Lock = field(default_factory=threading.Lock)

    def skills(self):
        return [s for s in SKILLS.values() if s.always] + [SKILLS[n] for n in self.loaded]


CONVERSATIONS: dict[str, Conversation] = {}


def get_conversation(cid: str | None) -> Conversation:
    """id로 대화를 찾고 없으면 새로 만든다. cid가 없으면 새 id를 쓰고, 모르는 cid면 그 id로 새 대화를 만든다.

    입력: cid — 대화 id 또는 None
    반환: Conversation(CONVERSATIONS에 등록됨)
    """
    if cid and cid in CONVERSATIONS:
        return CONVERSATIONS[cid]
    conv = Conversation(**({"id": cid} if cid else {}))
    CONVERSATIONS[conv.id] = conv
    return conv


class Ctx:
    """skill 도구가 실행기와 주고받는 창구. 도구를 실행할 때마다 만들며, skill 이름과 화면 이벤트 전달 함수를 담는다.
    BACKEND는 compute 인자의 자리표시로, SQL 백엔드로 바뀐다.
    """
    BACKEND = "__BACKEND__"  # compute 인자 자리표시: SQL 백엔드로 바뀐다

    def __init__(self, conv: Conversation, skill: str, emit):
        self.conv, self.skill, self._emit = conv, skill, emit

    def emit(self, ev):
        if ev.get("type") in ("result", "proposal") and isinstance(ev.get("data"), dict):  # 오브젝트 이름표 = skill 제목
            ev["data"].setdefault("skill_title", SKILLS[self.skill].title)
            ev["data"].setdefault("run_tool", getattr(SKILLS[self.skill].module, "RUN_TOOL", None))
        self._emit(ev)

    def backend(self):
        return W.backend()

    def source(self) -> dict:
        return self.conv.source or W.default_source()

    def source_name(self, cfg=None) -> str:
        """"적용된 설정"의 데이터 이름: 테이블 이름 (테이블 이름표)."""
        src = (cfg or {}).get("source") or self.source()
        short = S.short(S.source_key(src) or "")
        title = S.title(S.source_key(src), W.backend())
        return f"{short} ({title})" if title and title != short else short

    def unit(self, cfg=None) -> str:
        return W.source_profile((cfg or {}).get("source") or self.source())["unit"]

    def work(self) -> dict:
        return W.work_of(self.conv, self.source())

    def set_work(self, keys: dict):
        self.conv.work = {**keys, "source": S.source_key(self.source())}

    def progress(self, text: str):
        """도구가 실제 처리 단계를 지날 때 화면 도구 줄에 표시한다."""
        self._emit({"type": "tool_progress", "text": text})

    def data(self, cfg: dict, **override) -> dict:
        """작업 데이터: 이 cfg(병합된 것)로 처리한 데이터(데이터 처리 skill의 계산, 같은 설정이면 다시 씀). 분석 skill이 엔진에 넘긴다.
        override로 범위를 바꿔 받을 수 있다(기간을 넓히거나 그룹 필터를 더한 범위 등)."""
        return W.data({**cfg, **override}, W.backend())

    def compute(self, engine, func: str, *args, progress: bool = False, **kw):
        """엔진 함수 실행. BACKEND 자리에는 SQL 백엔드를, progress면 화면 진행 표시를 넘긴다."""
        if progress:
            kw["progress"] = self.progress
        return getattr(engine, func)(*[W.backend() if a == self.BACKEND else a for a in args], **kw)

    def cfg(self, user_cfg):
        merged = merged_cfg(self.skill, user_cfg, self.conv)
        if (user_cfg or {}).get("source"):
            self.conv.source = merged["source"]
        return merged

    def set_preview(self, skill, cfg):
        self.conv.last_preview[skill] = cfg

    def register(self, run_id, skill, res, ui, frames, main=True):
        self.conv.runs[run_id] = {"skill": skill, "res": res, "ui": ui, "frames": frames, "output_dir": res.get("output_dir"), "main": main}

    def previous(self, skill, cond=None):
        """이 대화에서 같은 skill의 직전 주 결과."""
        for st in reversed(list(self.conv.runs.values())):
            if st["skill"] == skill and st.get("main", True) and (cond is None or cond(st["res"])):
                return st["res"]
        return None

    def profile(self, cfg=None) -> dict:
        """지금 분석한 소스의 프로필(범위 차원·설비 차원·기간). 읽지 못하면 빈 프로필."""
        try:
            return W.source_profile((cfg or {}).get("source") or self.conv.source)
        except Exception:  # noqa: BLE001
            return {"dims": [], "scope": [], "equip": None, "date_range": None}


# ----------------------------------------------------------------------------- 도구 (실행기가 늘 주는 기능, skill과 무관)

CHART_SPEC = {"type": "object", "properties": {  # 차트 하나(공통 블록 카탈로그의 차트 종류·필드 키)
    "type": {"type": "string", "enum": sorted(C.EDITABLE_TYPES)},
    "title": {"type": "string"}, "x": {"type": "string"}, "y": {"type": "string"}, "color": {"type": "string"},
    "agg": {"type": "string", "enum": ["mean", "median", "sum", "count"]},
    "bucket": {"type": "string", "enum": ["day", "week", "month", "quarter"]},
    "bins": {"type": "integer"}, "fields": {"type": "array", "items": {"type": "string"}},
    "span": {"type": "integer", "enum": [1, 2, 3]}}, "required": ["type"]}

RUNTIME_TOOLS = [
    {"type": "function", "function": {
        "name": "load_skill",
        "description": "분석 skill의 지침(진행·설정 키·해석 형식)을 읽고 그 skill의 도구를 연다. 분석 전에 먼저 호출한다.",
        "parameters": {"type": "object", "properties": {"name": {"type": "string", "enum": [s.name for s in SKILLS.values() if not s.always]}},
                       "required": ["name"]}}},
    {"type": "function", "function": {
        "name": "save_pdf",
        "description": "실행 결과와 그 해석을 담은 PDF 리포트를 만든다(결과 패널의 차트 포함).",
        "parameters": {"type": "object", "properties": {"run_id": {"type": "string", "description": "생략하면 이 대화의 마지막 결과"}}}}},
    {"type": "function", "function": {
        "name": "edit_charts",
        "description": "결과 패널 차트를 추가·변경·삭제한다. 행 단위 데이터로 그린다.",
        "parameters": {"type": "object", "properties": {
            "run_id": {"type": "string", "description": "대상 결과(생략 시 사용자가 보고 있는 결과)"},
            "view": {"type": "string", "description": "보기 id(생략 시 사용자가 보고 있는 보기). '현재 결과 패널' 절의 보기 목록"},
            "add": {"type": "array", "items": CHART_SPEC},
            "update": {"type": "array", "items": {"type": "object", "description": "{id: '현재 결과 패널'의 차트 id, 바꿀 키(type·x·y·color·agg·bucket·bins·fields·title·span)}"}},
            "remove": {"type": "array", "items": {"type": "string"}, "description": "삭제할 차트 id ('현재 결과 패널' 절)"},
            "cols": {"type": "object", "description": "차트 묶음별 열 수 {묶음 id: 1|2|3} ('현재 결과 패널'의 묶음 id)"}}}}},
    {"type": "function", "function": {
        "name": "add_section",
        "description": "결과 패널(사용자가 보고 있는 보기)의 맨 아래에 질문에 맞는 표·차트 묶음을 덧붙인다. 기본 화면이 질문의 답을 바로 보여 주지 못할 때 쓴다 "
                       "(예: 두 그룹의 변수별 값 비교 표 + 그룹별 상자그림). 그 결과의 행 단위 데이터로 만들고, 표·차트 형식은 앱이 검사한다(PDF에도 들어간다).",
        "parameters": {"type": "object", "properties": {
            "run_id": {"type": "string", "description": "대상 결과(생략 시 사용자가 보고 있는 결과)"},
            "title": {"type": "string", "description": "묶음 제목(짧게, 예: 주요 차이)"},
            "note": {"type": "string", "description": "묶음 설명 한 줄(사람 말로)"},
            "group_table": {"type": "object", "description": "그룹별 집계 표: 행 = 변수, 열 = 그룹 값(두 그룹이면 차이·표준편차 단위 차이도)", "properties": {
                "by": {"type": "string", "description": "그룹 필드 키(범주형, '현재 결과 패널'의 필드 키)"},
                "fields": {"type": "array", "items": {"type": "string"}, "description": "비교할 수치 필드 키(보여줄 순서대로)"},
                "agg": {"type": "string", "enum": ["mean", "median"]},
                "order": {"type": "array", "items": {"type": "string"}, "description": "그룹 열 순서(생략 시 이름 순). 차이는 첫째 − 둘째"}}, "required": ["by", "fields"]},
            "charts": {"type": "array", "items": CHART_SPEC, "description": "이 묶음의 차트(필드 키는 '현재 결과 패널'의 것)"},
            "cols": {"type": "integer", "enum": [1, 2, 3], "description": "차트 열 수(기본 2)"}},
            "required": ["title"]}}},
]
if G.SPACE_ID:  # 원본 조회: Genie Agent(별도 에이전트)를 부르는 도구
    RUNTIME_TOOLS.insert(1, {"type": "function", "function": {
        "name": "ask_genie",
        "description": "원본 테이블에 SQL로 바로 답할 수 있는 조회·집계(건수·평균·합계·최대/최소·추이·순위·목록·조건 필터)를 Genie Agent에 자연어로 묻는다. "
                       "Genie가 SQL을 만들어 실행하고 결과 표를 돌려준다(대화에 '원본 조회' 오브젝트로 표시).",
        "parameters": {"type": "object", "properties": {
            "question": {"type": "string", "description": "Genie에 보낼 질문(한국어). 질문에 맞는 테이블의 짧은 이름과 조건을 문장에 넣는다"}},
            "required": ["question"]}}})
GENIE_LLM_ROWS = 120  # Genie 결과 중 LLM에 넘길 행 수(표 전체는 패널에)
RUNTIME_LABELS = {"ask_genie": "데이터 조회", "load_skill": "분석 지침 열기",
                  "save_pdf": "PDF 리포트 만들기", "edit_charts": "차트 편집", "add_section": "표·차트 덧붙이기"}


def _editable_dataset(ui: dict, view: dict | None):
    if (view or {}).get("dataset") in ui["datasets"]:
        return view["dataset"]
    for c in (view or {}).get("charts", []):
        d = ui["datasets"].get(c.get("dataset"))
        if d and d.get("editable"):
            return c["dataset"]
    return next((k for k, d in ui["datasets"].items() if d.get("editable")), None)


def default_view(ui: dict) -> dict:
    """화면이 처음 보여주는 보기: 반복 분석은 마지막 회차, 그 밖에는 첫 보기."""
    v = ui["views"]
    return v[-1] if ui["kind"] == "run" and len(v) > 1 and v[0]["id"] != "summary" else v[0]


def _layout(st: dict, view_id: str) -> dict:
    return st.setdefault("layouts", {}).setdefault(view_id, {"removed": [], "overrides": {}, "added": [], "cols": {}})


def effective_charts(st: dict, view: dict) -> list:
    """기본 배치 + 사용자 편집(화면·대화 모두) = 지금 화면에 보이는 차트."""
    lay = _layout(st, view["id"])
    return [{**c, **lay["overrides"].get(c["id"], {})} for c in view["charts"] if c["id"] not in lay["removed"]] + list(lay["added"])


def screen_target(conv: Conversation):
    """지금 사용자가 보고 있는 결과·보기 (화면이 알려준 값 → 없으면 마지막 실행의 기본 보기)."""
    sc = conv.screen or {}
    rid = sc.get("run_id") if sc.get("run_id") in conv.runs else conv.last_run_id
    st = conv.runs.get(rid)
    if not st or not st["ui"].get("views"):
        return None, None, None
    view = next((v for v in st["ui"]["views"] if v["id"] == sc.get("view_id")), None) if rid == sc.get("run_id") else None
    return rid, st, view or default_view(st["ui"])


def screen_md(conv: Conversation) -> str:
    """시스템 프롬프트에 넣는 현재 결과 패널 상태(차트 편집 요청을 정확한 차트·필드로 옮기기 위해)."""
    rid, st, view = screen_target(conv)
    if not st:
        return ""
    ui = st["ui"]
    ds = _editable_dataset(ui, view)
    lines = [f"- 결과 `{rid}` ({ui['title']}) · 보고 있는 보기 `{view['id']}`({view['label']})",
             "- 보기 목록: " + ", ".join(f"`{v['id']}`({v['label']})" for v in ui["views"])]
    lay = _layout(st, view["id"])
    gl = [f"`{g['id']}`({g['title']}, {lay['cols'].get(g['id'], g['cols'])}열)" for g in view.get("chart_groups") or []]
    if gl:
        lines.append("- 차트 묶음: " + ", ".join(gl))
    for c in effective_charts(st, view):
        enc = ", ".join(f"{k}={c[k]}" for k in ("x", "y", "color", "agg", "bucket") if c.get(k))
        lines.append(f"  - 차트 `{c['id']}` {c['type']} \"{c.get('title', '')}\"" + (f" ({enc})" if enc else "") +
                     (" [사용자 추가]" if c.get("group") == "user" else ""))
    if ds:
        lines.append("- 차트 필드(키: 표시명): " + ", ".join(f"{f['key']}: {f['label']}" for f in ui["datasets"][ds]["fields"]))
    return "\n".join(lines)


def edit_charts(conv: Conversation, args: dict, emit) -> str:
    """LLM의 차트 편집 요청(add · update · remove · cols)을 검증해 결과 패널 배치에 반영한다. 행 단위 데이터 기준이다.
    검증에 실패하면 오류 목록과 쓸 수 있는 필드를 JSON으로 돌려주고 아무것도 바꾸지 않는다. 사용자가 추가한 차트(group user)는 그 보기의 layout에 쌓인다.

    입력: conv — 대화, args — 도구 인자(run_id · view · add · update · remove · cols), emit — 화면 이벤트 전달 함수
    반환: 요약 문자열(성공) 또는 오류 JSON 문자열
    부작용: 결과 layout 갱신, 'charts' 이벤트 전송
    """
    rid0, _st0, view0 = screen_target(conv)
    rid = args.get("run_id") or rid0
    st = conv.runs.get(rid)
    if not st or not st["ui"].get("views"):  # 보기가 없는 결과면 지금 화면의 결과에 그린다
        rid, st = rid0, conv.runs.get(rid0)
        if not st:
            raise cd.PipelineError("차트를 그릴 결과가 없습니다.", {"runs": list(conv.runs)})
    ui = st["ui"]
    view = next((v for v in ui["views"] if v["id"] == args.get("view")), None) or (view0 if rid == rid0 and view0 else default_view(ui))
    ds = _editable_dataset(ui, view)
    if not ds:
        raise cd.PipelineError("이 결과에는 차트를 추가할 데이터가 없습니다.")
    fields = ui["datasets"][ds]["fields"]
    lay = _layout(st, view["id"])
    current = {c["id"]: c for c in effective_charts(st, view)}
    errors, add, update = [], [], []
    for spec in args.get("add") or []:
        spec = {**spec, "dataset": ds, "group": "user", "id": "u-" + uuid.uuid4().hex[:6]}
        e = C.validate_chart(spec, fields)
        (errors.extend(e) if e else add.append({k: v for k, v in spec.items() if v is not None}))
    for u in args.get("update") or []:
        cur = current.get(u.get("id"))
        if not cur:
            errors.append(f"차트 id '{u.get('id')}'가 없습니다. 가능: {list(current)[:40]}")
            continue
        merged = {**cur, **{k: v for k, v in u.items() if k not in ("id", "dataset", "group")}}
        if cur["type"] not in C.EDITABLE_TYPES or ui["datasets"].get(cur["dataset"], {}).get("editable") is not True:
            bad = [k for k in u if k not in ("id", "title", "span")]
            if bad:
                errors.append(f"차트 '{cur.get('title')}'는 제목·너비만 바꿀 수 있습니다(바꾸려던 항목: {bad}). 대신 새 차트를 추가하세요.")
                continue
            update.append(merged)
            continue
        e = C.validate_chart(merged, fields)
        (errors.extend(e) if e else update.append(merged))
    groups = {g["id"] for g in view.get("chart_groups") or []} | {"user"}
    cols = {k: int(v) for k, v in (args.get("cols") or {}).items() if k in groups and str(v) in ("1", "2", "3")}
    if [k for k in (args.get("cols") or {}) if k not in groups]:
        errors.append(f"차트 묶음 id가 없습니다. 가능: {sorted(groups)}")
    remove = [r for r in args.get("remove") or [] if r in current]
    if [r for r in args.get("remove") or [] if r not in current]:
        errors.append(f"삭제할 차트 id가 없습니다. 가능: {list(current)[:40]}")
    if errors:
        avail = ", ".join(f"{f['key']}({f['label']})" for f in fields[:90])
        return json.dumps({"error": "차트 spec 오류", "detail": errors, "available_fields": avail}, ensure_ascii=False)
    added_ids = {c["id"] for c in lay["added"]}  # 서버도 화면과 같은 배치를 유지한다(다음 편집이 지금 화면 기준이 되게)
    lay["added"] = [next((u for u in update if u["id"] == c["id"]), c) for c in lay["added"] if c["id"] not in remove] + add
    for u in update:
        if u["id"] not in added_ids:
            lay["overrides"][u["id"]] = u
    lay["removed"] += [r for r in remove if r not in added_ids]
    lay["cols"].update(cols)
    emit({"type": "charts", "target": rid, "view": view["id"], "ops": {"add": add, "update": update, "remove": remove, "cols": cols}})
    title = lambda c: c.get("title") or c["id"]  # noqa: E731
    done = ([f"추가: {', '.join(title(c) for c in add)}"] if add else []) + ([f"변경: {', '.join(title(c) for c in update)}"] if update else []) + \
           ([f"삭제: {', '.join(title(current[r]) for r in remove)}"] if remove else []) + ([f"열 수: {cols}"] if cols else [])
    return (f"반영 완료(보기 '{view['label']}') — " + (" / ".join(done) or "바뀐 것 없음") +
            ". 시스템 프롬프트의 '현재 결과 패널'에는 이 편집이 이미 반영돼 있다(방금 추가한 차트가 거기 보이는 것은 중복이 아니다).")


AGG_LABEL = {"mean": "평균", "median": "중앙값"}


def _group_table(st: dict, ds: str, fmap: dict, gt: dict, unit: str) -> tuple[dict | None, list, str]:
    """그룹별 집계 표(블록 카탈로그의 table)를 만든다. 행 = 수치 필드, 열 = 그룹 값(요청한 순서, 없으면 이름 순, 최대 6개).
    그룹이 두 개면 차이(첫째 − 둘째)와 표준편차 단위 차이를 더한다.

    입력: st — 결과 상태(frames 포함), ds — 데이터셋 키, fmap — 필드 키 → 필드 정보, gt — group_table 요청(by · fields · agg · order), unit — 행 단위 이름
    반환: (표 dict 또는 None, 오류 목록, LLM에 돌려줄 마크다운)
    """
    by, flds, agg = gt.get("by"), [f for f in dict.fromkeys(gt.get("fields") or [])], gt.get("agg") or "mean"
    cats = [k for k, f in fmap.items() if f.get("type") == "cat"]
    errs = []
    if by not in fmap or fmap[by].get("type") != "cat":
        errs.append(f"그룹 필드 '{by}'는 범주형 필드가 아닙니다. 가능: {cats[:25]}")
    bad = [f for f in flds if fmap.get(f, {}).get("type") != "num"]
    if bad or not flds:
        errs.append(f"수치 필드가 아닙니다: {bad or '없음'}")
    if agg not in AGG_LABEL:
        errs.append(f"agg는 {list(AGG_LABEL)} 중 하나")
    frame = st["frames"].get(ds) if ds in st["frames"] else st["frames"].get(ds.split(":")[-1])
    if frame is None:
        errs.append("이 결과의 행 데이터가 없습니다.")
    if errs:
        return None, errs, ""
    g = frame[by].astype(str)
    have = list(g.value_counts().index)
    order = [str(v) for v in gt.get("order") or [] if str(v) in have]
    groups = (order or sorted(have))[:6]  # 열 순서: 요청한 순서, 없으면 이름 순(같은 요청이면 같은 표)
    if len(groups) < 2:
        return None, [f"'{fmap[by]['label']}' 값이 하나뿐이라 그룹을 비교할 수 없습니다."], ""
    two = len(groups) == 2
    cols = [{"key": "label", "label": "변수", "type": "text"}] + \
           [{"key": f"g{i}", "label": f"{v} ({int((g == v).sum()):,}{unit})", "type": "num", "digits": 4} for i, v in enumerate(groups)]
    if two:
        cols += [{"key": "diff", "label": f"차이({groups[0]} − {groups[1]})", "type": "num", "digits": 4},
                 {"key": "es", "label": "차이(표준편차 단위)", "type": "num", "digits": 2}]
    rows = []
    for f in flds:
        v = pd.to_numeric(frame[f], errors="coerce")
        stat = {x: (v[g == x].mean() if agg == "mean" else v[g == x].median()) for x in groups}
        row = {"label": fmap[f]["label"], **{f"g{i}": (None if pd.isna(stat[x]) else float(stat[x])) for i, x in enumerate(groups)}}
        if two and row["g0"] is not None and row["g1"] is not None:
            sd = float(np.sqrt((v[g == groups[0]].var() + v[g == groups[1]].var()) / 2))
            row["diff"] = row["g0"] - row["g1"]
            row["es"] = row["diff"] / sd if sd > 0 else None
        rows.append(row)
    title = f"{fmap[by]['label']}별 {AGG_LABEL[agg]}"
    md = f"표 '{title}'\n| 변수 | " + " | ".join(c["label"] for c in cols[1:]) + " |\n" + "|---" * len(cols) + "|\n" + \
        "\n".join("| " + " | ".join([r["label"]] + [("-" if r.get(c["key"]) is None else f"{r[c['key']]:.4g}") for c in cols[1:]]) + " |" for r in rows)
    return {"type": "table", "id": "group_table", "title": title, "columns": cols, "rows": rows}, [], md


def add_section(conv: Conversation, args: dict, emit) -> str:
    """결과의 보기(사용자가 보고 있는 것) 맨 아래에 표·차트 묶음을 덧붙인다: 그룹별 집계 표와 차트를 블록 카탈로그 안에서, 그 결과의 행 데이터로 만든다.
    기본 화면(양식)은 그대로 두고 아래로 이어 붙인다(화면과 PDF에서 한 흐름으로 읽히게). 표나 차트 중 하나는 있어야 하고, 검증에 실패하면 오류 JSON을 돌려주고 아무것도 바꾸지 않는다.

    입력: conv — 대화, args — 도구 인자(run_id · title · note · group_table · charts · cols), emit — 화면 이벤트 전달 함수
    반환: 요약 문자열(표·차트 개수, 덧붙인 표의 마크다운 포함) 또는 오류 JSON 문자열
    부작용: 보기에 묶음 추가, conv.screen을 그 위치로 이동, 'section' 이벤트 전송
    """
    rid0, _st0, view0 = screen_target(conv)
    rid = args.get("run_id") or rid0
    st = conv.runs.get(rid)
    if not st or not st["ui"].get("views"):
        raise cd.PipelineError("표·차트를 덧붙일 결과가 없습니다.", {"runs": list(conv.runs)})
    ui = st["ui"]
    view = view0 if rid == rid0 and view0 else default_view(ui)
    ds = _editable_dataset(ui, view)
    if not ds:
        raise cd.PipelineError("이 결과에는 표·차트를 만들 행 데이터가 없습니다.")
    fields = ui["datasets"][ds]["fields"]
    fmap = {f["key"]: f for f in fields}
    gid = "s-" + uuid.uuid4().hex[:6]
    errors, sections, charts, md = [], [], [], ""
    if args.get("group_table"):
        try:
            unit = W.source_profile(st["res"].get("cfg", {}).get("source") or conv.source)["unit"]
        except Exception:  # noqa: BLE001
            unit = "행"
        tbl, e, md = _group_table(st, ds, fmap, args["group_table"], unit)
        errors += e
        if tbl:
            sections.append(tbl)
    for spec in args.get("charts") or []:
        spec = {**spec, "dataset": ds, "group": gid, "id": f"{gid}-{len(charts) + 1}"}
        e = C.validate_chart(spec, fields)
        (errors.extend(e) if e else charts.append({k: v for k, v in spec.items() if v is not None}))
    if not errors and not sections and not charts:
        errors.append("표(group_table)나 차트(charts) 중 하나는 있어야 합니다.")
    title = (args.get("title") or args.get("label") or "추가 분석").strip()[:30]
    group = {"id": gid, "title": title, "cols": int(args.get("cols") or 2), "note": (args.get("note") or "").strip(), "sections": sections, "user": True}
    after = {**view, "chart_groups": list(view.get("chart_groups") or []) + [group], "charts": list(view["charts"]) + charts}
    errors += Lay.validate(after, "view") if not errors else []
    if errors:
        avail = ", ".join(f"{f['key']}({f['label']}, {f.get('type')})" for f in fields[:90])
        return json.dumps({"error": "표·차트 spec 오류", "detail": errors, "available_fields": avail}, ensure_ascii=False)
    if not view.get("chart_groups") and view["charts"]:  # 묶음 없이 차트만 있던 보기: 기존 차트를 한 묶음으로 둔다(덧붙인 묶음과 섞이지 않게)
        view["chart_groups"] = [{"id": "main", "title": "차트", "cols": 2}]
        for c in view["charts"]:
            c.setdefault("group", "main")
    view.setdefault("chart_groups", []).append(group)
    view["charts"] += charts
    conv.screen = {"run_id": rid, "view_id": view["id"]}
    emit({"type": "section", "target": rid, "view": view["id"], "group": group, "charts": charts})
    return (f"결과 아래에 '{title}' 묶음을 덧붙였다(표 {len(sections)}개 · 차트 {len(charts)}개). 화면은 그 위치로 이동했다. "
            "시스템 프롬프트의 '현재 결과 패널'에 이미 반영돼 있다." + (f"\n\n{md}" if md else ""))

def make_pdf(conv: Conversation, rid: str | None, emit=None, images=None) -> str:
    """실행 결과 하나를 PDF로 만든다. PDF를 만드는 곳은 common/report.py 하나다(결과 종류와 무관하게 같은 모양).

    담는 것: 결과 제목 · 핵심 지표 · 적용된 설정(화면 그대로) → 해석 글 → skill이 넘긴 표(report_parts) → 결과 아래 덧붙인 표 →
    그림(화면 캡처가 있으면 그것, 없으면 skill이 넘긴 그림).
    입력: conv — 대화, rid — 실행 id, emit — 화면 이벤트 전달 함수(없으면 링크 없음), images — 화면 캡처 이미지 경로 목록(없을 수 있음)
    반환: 담긴 내용을 적은 안내 문장. 부작용: PDF 파일 생성, 'file' 이벤트(내려받기 링크). 결과가 없으면 cd.PipelineError.
    """
    from common import report
    st = conv.runs.get(rid)
    if not st:
        raise cd.PipelineError(f"실행 결과 {rid}를 찾을 수 없습니다.", {"runs": list(conv.runs)})
    ui, mod = st["ui"], SKILLS[st["skill"]].module
    parts = mod.report_parts(st["res"]) if hasattr(mod, "report_parts") else {}
    fmt = lambda v: "-" if v is None else (f"{v:.4g}" if isinstance(v, float) else str(v))  # noqa: E731
    added = [{"type": "table", "title": g["title"] + (f" — {t['title']}" if t.get("title") else ""),
              "columns": [c["label"] for c in t["columns"]], "rows": [[fmt(r.get(c["key"])) for c in t["columns"]] for r in t["rows"]]}
             for v in ui.get("views") or [] for g in v.get("chart_groups") or [] if g.get("user")
             for t in g.get("sections") or [] if t.get("type") == "table"]
    interp = conv.interpretations.get(rid, "")
    blocks = [{"type": "md", "title": "해석", "text": interp}] + list(parts.get("tables") or []) + added + [
        {"type": "images", "title": "차트 (화면에서 보던 구성)" if images else "차트", "paths": list(images or parts.get("images") or [])}]
    applied = [(a["label"], a["value"]) for a in ui.get("applied") or []]
    items = [(m["label"], f"{m['value']}{m.get('unit') or ''}") for m in ui.get("metrics") or []
             if m["label"] not in {k for k, _ in applied}] + applied  # 핵심 지표(적용된 설정과 겹치는 것 빼고) → 적용된 설정
    path = report.build(os.path.join(st.get("output_dir") or OUTPUT_DIR, parts.get("file") or f"report_{rid}.pdf"),
                        {"title": ui.get("title"), "subtitle": " · ".join(x for x in [ui.get("subtitle"), time.strftime("%Y-%m-%d %H:%M")] if x),
                         "items": items, "blocks": blocks})
    fname = os.path.basename(path)
    if emit:
        emit({"type": "file", "name": fname, "url": f"/api/files/{rid}/{fname}"})
    has = ["적용된 설정", "해석" if interp else None, "결과 표" if parts.get("tables") else None,
           f"덧붙인 표 {len(added)}개" if added else None, f"화면 차트 {len(images)}개" if images else ("차트" if parts.get("images") else None)]
    return f"PDF를 만들었다: {fname} (담긴 것: {', '.join(h for h in has if h)}). 담긴 것만 말한다."


def ask_genie(conv: Conversation, question: str, emit) -> str:
    """Genie Agent에 자연어 조회를 보내고 결과를 대화에 '원본 조회' 오브젝트로 남긴다. LLM에는 표 앞부분(GENIE_LLM_ROWS행)과 전체 행 수를 준다.
    Genie 대화(conv.genie_cid)를 이어 쓴다. 표 결과가 없으면 Genie의 답 문장을 돌려준다.

    입력: conv — 대화, question — 조회 질문(한국어), emit — 화면 이벤트 전달 함수
    반환: LLM에 돌려줄 문자열(조회 id · 설명 · SQL · 표 마크다운, 또는 Genie 답 JSON)
    부작용: 'lookup' 이벤트 전송, conv.lookups · conv.genie_cid 갱신
    """
    emit({"type": "tool_progress", "text": "조회 쿼리를 만들어 실행하는 중"})
    r = G.ask(question + " 결과 열 이름은 한국어로 해줘.", conv.genie_cid)  # 화면 표의 열 이름도 사람 말로
    conv.genie_cid = r["conversation_id"]
    if r["status"] != "COMPLETED" or not r["columns"]:
        return json.dumps({"genie_text": r["text"], "status": r["status"], "note": "표 결과가 없다. Genie 답을 바탕으로 한두 문장으로 안내한다."}, ensure_ascii=False)
    lid = cd.run_id("q_")
    conv.lookups[lid] = {**r, "question": question}
    asked = next((m["content"] for m in reversed(conv.messages) if m.get("role") == "user" and isinstance(m.get("content"), str)), "") or question
    emit({"type": "lookup", "data": {"id": lid, "question": question, "title": asked[:80], "description": r["description"], "sql": r["sql"],
                                     "columns": r["columns"], "rows": r["rows"], "n_rows": r["n_rows"]}})
    head = r["rows"][:GENIE_LLM_ROWS]
    md = "| " + " | ".join(r["columns"]) + " |\n|" + "---|" * len(r["columns"]) + "\n" + \
        "\n".join("| " + " | ".join("" if v is None else str(v) for v in row) + " |" for row in head)
    part = f" 중 앞 {len(head)}행만 여기 있음 — 전체에 대한 합계·평균·최대 같은 결론은 쓰지 말고, 필요하면 집계 질문으로 다시 조회" if r["n_rows"] > len(head) else ""
    return (f"조회 결과 `{lid}` (원본 데이터 기준 — 작업 데이터의 처리는 반영되지 않음, 전체 {r['n_rows']}행{part}) — 대화에 표 오브젝트로 표시됨\n"
            f"Genie 설명: {r['description'] or '-'}\nSQL: {r['sql']}\n\n{md}")


def runtime_tool(conv: Conversation, name: str, args: dict, emit) -> str:
    """실행기 도구를 실행한다(ask_genie · save_pdf · edit_charts · add_section). skill 도구는 여기서 다루지 않는다.
    save_pdf는 화면이 있으면 화면 캡처를 요청하는 pdf_capture 이벤트를 보내고 안내 문장을 돌려준다. 화면이 없으면 바로 PDF를 만든다.

    입력: conv — 대화, name — 도구 이름, args — 도구 인자, emit — 화면 이벤트 전달 함수
    반환: LLM에 돌려줄 문자열
    예외: 알 수 없는 도구이거나 결과가 없으면 cd.PipelineError를 던진다.
    """
    if name == "ask_genie":
        return ask_genie(conv, args.get("question") or "", emit)
    if name == "save_pdf":
        rid = args.get("run_id") or conv.last_run_id
        if rid not in conv.runs:
            raise cd.PipelineError(f"실행 결과 {rid}를 찾을 수 없습니다.", {"runs": list(conv.runs)})
        if (conv.screen or {}).get("ui"):  # 화면이 있으면 보고 있는 차트까지 담도록 화면에 캡처를 요청
            emit({"type": "pdf_capture", "run_id": rid})
            return "PDF를 만드는 중이다. 결과 표·해석·엔진 차트에 더해, 사용자가 지금 보고 있는 보기의 차트(화면 캡처, 덧붙인 차트 포함)와 덧붙인 표가 들어간다. 대화창에 내려받기 링크가 표시된다."
        with ENGINE_LOCK:
            return make_pdf(conv, rid, emit)
    if name == "edit_charts":
        return edit_charts(conv, args, emit)
    if name == "add_section":
        return add_section(conv, args, emit)
    raise cd.PipelineError(f"알 수 없는 도구: {name}")


def tool_label(name: str) -> str:
    owner = TOOL_OWNER.get(name)
    return RUNTIME_LABELS.get(name) or (SKILLS[owner].labels.get(name) if owner else None) or name


def execute_tool(conv: Conversation, name: str, args: dict, emit) -> tuple[str, bool, tuple | None]:
    """도구 하나를 실행한다. load_skill은 skill 지침을 돌려주고 그 skill의 도구를 연다. skill 도구는 실행 전에 테이블을 확인하고 정한다(cfg.source → 등록 테이블, 바뀌면 화면에 알림).
    오류는 예외로 던지지 않고 JSON 문자열로 LLM에 돌려준다(턴은 이어간다).

    입력: conv — 대화, name — 도구 이름, args — 도구 인자(dict), emit — 화면 이벤트 전달 함수
    반환: (LLM에 돌려줄 문자열, 턴 종료 여부(항상 False), 결과 (kind, id) 또는 None)
    부작용: conv.loaded 갱신(skill 도구 첫 사용), 도구 시작·끝 이벤트 전송, 작업 데이터 갱신 가능
    """
    if name == "load_skill":
        sk = args.get("name")
        if sk not in SKILLS:
            return json.dumps({"error": f"없는 skill: {sk}", "skills": list(SKILLS)}, ensure_ascii=False), False, None
        if SKILLS[sk].always or sk in conv.loaded:
            return f"{sk}는 이미 열려 있다. 그 지침을 따른다.", False, None
        conv.loaded.append(sk)
        emit({"type": "skill", "name": sk, "title": SKILLS[sk].title})
        return skill_doc(sk), False, None
    owner = TOOL_OWNER.get(name)
    if owner and not SKILLS[owner].always and owner not in conv.loaded:
        conv.loaded.append(owner)
    label = tool_label(name)
    from_result = set(getattr(SKILLS[owner].module, "FROM_RESULT_TOOLS", ())) if owner else set()  # 이전 결과에서 일하는 도구: 테이블을 몰라도 되고 작업 데이터를 바꾸지 않는다
    try:  # 테이블: LLM이 고른 이름 → 등록 테이블, 바뀌면 대화의 테이블로(도구 줄보다 먼저 대화에 데이터 한 줄). 첫 제안이 없으면 여기서 받는다
        if owner and name not in from_result and isinstance(args.get("cfg"), dict):
            W.prefetch(conv, args["cfg"])  # 첫 제안을 받는 동안 범위 데이터를 같이 읽는다
        if owner and isinstance(args.get("cfg"), dict) and args["cfg"].get("source"):
            src = W.resolve_source(args["cfg"]["source"])
            args["cfg"]["source"] = src
            if S.source_key(src) != S.source_key(conv.source):
                W.set_source(conv, src, emit)
                bad = W.unknown_values(src, args["cfg"])
                if bad:  # 테이블을 막 정해서 LLM이 값을 못 본 채 썼다 → 그 테이블의 컬럼 표(값)를 보여 주고 다시 쓰게 한다
                    return (f"대화의 테이블을 `{S.source_key(src)}`로 정했다. 필터 값 {bad}가 이 테이블에 없다. 아래 컬럼 표의 값 그대로 cfg를 다시 써서 "
                            f"같은 도구를 다시 부른다(묻지 않는다).\n\n{W.source_md(src)}"), False, None
        elif owner and not conv.source and name not in from_result:
            raise cd.PipelineError("이 대화의 테이블을 아직 정하지 않았습니다. 질문에 맞는 등록 테이블 이름을 cfg의 source에 넣어 다시 부르세요.",
                                   {"registered": [i["name"] for i in S.data_items(S.list_sources(W.backend())) if i["kind"] == "테이블"]})
        if owner:
            W.activate(conv, emit=emit)  # 데이터 패널에서 고른 테이블이면 여기서 첫 제안을 받는다
    except cd.PipelineError as e:
        return json.dumps({"error": str(e), "detail": e.detail}, ensure_ascii=False, default=str), False, None
    except Exception as e:  # noqa: BLE001  (테이블 확인 중 오류도 LLM에 돌려준다 — 턴은 이어간다)
        return json.dumps({"error": f"{type(e).__name__}: {e}"}, ensure_ascii=False), False, None
    t0 = time.time()
    quiet = name == "save_pdf" and bool((conv.screen or {}).get("ui"))  # 화면이 차트를 담아 PDF를 만든다(도구 줄은 화면이 띄움)
    emit({"type": "tool_start", "name": name, "label": label, "skill": owner, "args": args, "silent": quiet})
    try:
        target = None
        if owner:
            mod = SKILLS[owner].module
            if isinstance(args.get("cfg"), dict) and hasattr(mod, "ENGINE_DEFAULTS") and name not in from_result:
                W.remember_work(conv, merged_cfg(owner, args["cfg"], conv))  # 분석에서 정한 공통 데이터 처리는 작업 데이터에도 남긴다
            with (ENGINE_LOCK if getattr(mod, "LOCK", True) else contextlib.nullcontext()):
                r = mod.handle(name, args, Ctx(conv, owner, emit))
            out, target = r["text"], r.get("summarize")
            if target:
                conv.last_run_id = target[1]
                conv.screen = {"run_id": r.get("screen") or target[1]}  # 새 결과가 화면에 뜬다
        else:
            out = runtime_tool(conv, name, args, emit)
        emit({"type": "tool_end", "name": name, "ok": True, "ms": int((time.time() - t0) * 1000), "summary": out[:1500], "silent": quiet})
        return out, False, target
    except cd.PipelineError as e:
        emit({"type": "tool_end", "name": name, "ok": False, "ms": int((time.time() - t0) * 1000), "error": str(e)})
        return json.dumps({"error": str(e), "detail": e.detail}, ensure_ascii=False, default=str), False, None
    except Exception as e:  # noqa: BLE001
        emit({"type": "tool_end", "name": name, "ok": False, "ms": int((time.time() - t0) * 1000), "error": str(e)})
        return json.dumps({"error": f"{type(e).__name__}: {e}"}, ensure_ascii=False), False, None


# ----------------------------------------------------------------------------- 시스템 프롬프트

def registered_md(cur) -> str:
    """등록 테이블마다 이름 · 설명 · 컬럼(이름 · 형식 · 설명) — Unity Catalog 메타데이터만(LLM이 질문에 맞는 테이블을 고르는 근거).
    값 · 역할 · 정상범위가 담긴 컬럼 표는 이 대화의 테이블만("이 대화의 데이터 소스" 절)."""
    try:
        items = [i for i in S.data_items(S.list_sources(W.backend())) if i["kind"] == "테이블"]
    except Exception as e:  # noqa: BLE001
        return f"(목록을 읽지 못함: {type(e).__name__})"
    out = []
    for i in items:
        mark = " ← 이 대화의 테이블" if S.source_key(cur) == i["name"] else ""
        cols = "\n".join(f"  - `{c['column']}` ({c['type']}){': ' + c['comment'][:80] if c['comment'] else ''}" for c in i["col_info"])
        out.append(f"## `{i['short']}` — `{i['name']}`{mark}\n설명: {i['comment'] or '-'}\n컬럼:\n{cols}")
    return "\n\n".join(out)


def system_prompt(conv: Conversation) -> str:
    """턴마다 시스템 프롬프트를 조립한다: prompt_app.md 기본 지침 + 분석 skill 목록(열린 것 표시) + 항상 열린 skill 지침 + 등록 테이블 + 이 대화의 소스와 작업 데이터 + 현재 결과 패널 + 오늘 날짜.

    입력: conv — 대화
    반환: 프롬프트 문자열. 소스 컬럼 표를 읽지 못하면 그 절에 오류 한 줄을 넣고 계속한다.
    """
    with open(os.path.join(HERE, "prompt_app.md"), encoding="utf-8") as f:
        base = f.read()
    cur = conv.source
    on_demand = "\n".join(f"- `{s.name}` ({s.title}): {s.description}" for s in SKILLS.values() if not s.always)
    always = "\n\n".join(skill_doc(s.name) for s in SKILLS.values() if s.always)
    opened = "\n\n".join(f"(열려 있음: {n})" for n in conv.loaded)
    parts = [base, "# 분석 skill (load_skill로 연다)\n" + on_demand + ("\n" + opened if opened else ""), "# 항상 열린 skill (데이터 처리)\n" + always,
             "# 등록된 테이블 (질문에 맞는 테이블을 고른다)\n" + registered_md(cur)]
    if cur:
        try:
            data = W.source_md(cur)
        except Exception as e:  # noqa: BLE001
            data = f"(컬럼 표를 읽지 못함: {type(e).__name__})"
        parts += [f"# 이 대화의 데이터 소스\n{W.source_label(cur)} — `{S.source_key(cur)}`. 질문이 다른 등록 테이블에 맞으면 도구 cfg의 `source`로 바꾼다.\n{data}",
                  "# 이 대화의 작업 데이터 (공통 데이터 처리. 분석 cfg는 이 값 위에 요청한 키만 덮어쓴다)\n" + W.work_md(conv, cur)]
    else:
        parts.append("# 이 대화의 데이터 소스\n아직 정하지 않았다. 질문에 맞는 등록 테이블을 골라 그 도구 cfg의 `source`에 이름을 넣는다(묻지 않는다). "
                     "Genie 원본 조회는 질문에 테이블 짧은 이름을 넣는다.")
    if conv.runs:
        parts.append("# 현재 결과 패널 (이전 편집이 모두 반영된 지금 상태. 차트 편집은 이 차트 id·필드 키로)\n" + screen_md(conv))
    parts.append(f"오늘 날짜: {time.strftime('%Y-%m-%d')}")
    return "\n\n".join(parts)


# ----------------------------------------------------------------------------- LLM 호출

_SYNC_CLIENT = None


def _client():
    """동기 LLM 클라이언트(첫 제안 · 후속 질문). 한 번 만들어 같이 쓴다 — 요청마다 SDK가 인증 헤더를 새로 붙인다."""
    global _SYNC_CLIENT
    if _SYNC_CLIENT is None:
        from databricks.sdk import WorkspaceClient
        _SYNC_CLIENT = WorkspaceClient().serving_endpoints.get_open_ai_client(max_retries=4)
    return _SYNC_CLIENT


def _text_of(content) -> str:
    """content가 문자열 또는 블록 리스트([{type: text, text}, ...])인 경우 모두 텍스트만 뽑는다."""
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    out = []
    for b in content:
        if isinstance(b, dict):
            if b.get("type") in (None, "text"):
                out.append(b.get("text") or "")
        else:
            t = getattr(b, "text", None)
            if t and getattr(b, "type", "text") == "text":
                out.append(t)
    return "".join(out)


RETRY_WAITS = [5, 10, 20, 30]  # 모델 분당 호출 한도(429)에 걸렸을 때 기다릴 초


def _rate_limited(e: Exception) -> bool:
    t = f"{type(e).__name__} {e}"
    return "RateLimit" in t or "429" in t or "REQUEST_LIMIT_EXCEEDED" in t


def error_text(e: Exception) -> str:
    """화면에 보일 오류 문장을 만든다. 모델 호출 한도 오류는 사람이 할 일(잠시 뒤 다시 보내기)을 알려 준다.

    입력: e — 예외 객체
    반환: 한 문장 문자열
    """
    if _rate_limited(e):
        return "요청이 몰려 몇 번 다시 시도했지만 응답을 받지 못했습니다. 1분쯤 뒤에 같은 요청을 다시 보내 주세요."
    return f"{type(e).__name__}: {e}"


def _create(client, emit, **kw):
    """LLM 호출(chat.completions.create)을 한다. 분당 한도(429)면 RETRY_WAITS 초만큼 기다렸다 다시 부른다(최대 4회). 기다리는 동안 작업 상태에 그 사실을 표시한다.

    입력: client — OpenAI 클라이언트, emit — 화면 이벤트 전달 함수, kw — create 인자(model · messages 등)
    반환: 응답 객체. 한도 외 오류나 재시도 소진이면 예외를 그대로 던진다.
    """
    for k, wait in enumerate(RETRY_WAITS + [None]):
        try:
            return client.chat.completions.create(**kw)
        except Exception as e:  # noqa: BLE001
            if wait is None or not _rate_limited(e):
                raise
            emit({"type": "activity", "text": f"요청이 몰려 {wait}초 뒤 다시 시도하는 중 ({k + 1}/{len(RETRY_WAITS)})"})
            time.sleep(wait)


# ----------------------------------------------------------------------------- 후속 질문

def _next_steps(skill: str) -> str:
    """SKILL.md의 '다음 단계' 절(후속 질문 힌트)."""
    m = re.search(r"^## 다음 단계[^\n]*\n(.*?)(?=^## |\Z)", skill_doc(skill), re.M | re.S)
    return m.group(1).strip() if m else ""


def followups(conv: Conversation, user_text: str, answer: str, seen: list, client, emit) -> None:
    """이번 턴을 보고 사용자가 이어서 물어볼 만한 질문 3개를 만들어 화면에 보낸다(입력창 위 칩). 보조 기능이라 실패해도 조용히 넘어가며, 턴은 이미 끝난 상태다.

    입력: conv — 대화, user_text — 사용자 질문, answer — 이번 턴의 글(뒤쪽 1800자만 사용), seen — 이번 턴에 부른 도구 이름표 목록, client — OpenAI 클라이언트, emit — 화면 이벤트 전달 함수
    반환: 없음(부작용: 'followups' 이벤트 전송)
    """
    try:
        if conv.source:
            prof = W.source_profile(conv.source)
            data = {"table": prof["title"], "rows": prof["rows"], "unit": prof["unit"], "default_y": (prof.get("y") or {}).get("label"),
                    "other_ys": [y["label"] for y in prof.get("ys", [])][:6], "date_range": prof.get("date_range"),
                    "dims": {d["label"]: d["values"][:8] for d in prof.get("dims", [])}}
        else:  # 아직 테이블을 정하지 않은 대화(원본 조회만 했을 때): 등록 테이블 설명만
            data = {"tables": [{"name": i["short"], "description": i["comment"][:120]} for i in S.data_items(S.list_sources(W.backend()))]}
        payload = {"user": user_text, "answer": (answer or "")[-1800:], "this_turn": seen, "data": data,
                   "can_do": [f"{t}: {sm}" for t, sm in capabilities()],
                   "next_step_hints": {SKILLS[n].title: _next_steps(n) for n in conv.loaded if _next_steps(n)},
                   "today": time.strftime("%Y-%m-%d")}
        with open(os.path.join(HERE, "followup_prompt.md"), encoding="utf-8") as f:
            system = f.read()
        r = _create(client, emit, model=FOLLOWUP_MODEL, max_tokens=400, messages=[
            {"role": "system", "content": system}, {"role": "user", "content": json.dumps(payload, ensure_ascii=False, default=str)}])
        m = re.search(r"\[.*\]", _text_of(r.choices[0].message.content), re.S)
        items = [str(x).strip() for x in (json.loads(m.group(0)) if m else []) if isinstance(x, str) and x.strip()][:3]
        if items:
            emit({"type": "followups", "items": items})
    except Exception:  # noqa: BLE001  (보조 기능이라 실패해도 턴은 끝난 상태)
        pass


# ----------------------------------------------------------------------------- 한 턴

def _sync_screen(conv: Conversation, screen: dict | None):
    """화면에서 바꾼 차트 배치를 서버 상태에 반영한다(대화로 차트를 고칠 때 지금 화면이 기준)."""
    if screen and screen.get("run_id") in conv.runs:
        conv.screen = screen
        if screen.get("view_id") and isinstance(screen.get("layout"), dict):
            lay = screen["layout"]
            conv.runs[screen["run_id"]].setdefault("layouts", {})[screen["view_id"]] = {
                "removed": list(lay.get("removed") or []), "overrides": dict(lay.get("overrides") or {}),
                "added": list(lay.get("added") or []), "cols": dict(lay.get("cols") or {})}
    elif screen and not conv.screen:
        conv.screen = screen


# ----------------------------------------------------------------------------- 에이전트 (OpenAI Agents SDK, MLflow ResponsesAgent 형식으로 내보냄)

def _blocks_text(content):
    """Claude 응답 content가 블록 목록(추론 블록 포함)이면 글 블록만 이어 붙인다. 문자열·None은 그대로."""
    if isinstance(content, list):
        return "".join(p.get("text", "") if isinstance(p, dict) else getattr(p, "text", "") or "" for p in content
                       if (p.get("type") if isinstance(p, dict) else getattr(p, "type", None)) in (None, "text")) or None
    return content


class _TextOnlyStream:
    """스트림 조각의 delta.content를 글만 남긴 문자열로(Agents SDK는 글 문자열을 기대한다)."""
    def __init__(self, inner):
        self._inner = inner

    def __aiter__(self):
        return self._gen()

    async def _gen(self):
        async for ch in self._inner:
            for c in ch.choices or []:
                if isinstance(getattr(c.delta, "content", None), list):
                    c.delta.content = _blocks_text(c.delta.content)
            yield ch

    def __getattr__(self, name):
        return getattr(self._inner, name)


def _text_only_completions():
    """비동기 chat.completions.create가 글만 남긴 응답을 돌려주게 한다(이 앱의 비동기 OpenAI 호출은 Agents SDK뿐).
    Claude 응답 content가 추론 블록이 섞인 목록으로 오면 Agents SDK가 글 문자열을 기대해 실패한다."""
    from openai.resources.chat.completions import AsyncCompletions
    if getattr(AsyncCompletions.create, "_text_only", False):
        return
    create = AsyncCompletions.create

    async def create_text_only(self, *args, **kw):
        r = await create(self, *args, **kw)
        if kw.get("stream"):
            return _TextOnlyStream(r)
        for c in getattr(r, "choices", None) or []:
            c.message.content = _blocks_text(c.message.content)
        return r

    create_text_only._text_only = True
    AsyncCompletions.create = create_text_only


_text_only_completions()


class _DatabricksAuth(httpx.Auth):
    """요청마다 Databricks SDK 인증 헤더(앱에서는 서비스 주체 OAuth, 로컬에서는 프로필)를 붙인다 — 토큰이 만료돼도 SDK가 새로 받는다."""
    def __init__(self):
        from databricks.sdk import WorkspaceClient
        self.cfg = WorkspaceClient().config

    def auth_flow(self, request):
        for k, v in self.cfg.authenticate().items():
            request.headers[k] = v
        yield request


def _llm_client() -> AsyncOpenAI:
    """Model Serving(Claude)의 OpenAI 호환 엔드포인트 — Agents SDK가 쓰는 비동기 클라이언트."""
    auth = _DatabricksAuth()
    return AsyncOpenAI(base_url=f"{auth.cfg.host.rstrip('/')}/serving-endpoints", api_key="databricks", max_retries=4,
                       http_client=httpx.AsyncClient(auth=auth, timeout=httpx.Timeout(600, connect=30)))


set_default_openai_client(_llm_client())  # 앱 서비스 주체 권한(앱 리소스 serving-endpoint CAN_QUERY)
W.configure(client=_client, model=MODEL, skills=capabilities)  # 첫 제안(데이터 처리 skill)이 쓸 LLM
threading.Thread(target=_client, daemon=True).start()  # 동기 클라이언트(첫 제안 · 후속 질문)도 켜질 때 만들어 둔다(처음 만들 때 인증 설정에 2초쯤)
set_default_openai_api("chat_completions")
set_tracing_disabled(not TRACE)  # Agents SDK 추적은 MLflow로만 간다(app.py의 mlflow.openai.autolog가 MLflow 처리기를 붙인다)
set_trace_processors([])  # Agents SDK 기본 처리기(OpenAI로 보내는 것)는 처음부터 뺀다


def _traced(name: str, conv, fn, *args):
    """fn을 이름 붙은 trace 안에서 돌린다(턴이 끝난 뒤 하는 보조 LLM 호출 — 같은 대화 id로 묶는다). 추적이 꺼져 있으면 그냥 돌린다."""
    if not TRACE:
        return fn(*args)
    import mlflow
    with mlflow.start_span(name=name, span_type="CHAIN") as sp:
        sp.set_inputs({"conversation_id": conv.id})
        try:
            mlflow.update_current_trace(metadata={"mlflow.trace.session": conv.id})
        except Exception:  # noqa: BLE001
            pass
        return fn(*args)


def _trace_meta(conv, user_text) -> None:
    """지금 trace에 대화 id(세션)와 질문을 단다(MLflow 실험에서 대화별로 묶어 보게). 추적이 꺼져 있으면 아무 일도 하지 않는다."""
    if not TRACE:
        return
    try:
        import mlflow
        mlflow.update_current_trace(metadata={"mlflow.trace.session": conv.id}, tags={"source": S.short(S.source_key(conv.source) or "") or "-"},
                                    request_preview=(user_text or "")[:200] or None)
    except Exception:  # noqa: BLE001  (추적 실패가 턴을 막지 않게)
        pass


@dataclass
class Turn:
    """한 턴의 실행 상태(Agents SDK run context). 도구가 화면에 이벤트를 보내는 통로와 해석을 기다리는 결과를 담는다.

    필드: conv — 대화 · emit — 화면 이벤트 전달 함수 · pending — 해석을 기다리는 결과 (kind, id): 결과 뒤 처음 쓴 글이 그 해석이다 ·
    seen — 이번 턴에 부른 도구 이름표(후속 질문용) · said — 이번 턴에 쓴 글 · lock — 도구는 차례로 실행한다(대화 상태를 같이 쓰므로)
    """
    conv: Conversation
    emit: object
    pending: tuple | None = None                      # 해석을 기다리는 결과 (kind, id) — 결과 뒤 처음 쓴 글이 그 해석
    seen: list = field(default_factory=list)          # 이번 턴에 부른 도구(후속 질문용)
    said: list = field(default_factory=list)          # 이번 턴에 쓴 글
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)  # 도구는 차례로(대화 상태를 같이 쓴다)


def _function_tool(spec: dict, owner: str | None = None) -> FunctionTool:
    """도구 정의(실행기 도구, 또는 skill의 tools.py TOOLS)를 Agents SDK 도구로 바꾼다. skill 도구는 그 skill을 연 뒤에만 LLM에 보인다.

    입력: spec — {"function": {name, description, parameters}} 형식의 도구 정의, owner — skill 이름(실행기 도구면 None)
    반환: FunctionTool. is_enabled: owner가 대화의 loaded에 있을 때만 켜진다. 항상 열린 skill과 실행기 도구는 늘 켜진다.
    """
    fn = spec["function"]

    async def run(ctx, args_json: str) -> str:
        """LLM이 부른 도구를 실행한다. 인자 JSON을 읽고(잘못되면 빈 dict), 턴 잠금 안에서 execute_tool을 스레드로 돌린다. 결과가 있으면 턴의 pending으로 기억한다.

        입력: ctx — Agents SDK 실행 컨텍스트(context가 Turn), args_json — 인자 JSON 문자열
        반환: 도구 결과 문자열(LLM에 돌려준다)
        """
        t: Turn = ctx.context
        try:
            args = json.loads(args_json or "{}")
        except json.JSONDecodeError:
            args = {}
        async with t.lock:
            out, _end, target = await asyncio.to_thread(execute_tool, t.conv, fn["name"], args, t.emit)
        if target:
            t.pending = target
        t.seen.append(tool_label(fn["name"]))
        return out

    sk = SKILLS.get(owner) if owner else None
    enabled = True if sk is None or sk.always else (lambda ctx, _agent, name=owner: name in ctx.context.conv.loaded)
    return FunctionTool(name=fn["name"], description=fn.get("description", ""), on_invoke_tool=run, strict_json_schema=False,
                        params_json_schema=fn.get("parameters") or {"type": "object", "properties": {}}, is_enabled=enabled)


async def _instructions(ctx, _agent) -> str:
    """시스템 프롬프트를 스레드에서 만든다. 카탈로그 조회가 들어 있어 이벤트 루프를 막지 않으려는 것이다.

    입력: ctx — Agents SDK 실행 컨텍스트, _agent — 에이전트(사용 안 함)
    반환: system_prompt 문자열
    """
    return await asyncio.to_thread(system_prompt, ctx.context.conv)  # 프롬프트에 카탈로그 조회가 들어 있어 스레드에서


AGENT = Agent(name="공정 데이터 분석 에이전트", model=MODEL, instructions=_instructions, model_settings=ModelSettings(max_tokens=4000),
              tools=[_function_tool(t) for t in RUNTIME_TOOLS] + [_function_tool(t, s.name) for s in SKILLS.values() for t in s.tools])


class _Hooks(RunHooks):
    async def on_llm_start(self, context, agent, system_prompt, input_items):  # noqa: D401  (작업 상태 표시)
        t: Turn = context.context
        t.emit({"type": "activity", "text": "결과를 보고 해석을 쓰는 중" if t.pending else ("다음 할 일을 정하는 중" if t.seen else "요청을 읽고 할 일을 정하는 중")})


HOOKS = _Hooks()


def ui_event(ev: dict) -> dict:
    """화면 이벤트 → 표준 스트림의 사용자 정의 이벤트(type "ui"). JSON으로 한 번 돌려 숫자·날짜 형식을 맞춘다."""
    return {"type": "ui", "ui": json.loads(json.dumps(ev, ensure_ascii=False, default=str))}


def _action_items(conv: Conversation, action: dict, t: Turn) -> list:
    """화면의 [실행] 버튼을 처리한다. LLM 없이 그 도구를 먼저 실행하고, 대화 기록에 사용자 행동과 도구 호출·결과를 남긴다(이어서 LLM이 해석).

    입력: conv — 대화, action — {tool, base(패널을 연 때의 값), cfg(바뀐 값)}, t — 턴
    반환: 대화 기록에 추가할 항목 3개(사용자 메모, 도구 호출, 도구 결과)
    부작용: 도구 실행, t.pending · t.seen 갱신
    """
    tool = action.get("tool")
    base = action.get("base") or conv.last_preview.get(TOOL_OWNER[tool], {})  # 패널을 연 때의 값(없으면 제안)
    new = action.get("cfg") or {}
    diff = [f"{k}: {json.dumps(base.get(k), ensure_ascii=False)} → {json.dumps(v, ensure_ascii=False)}" for k, v in new.items() if k in base and base.get(k) != v]
    note = ("사용자가 설정 패널에서 직접 바꿔 실행했다(의도한 변경이다): " + "; ".join(diff)) if diff else "제안·설정 값 그대로 실행했다."
    args = {"cfg": new}
    result, _end, t.pending = execute_tool(conv, tool, args, t.emit)
    t.seen.append(tool_label(tool))
    cid = "call_" + uuid.uuid4().hex[:10]
    return [{"role": "user", "content": f"[화면에서 '실행'을 눌렀다] {note}"},
            {"type": "function_call", "call_id": cid, "name": tool, "arguments": json.dumps(args, ensure_ascii=False)},
            {"type": "function_call_output", "call_id": cid, "output": result}]


async def run_turn_stream(conv: Conversation, user_text: str | None, action: dict | None, screen: dict | None = None, suggest: bool = True):
    """한 턴을 스트리밍으로 돌린다. Runner가 LLM과 도구를 글만 쓸 때까지 번갈아 돌린다.
    내보내는 것은 표준 Responses 이벤트(글, 도구 호출 항목)와 화면 이벤트(type "ui")다. suggest면 턴이 끝난 뒤(대화 잠금을 푼 뒤) 후속 질문을 만든다.

    입력: conv — 대화, user_text — 사용자 질문(없으면 빈 문자열), action — 화면 [실행] 요청(없을 수 있음), screen — 화면 상태(없을 수 있음), suggest — 후속 질문 생성 여부
    반환: 비동기 이벤트 생성기(dict 이벤트)
    부작용: 대화 잠금 획득·해제, conv.messages를 실행 결과로 갱신
    """
    loop = asyncio.get_running_loop()
    q: asyncio.Queue = asyncio.Queue()
    t = Turn(conv, lambda ev: loop.call_soon_threadsafe(q.put_nowait, ("ui", ev)))
    yield ui_event({"type": "conversation", "conversation_id": conv.id})
    yield ui_event({"type": "activity", "text": "요청을 읽고 할 일을 정하는 중"})
    await asyncio.to_thread(conv.lock.acquire)
    task = None
    try:
        _sync_screen(conv, screen)
        if action and action.get("type") == "run":
            if action.get("tool") not in TOOL_OWNER:
                t.emit({"type": "error", "message": f"실행할 도구가 없습니다: {action.get('tool')}"})
                action = None
            else:
                conv.messages += await asyncio.to_thread(_action_items, conv, action, t)
        if not action:
            conv.messages.append({"role": "user", "content": user_text or ""})
        result = Runner.run_streamed(AGENT, input=list(conv.messages), context=t, max_turns=MAX_STEPS, hooks=HOOKS,
                                     run_config=RunConfig(workflow_name="공정 데이터 분석 에이전트"))  # 대화 id는 trace의 session으로 단다(_trace_meta)
        _trace_meta(conv, user_text)

        async def pump():
            try:
                async for ev in result.stream_events():
                    q.put_nowait(("agent", ev))
            except Exception as e:  # noqa: BLE001
                q.put_nowait(("error", e))
            finally:
                q.put_nowait(("end", None))

        task = asyncio.create_task(pump())
        item = None
        while True:
            kind, ev = await q.get()
            if kind == "ui":
                yield ui_event(ev)
            elif kind == "error":
                yield ui_event({"type": "error", "message": error_text(ev)})
            elif kind == "end":
                break
            elif ev.type == "raw_response_event":
                d = ev.data
                if d.type == "response.output_item.added" and getattr(d.item, "type", "") == "message":
                    item = "msg_" + uuid.uuid4().hex[:16]
                elif d.type == "response.output_text.delta":
                    item = item or "msg_" + uuid.uuid4().hex[:16]
                    yield {"type": "response.output_text.delta", "item_id": item, "delta": d.delta}
            elif ev.type == "run_item_stream_event":
                if ev.name == "message_output_created":
                    text = ItemHelpers.text_message_output(ev.item)
                    if text.strip():
                        t.said.append(text)
                        if t.pending:  # 결과가 나온 뒤 처음 쓴 글 = 그 결과의 해석(PDF에 들어간다)
                            conv.interpretations[t.pending[1]] = text
                            yield ui_event({"type": "interpretation", "kind": t.pending[0], "target": t.pending[1], "text": text})
                            t.pending = None
                    yield {"type": "response.output_item.done", "item": {"type": "message", "id": item or "msg_" + uuid.uuid4().hex[:16], "role": "assistant",
                                                                         "content": [{"type": "output_text", "text": text}]}}
                    item = None
                elif ev.name in ("tool_called", "tool_output"):
                    yield {"type": "response.output_item.done", "item": ev.item.to_input_item()}
        await task
        try:
            conv.messages = result.to_input_list()  # 다음 턴은 이 기록(도구 호출·결과 포함)으로 이어간다
        except Exception:  # noqa: BLE001  (도중에 멈춘 턴은 사용자 말까지만 남는다)
            pass
    finally:
        if task and not task.done():  # 화면이 연결을 끊으면 남은 실행을 멈춘다(대화 잠금을 풀기 전에)
            task.cancel()
        conv.lock.release()
    yield ui_event({"type": "done", "conversation_id": conv.id})
    if suggest:
        out: list = []
        await asyncio.to_thread(_traced, "후속 질문 만들기", conv, followups, conv, user_text or "", "\n\n".join(t.said), t.seen, _client(), out.append)
        for ev in out:
            yield ui_event(ev)
