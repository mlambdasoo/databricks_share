"""공정 데이터 분석 에이전트 Databricks App의 진입점: MLflow AgentServer, 화면용 보조 API, 정적 React 빌드 서빙.

용도:
- /responses(스트리밍) · /invocations(한 번에 응답) · /health를 AgentServer에 등록한다. 에이전트 본체는 agent.py(OpenAI Agents SDK).
- 화면 전용 이벤트(제안 카드 · 결과 · 진행 상태 등)는 표준 스트림 안의 사용자 정의 이벤트(type "ui")로 받는다.
- 설정 패널 · PDF · 결과 파일/데이터 · 첫 화면 정보 · 데이터 선택기 · 시연 시나리오 API를 제공한다.

목적: 이 파일은 HTTP 경계만 맡고 분석 로직은 agent.py와 skill에 둔다. MLflow 실험은 앱 리소스(MLFLOW_EXPERIMENT_ID)로 연결해 배포한 코드마다 에이전트 버전(LoggedModel)을 남기고, 요청마다 trace를 남긴다(실험이 Unity Catalog trace 위치에 연결돼 span은 UC 테이블로).
"""
from __future__ import annotations

import asyncio
import functools
import hashlib
import json
import mimetypes
import os
import threading
import time
import uuid

import mlflow
from fastapi import HTTPException
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from mlflow.genai.agent_server import AgentServer, invoke, stream
from mlflow.types.responses import ResponsesAgentRequest
from pydantic import BaseModel

import yaml
import agent
from agent import C, cd

server = AgentServer("ResponsesAgent")  # 표준 /responses · /invocations · /health
app = server.app
app.add_middleware(GZipMiddleware, minimum_size=2000)
STATIC = os.path.join(agent.HERE, "static")


# ----------------------------------------------------------------------------- MLflow 실험 연결(에이전트 버전)

@functools.lru_cache(maxsize=1)
def code_version() -> str:
    """앱 코드(파이썬·지침·양식)의 해시 — 배포한 코드가 바뀌면 다른 에이전트 버전이 된다(앱 폴더는 git이 아니라서)."""
    h = hashlib.sha1()
    for root, dirs, files in os.walk(agent.HERE):
        dirs[:] = sorted(d for d in dirs if not d.startswith((".", "_")) and d not in ("outputs", "static", "node_modules", "mlruns"))  # 패키지(.venv)·캐시·빌드·로컬 MLflow 파일 제외
        for f in sorted(files):
            if f.endswith((".py", ".md", ".yaml", ".json")):
                with open(os.path.join(root, f), "rb") as fp:
                    h.update(f.encode() + fp.read())
    return h.hexdigest()[:8]


def _link_experiment():
    """MLFLOW_EXPERIMENT_ID(앱 리소스)가 있으면 그 실험에 이 코드 버전의 에이전트(LoggedModel)를 남긴다. 실패해도 앱은 돈다."""
    exp = os.getenv("MLFLOW_EXPERIMENT_ID")
    if not agent.TRACE:
        mlflow.tracing.disable()  # 로컬 실행: 추적 기록 파일(mlruns)을 남기지 않는다
    if not exp:
        return
    try:
        mlflow.set_experiment(experiment_id=exp)
        m = mlflow.set_active_model(name=f"{os.getenv('DATABRICKS_APP_NAME', 'local')}-{code_version()}")
        mlflow.log_model_params({"llm": agent.MODEL, "skills": ",".join(agent.SKILLS), "tools": str(len(agent.AGENT.tools)),
                                 "genie_space": agent.G.SPACE_ID or "-", "framework": "MLflow ResponsesAgent + OpenAI Agents SDK"}, model_id=m.model_id)

    except Exception as e:  # noqa: BLE001
        print("MLflow 실험 연결 실패:", type(e).__name__, e)


if agent.TRACE:  # 한 턴 = trace 하나: 요청(root) → Agents SDK 실행 → LLM 호출 · 도구 호출(이름 · 인자 · 결과) span. 첫 요청 전에 켠다
    mlflow.openai.autolog(silent=True)
threading.Thread(target=_link_experiment, daemon=True).start()


# ----------------------------------------------------------------------------- 에이전트 (표준 ResponsesAgent: /responses)

def _content_text(content) -> str:
    if isinstance(content, str):
        return content
    return "".join(p.get("text", "") for p in content or [] if isinstance(p, dict))


def _turn(request: ResponsesAgentRequest):
    """요청 1건을 이번 턴의 입력으로 풀어낸다. 대화 id가 없으면 새 대화를 만들고, 상태 없이 대화 이력을 통째로 보냈으면 그 이력을 대화에 채운다.

    입력: request — ResponsesAgentRequest(input: 메시지 목록, custom_inputs: conversation_id · action · screen · followups)
    반환: (대화 객체, 사용자 글 또는 None, 화면 행동 action 또는 None, 화면 상태 screen, 후속 질문 여부 bool). 후속 질문은 followups를 False로 명시한 경우만 끈다.
    예외: 사용자 메시지도 action도 없으면 HTTP 400
    """
    ci = request.custom_inputs or {}
    msgs = [m.model_dump() if hasattr(m, "model_dump") else dict(m) for m in request.input]
    last = next((m for m in reversed(msgs) if m.get("role") == "user"), None)
    if last is None and not ci.get("action"):
        raise HTTPException(400, "input에 user 메시지가 없습니다.")
    conv = agent.get_conversation(ci.get("conversation_id"))
    if not ci.get("conversation_id") and len(msgs) > 1:  # 상태 없이 대화 이력을 통째로 보낸 경우
        for m in msgs[: msgs.index(last)]:
            if m.get("role") in ("user", "assistant"):
                conv.messages.append({"role": m["role"], "content": _content_text(m.get("content"))})
    return conv, (_content_text(last.get("content")) if last else None), ci.get("action"), ci.get("screen"), ci.get("followups", True) is not False


@stream()
async def stream_handler(request: ResponsesAgentRequest):
    """POST /responses (스트리밍): 표준 ResponsesAgent 스트림. 턴을 agent.run_turn_stream으로 돌려 나오는 chunk를 그대로 흘린다.

    입력: request — ResponsesAgentRequest
    반환: 비동기 생성기(chunk dict: 텍스트 조각 · 화면 이벤트 type "ui" 등)
    """
    conv, text, action, screen, suggest = _turn(request)
    async for chunk in agent.run_turn_stream(conv, text, action, screen, suggest):
        yield chunk


@invoke()
async def invoke_handler(request: ResponsesAgentRequest) -> dict:
    """POST /invocations: 한 번에 받는 호출(평가 도구 · 다른 시스템용). 같은 턴을 끝까지 돌려 Responses 응답 하나로 준다. 화면 이벤트는 custom_outputs에 담는다.

    입력: request — ResponsesAgentRequest
    반환: Responses 응답 dict(_response_object 결과). 텍스트 조각은 항목별로 모아 빈 항목을 뺀 뒤 빈 줄로 잇는다.
    """
    conv, text, action, screen, suggest = _turn(request)
    events, texts, order = [], {}, []
    async for ch in agent.run_turn_stream(conv, text, action, screen, suggest):
        if ch["type"] == "ui":
            events.append(ch["ui"])
        elif ch["type"] == "response.output_text.delta":
            if ch["item_id"] not in texts:
                texts[ch["item_id"]] = ""
                order.append(ch["item_id"])
            texts[ch["item_id"]] += ch["delta"]
    final = "\n\n".join(texts[i] for i in order if texts[i].strip())
    return _response_object("resp_" + uuid.uuid4().hex[:24], conv, events, final)


def _response_object(rid, conv, events, text):
    """화면 이벤트 목록을 Responses 응답 객체 하나로 묶는다. 도구 호출은 function_call · function_call_output 항목으로, 화면 이벤트는 custom_outputs로 넣는다.

    입력: rid — 응답 id · conv — 대화 객체(id · 로드된 skill 사용) · events — 화면 이벤트 dict 목록(type: tool_start · tool_end · proposal · result · lookup · work · interpretation · followups · file · charts · error · activity) · text — 최종 답변 문자열
    반환: 응답 dict(id · object · status · output · custom_outputs). activity 이벤트는 custom_outputs에서 뺀다. 짝이 되는 tool_start가 없는 tool_end의 call_id는 call_unknown이다.
    """
    output, calls = [], {}
    for ev in events:
        if ev["type"] == "tool_start":
            cid = "call_" + uuid.uuid4().hex[:10]
            calls[ev["name"]] = cid
            output.append({"type": "function_call", "id": "fc_" + cid[5:], "call_id": cid, "name": ev["name"],
                           "arguments": json.dumps(ev.get("args") or {}, ensure_ascii=False)})
        elif ev["type"] == "tool_end":
            cid = calls.pop(ev["name"], "call_unknown")
            output.append({"type": "function_call_output", "call_id": cid,
                           "output": json.dumps({"ok": ev.get("ok"), "ms": ev.get("ms"), "error": ev.get("error"),
                                                 "summary": ev.get("summary")}, ensure_ascii=False)})
    output.append({"type": "message", "id": "msg_" + rid[5:], "role": "assistant", "status": "completed",
                   "content": [{"type": "output_text", "text": text, "annotations": []}]})
    keep = [e for e in events if e["type"] not in ("activity",)]
    custom = {"conversation_id": conv.id,
              "skills_loaded": list(conv.loaded),
              "proposal": next((e["data"] for e in reversed(keep) if e["type"] == "proposal"), None),
              "results": [e["data"] for e in keep if e["type"] == "result"],
              "lookups": [e["data"] for e in keep if e["type"] == "lookup"],
              "works": [{k: v for k, v in e["data"].items() if k not in ("rows",)} for e in keep if e["type"] == "work"],
              "interpretations": [{"target": e["target"], "text": e["text"]} for e in keep if e["type"] == "interpretation"],
              "followups": next((e["items"] for e in reversed(keep) if e["type"] == "followups"), []),
              "files": [e for e in keep if e["type"] == "file"],
              "charts": [e for e in keep if e["type"] == "charts"],
              "errors": [e for e in keep if e["type"] == "error"],
              "events": [{k: v for k, v in e.items() if k not in ("data",)} for e in keep]}
    return {"id": rid, "object": "response", "created_at": int(time.time()), "model": "analysis-agent", "status": "completed",
            "output": output, "custom_outputs": custom}


# ----------------------------------------------------------------------------- 화면 보조 API

class SettingsIn(BaseModel):
    """POST /api/settings 요청 본문: 분석 설정 패널에서 칸을 바꿀 때 보내는 값.

    필드: conversation_id — 대화 id(없으면 새 대화) · skill — 설정을 맡을 skill 이름 · cfg — 바꾼 설정 dict · from_result — 결과 화면의 [설정 수정]에서 왔는지(True면 이름표가 "현재 값")
    """
    conversation_id: str | None = None
    skill: str
    cfg: dict
    from_result: bool = False


@app.post("/api/settings")
async def settings(body: SettingsIn):
    """POST /api/settings: 분석 설정 패널. 칸을 바꿀 때마다(또는 결과의 [설정 수정]) 그 cfg로 skill이 진단하고 칸을 다시 만든다.

    입력: body — SettingsIn(conversation_id · skill · cfg · from_result)
    반환: skill 설정 결과 dict. 제안 cfg(last_preview)는 덮어쓰지 않는다. 실행할 때 사용자가 바꾼 항목을 제안과 비교해 알리기 위해서다.
    예외: skill이 없거나 설정 패널이 없으면 HTTP 400, 파이프라인 오류(cd.PipelineError)는 HTTP 400(메시지 · 상세 포함)
    """
    conv = agent.get_conversation(body.conversation_id)
    sk = agent.SKILLS.get(body.skill)
    if not sk or not hasattr(sk.module, "settings"):
        raise HTTPException(400, f"{body.skill}에는 설정 패널이 없습니다.")

    def work():
        agent.W.activate(conv)
        with agent.ENGINE_LOCK:
            return sk.module.settings(body.cfg, agent.Ctx(conv, body.skill, lambda e: None), from_result=body.from_result)

    try:
        payload = await asyncio.to_thread(work)
    except cd.PipelineError as e:
        raise HTTPException(400, {"message": str(e), "detail": e.detail})
    return payload  # 제안 cfg(last_preview)는 덮어쓰지 않는다 — 실행할 때 사용자가 바꾼 항목을 제안과 비교해 알린다


class PdfIn(BaseModel):
    """POST /api/pdf 요청 본문: 실행 결과를 PDF로 만들 때 쓴다.

    필드: conversation_id — 대화 id · run_id — 실행 id · images — 결과 패널에서 보던 차트 목록 [{"title", "data_url": "data:image/png;base64,..."}](없으면 표만)
    """
    conversation_id: str
    run_id: str
    images: list[dict] | None = None   # [{"title", "data_url": "data:image/png;base64,..."}] 결과 패널에서 보던 차트


@app.post("/api/pdf")
async def pdf(body: PdfIn):
    """POST /api/pdf: 실행 결과를 PDF로 만든다. 결과 화면에서 보던 차트(PNG data URL)를 넣을 수 있다.

    입력: body — PdfIn(conversation_id · run_id · images)
    반환: {"name"(PDF 파일 이름), "url"(다운로드 경로 /api/files/...), "screen_charts"(받은 차트 수)}
    예외: 실행 id가 없으면 HTTP 404, 파이프라인 오류는 HTTP 400
    """
    conv = agent.get_conversation(body.conversation_id)
    if body.run_id not in conv.runs:
        raise HTTPException(404, "실행 결과를 찾을 수 없습니다.")

    def work():
        import base64
        st = conv.runs[body.run_id]
        paths = []
        for k, im in enumerate(body.images or []):
            data = str(im.get("data_url", ""))
            if data.startswith("data:image/png;base64,"):
                p = os.path.join(st["output_dir"], f"screen_{body.run_id}_{k + 1:02d}.png")
                with open(p, "wb") as f:
                    f.write(base64.b64decode(data.split(",", 1)[1]))
                paths.append(p)
        with agent.ENGINE_LOCK:
            return agent.make_pdf(conv, body.run_id, images=paths or None)

    try:
        await asyncio.to_thread(work)
    except cd.PipelineError as e:
        raise HTTPException(400, {"message": str(e), "detail": e.detail})
    st = conv.runs[body.run_id]
    pdfs = sorted((f for f in os.listdir(st["output_dir"]) if f.endswith(".pdf")), key=lambda f: os.path.getmtime(os.path.join(st["output_dir"], f)))
    name = pdfs[-1]
    return {"name": name, "url": f"/api/files/{body.run_id}/{name}", "screen_charts": len(body.images or [])}


def _find_run(run_id):
    for conv in agent.CONVERSATIONS.values():
        st = conv.runs.get(run_id)
        if st:
            return st
    return None


@app.get("/api/files/{run_id}/{name}")
def files(run_id: str, name: str):
    """GET /api/files/{run_id}/{name}: 실행 결과 파일을 내려준다. PDF는 첨부(다운로드)로 준다.

    입력: run_id — 실행 id · name — 파일 이름(경로 없이 이름만)
    반환: FileResponse(파일 본문, 미디어 타입은 확장자로 추정)
    예외: 이름에 경로가 섞이면 HTTP 400, 실행이나 파일이 없으면 HTTP 404
    """
    if os.path.basename(name) != name:
        raise HTTPException(400, "잘못된 파일 이름")
    st = _find_run(run_id)
    if st and st.get("output_dir"):
        path = os.path.join(st["output_dir"], name)
        if os.path.isfile(path):
            media = mimetypes.guess_type(path)[0] or "application/octet-stream"
            headers = {"Content-Disposition": f'attachment; filename="{name}"'} if name.endswith(".pdf") else {}
            return FileResponse(path, media_type=media, headers=headers)
    raise HTTPException(404, "파일을 찾을 수 없습니다.")


@app.get("/api/data/{run_id}/{name}")
def data(run_id: str, name: str):
    """GET /api/data/{run_id}/{name}: 결과 화면 차트용 배치 단위 데이터(컬럼형 JSON).

    입력: run_id — 실행 id · name — 배치(프레임) 이름
    반환: JSON {"n": 행 수, "columns": 컬럼별 값}
    예외: 실행이나 배치가 없으면 HTTP 404
    """
    st = _find_run(run_id)
    frame = (st or {}).get("frames", {}).get(name)
    if frame is None:
        raise HTTPException(404, "데이터를 찾을 수 없습니다.")
    return JSONResponse({"n": int(len(frame)), "columns": C.columnar(frame)})


# ----------------------------------------------------------------------------- 메타

def _skills_meta():
    """첫 화면 "할 수 있는 일": 원본 조회 도구 + skill(제목·한 줄 설명)."""
    return [{"name": t, "title": t, "summary": sm} for t, sm in agent.capabilities()]


def source_meta(src=None) -> dict:
    """첫 화면 정보를 만든다. 계산하지 않는다(Unity Catalog 메타데이터만): 등록 테이블 목록 · 할 수 있는 일 · 이 대화의 테이블 이름(정했으면) · 첫 제안이 이미 있으면 예시 질문.
    기초 통계는 데이터 패널을 열 때(/api/stats) 계산한다.

    입력: src — 대화의 소스 dict(table 키, 없으면 None)
    반환: 첫 화면 dict(source · chosen · title · unit · rows(None: 행 수는 분석할 때 센다) · model · examples · sources · skills)
    """
    items = _source_items()
    table = (src or {}).get("table")
    tm = agent.W.first.table_meta(table)
    return {"source": table, "chosen": bool(table), "title": agent.S.title(table, agent.W.backend()) if table else None,
            "unit": tm.get("row_unit") or "행", "rows": None, "model": agent.MODEL,
            "examples": _examples(table, [i["name"] for i in items]), "sources": items, "skills": _skills_meta()}


def _examples(table, tables) -> list:
    """첫 화면 예시 질문: 첫 제안을 이미 받은 테이블(앱이 켜진 뒤 누군가 그 테이블로 분석했을 때)의 것만. 새로 계산하지 않는다."""
    pick = [table] if table else tables
    out = [e for t in pick for e in ((agent.W.first.get(t) or {}).get("examples") or [])[: 5 if table else 2] if e != "어떤 테이블 있어?"]
    return out + ["어떤 테이블 있어?"] if out else []




@app.get("/api/meta")
async def meta(conversation_id: str | None = None, source: str | None = None):
    """GET /api/meta: 대화의 첫 화면 정보를 계산 없이 바로 준다. 대화가 없으면 새로 만든다(source를 주면 그 테이블로 정한 대화).

    입력: conversation_id — 대화 id(없으면 새 대화) · source — 테이블 이름(새 대화일 때만 쓰며, 확인에 실패하면 무시)
    반환: 대화의 첫 화면 dict(+ conversation_id). 정보 만들기에 실패하면 error 문구와 빈 값을 담은 dict.
    """
    conv = agent.get_conversation(conversation_id)
    if source and not conversation_id:
        try:
            conv.source = agent.W.resolve_source(source)
        except cd.PipelineError:
            pass
    if not conv.meta:
        try:
            conv.meta = await asyncio.to_thread(source_meta, conv.source)
        except Exception as e:  # noqa: BLE001
            return {"conversation_id": conv.id, "error": agent.error_text(e), "source": None, "chosen": False, "examples": [],
                    "model": agent.MODEL, "rows": None, "skills": _skills_meta()}
    return {**conv.meta, "conversation_id": conv.id}


@app.get("/api/stats")
async def stats(table: str):
    """GET /api/stats?table=: 데이터 패널의 기초 통계. 테이블 전체를 SQL로 집계한다(표본 아님). 패널을 열 때만 계산하고 테이블마다 한 번 캐시한다.

    입력: table — 등록된 소스의 테이블 이름
    반환: 통계 dict(rows · n_cols · date · columns: 컬럼별 결측 · 최소 · 평균 · 최대 · 기간 · 값 종류 등)
    예외: 소스 확인이나 집계 오류는 HTTP 400
    """
    try:
        src = agent.W.resolve_source(table)
        return await asyncio.to_thread(agent.S.table_stats, src, agent.W.backend())
    except cd.PipelineError as e:
        raise HTTPException(400, str(e))


@app.get("/api/demo")
async def demo_scenarios():
    """GET /api/demo: 시연 시나리오 메뉴(demo_scenarios.yaml의 대본). 계산하지 않는다 — 첫 제안은 분석할 때 만든다.

    입력: 없음
    반환: {"scenarios": 시나리오 목록(앱에 있는 도구로 할 수 있는 것만)}
    """
    tools = set(agent.TOOL_OWNER) | {t["function"]["name"] for t in agent.RUNTIME_TOOLS}
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "demo_scenarios.yaml"), encoding="utf-8") as fp:
        spec = yaml.safe_load(fp)
    return {"scenarios": [  # 앱에 없는 도구를 기대하는 시나리오는 뺀다(그 skill을 지우면 시나리오도 빠진다)
        {"id": s_["id"], "title": s_["title"], "needs": s_.get("needs") or [],
         "steps": [{"ask": st["ask"], "shows": st.get("shows", ""), "expect": st.get("expect") or []} for st in s_["steps"]]}
        for s_ in spec if not any(set(st.get("expect") or []) - tools for st in s_["steps"])]}


def _source_items() -> list:
    """데이터 선택기 항목: Unity Catalog 태그로 등록한 테이블 + 이름(첫 제안의 테이블 이름, 없으면 테이블 설명 첫 구절)."""
    items = [i for i in agent.S.data_items(agent.S.list_sources(agent.W.backend())) if i["kind"] == "테이블"]
    return [{k: v for k, v in {**i, "title": agent.S.title(i["name"], agent.W.backend())}.items() if k not in ("columns", "col_info")}
            for i in items]


@app.get("/api/sources")
def sources(conversation_id: str | None = None):
    """GET /api/sources: 데이터 선택기 목록. LLM 없이 Unity Catalog 메타데이터만 쓴다.

    입력: conversation_id — 대화 id(없거나 대화가 없으면 기본 소스를 현재 소스로 본다)
    반환: {"current": 현재 소스 키, "default": 기본 소스 키, "tags": 등록 태그 설정, "items": _source_items() 결과}
    """
    conv = agent.CONVERSATIONS.get(conversation_id or "")
    cur = agent.S.source_key((conv.source if conv else None) or agent.W.default_source())
    return {"current": cur, "default": agent.S.source_key(agent.W.default_source()), "tags": agent.S.SOURCE_TAGS, "items": _source_items()}


class SourceIn(BaseModel):
    """POST /api/source 요청 본문: 데이터 선택기에서 고른 소스.

    필드: conversation_id — 대화 id(없으면 새 대화) · source — 소스 키(테이블 이름)
    """
    conversation_id: str | None = None
    source: str


@app.post("/api/source")
def pick_source(body: SourceIn):
    """POST /api/source: 데이터 선택기에서 고른 소스로 대화를 바꾼다(없으면 새 대화). 대화의 테이블만 정하고, 첫 제안은 첫 질문 때 받는다.

    입력: body — SourceIn(conversation_id · source)
    반환: {"conversation_id", "meta"(그 소스의 첫 화면 정보), "event"(소스 줄 이벤트 또는 None)}
    예외: 그 대화에서 분석이 진행 중이면 HTTP 409, 소스 오류는 HTTP 400
    """
    conv = agent.get_conversation(body.conversation_id)
    if not conv.lock.acquire(blocking=False):
        raise HTTPException(409, "분석이 진행 중입니다. 끝난 뒤 데이터를 바꿔 주세요.")
    events: list = []
    try:
        agent.W.pick_source(conv, body.source, events.append)  # 대화의 테이블만 정한다(첫 제안은 첫 질문 때)
        conv.meta = source_meta(conv.source)
    except cd.PipelineError as e:
        raise HTTPException(400, str(e))
    finally:
        conv.lock.release()
    ev = next((e for e in reversed(events) if e.get("type") == "source"), None)
    return {"conversation_id": conv.id, "meta": conv.meta, "event": ev}


@app.get("/api/health")
def health():
    """GET /api/health: 상태 확인. 모델 · 웨어하우스 설정 여부 · skill 목록 · 코드 버전을 돌려준다.

    입력: 없음
    반환: {"ok": True, "model", "warehouse"(웨어하우스 설정 여부 bool), "skills"(skill 이름 목록), "version"(코드 해시)}
    """
    return {"ok": True, "model": agent.MODEL, "warehouse": bool(agent.WAREHOUSE_ID), "skills": list(agent.SKILLS), "version": code_version()}


if os.path.isdir(STATIC):
    app.mount("/", StaticFiles(directory=STATIC, html=True), name="static")
