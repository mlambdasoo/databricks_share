"""작업 데이터(대화마다 하나)와 설정 패널의 공통 단계(데이터 범위 → 전처리 → 변수 선택).

용도:
- 시작값은 데이터 처리 skill의 첫 제안(테이블마다 한 번, proposal.py). 대화에서 고친 범위(필터 · 기간) → 전처리(변수별 정상범위 포함) → 변수 선택(변수 역할 포함) 설정을 실행기가 들고 있다.
- 그 설정으로 처리한 데이터를 만들어(같은 설정이면 다시 쓴다) 분석 skill에 넘긴다. 분석 엔진은 처리된 데이터로 계산만 한다.
- 설정 패널의 칸은 공통 단계(같은 폴더 layout.yaml)만 보여준다.

목적: 원본 조회는 Genie(UC 원본 테이블 SQL)가, 처리한 데이터 보기와 분석 skill은 이 작업 데이터로 한다. 분석 skill의 cfg는 작업 데이터 위에 요청한 키만 덮어쓴다(agent.merged_cfg). 분석에 특화된 설정(목표 지표 · 모델 · 관리 항목 등)은 패널에 값만 보이고 대화로 바꾼다.

    data(cfg, backend) -> {"df", "filled", "log", "plan", "pool", "selected", "n_rows", "filters_text", "smap", "cfg", "problems"}
    steps(cfg, backend, sprof, ...) -> 설정 패널의 공통 단계(화면 JSON)
"""
from __future__ import annotations

import importlib.util
import json
import os
import sys
import threading
from collections import OrderedDict

import pandas as pd

from common import data as cd
from common import layout as L
from common import result_format as C
import sources as S  # 같은 폴더(등록 테이블 · 표본 · 프로필)

# 작업 데이터가 들고 있는 키(분석 skill마다 아는 키만 가져간다)
SCOPE_KEYS = ("filters", "date_filter")
PREP_KEYS = ("normal_range", "normal_by_col", "na_ratio_max", "min_unique", "categorical", "impute", "impute_by_col", "knn_k", "impute_constant")
VAR_KEYS = ("var_exclude", "var_roles", "exclude_result_like")
KEYS = SCOPE_KEYS + PREP_KEYS + VAR_KEYS
BY_COL = ("impute_by_col", "normal_by_col", "var_roles")  # 변수마다 다른 값: 말한 변수만 바꾼다
_PREP_DIR = os.path.dirname(os.path.abspath(__file__))


def _load(name):
    spec = importlib.util.spec_from_file_location(f"skill_data_prep_{name}", os.path.join(_PREP_DIR, f"{name}.py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod  # 모듈이 자기 자신을 공급자로 끼울 수 있게(proposal.py)
    spec.loader.exec_module(mod)
    return mod


prep = _load("engine")     # 데이터 처리 skill의 계산(공통 데이터 처리)
first = _load("proposal")  # 데이터 처리 skill의 첫 제안(테이블마다 한 번, LLM)
DEFAULTS = prep.COMMON_DEFAULTS
_CACHE: OrderedDict = OrderedDict()   # 처리한 데이터(설정·첫 제안이 같으면 다시 씀)
_CACHE_MAX = 16
_LOCK = threading.Lock()
PREVIEW_ROWS = 200
STEPS = L.load(__file__)  # 설정 패널 공통 3단계 양식(같은 폴더 layout.yaml)
RANGE_CHOICES = [[k, v] for k, v in cd.RANGE_LABELS.items()]
CAT_CHOICES = [[k, v] for k, v in cd.CAT_LABELS.items()]
IMPUTE_TEXT = {**cd.IMPUTE_LABELS, "value": "직접 입력한 값"}


def merged(base: dict, change: dict | None) -> dict:
    """지금 작업 데이터 + 바꿀 키. 필터는 말한 컬럼만 바꾸고, 값이 빈 목록이면 그 필터를 푼다."""
    out = {**DEFAULTS, **{k: v for k, v in (base or {}).items() if k in KEYS or k == "source"}}
    for k, v in (change or {}).items():
        if k == "filters" and isinstance(v, dict):
            f = dict(out.get("filters") or {})
            for c, vals in v.items():
                if vals:
                    f[c] = vals
                else:
                    f.pop(c, None)
            out["filters"] = f
        elif k in BY_COL and isinstance(v, dict):
            out[k] = {**(out.get(k) or {}), **v}
        elif k in KEYS:
            out[k] = v
    return out


def data(cfg: dict, backend, impute: bool = False, df: pd.DataFrame | None = None) -> dict:
    """이 설정으로 데이터를 처리한다(데이터 처리 skill의 계산). 분석 skill이 받는 것이다. 같은 설정 · 같은 첫 제안이면 캐시에서 다시 쓴다(최대 16개). 문제가 있는 결과는 캐시하지 않는다.

    입력: cfg — 설정 dict(없는 키는 기본값) · backend — 백엔드 · impute — False면 분석용(결측은 분석이 자기 행을 정한 뒤 채운다), True면 작업 데이터 보기(결측 채움 포함) · df — 주면 그 데이터를 처리하고 캐시하지 않는다
    반환: 처리 결과 dict(df · filled · log · plan · pool · selected · n_rows · filters_text · smap · cfg · problems)
    """
    full = {**DEFAULTS, **cfg}
    if df is not None:
        return prep.process(full, backend, impute=impute, df=df)
    keys = ("source", "spec_table", "id_col") + KEYS
    table = (full.get("source") or {}).get("table")
    key = (json.dumps({k: full.get(k) for k in keys}, sort_keys=True, default=str), first.key(table), impute)
    with _LOCK:
        if key in _CACHE:
            _CACHE.move_to_end(key)
            return _CACHE[key]
    out = prep.process(full, backend, impute=impute)
    if not out["problems"]:
        with _LOCK:
            _CACHE[key] = out
            while len(_CACHE) > _CACHE_MAX:
                _CACHE.popitem(last=False)
    return out


def preview(p: dict, unit: str) -> dict:
    """화면 오브젝트용: 채운 칸이 있는 컬럼을 앞에, 채운 칸이 있는 행을 먼저 보여준다(최대 PREVIEW_ROWS행)."""
    smap, cfg, filled = p["smap"], p["cfg"], p["filled"]
    pool = {x["col"] for x in p["pool"]}
    df = p["df"][[c for c in p["df"].columns if c not in pool or c in p["selected"]]]  # 범위 컬럼 + 고른 변수
    first = [c for c in (cfg.get("id_col"), cfg.get("date_col")) if c and c in df.columns]
    fcols = [c for c in filled.columns if filled[c].any()]
    rest = [c for c in df.columns if c not in first and c not in fcols]
    cols = first + fcols + rest
    order = filled.any(axis=1).sort_values(ascending=False, kind="stable").index if len(fcols) else df.index
    rows = df.loc[order[:PREVIEW_ROWS], cols]
    marks = [[i, cols.index(c)] for i, ix in enumerate(rows.index) for c in fcols if bool(filled.at[ix, c])]
    clean = rows.astype(object).where(rows.notna(), None).map(lambda v: round(v, 4) if isinstance(v, float) else (str(v) if not isinstance(v, (int, float, str)) else v))
    return {"columns": [cd.label(c, smap) for c in cols], "rows": clean.values.tolist(), "filled": marks, "n_rows": p["n_rows"],
            "n_filled": int(filled.values.sum()), "unit": unit}


# ----------------------------------------------------------------------------- 설정 패널의 공통 단계

def tag(keys: set, asked: set, proposed: set, from_result: bool) -> str:
    """단계 이름표: 요청에 그 단계의 키가 있으면 '요청 반영', 제안으로 바꾼 키가 있으면 '제안', 아니면 기본값·현재 값."""
    if asked & keys:
        return "요청 반영"
    if proposed & keys:
        return "제안"
    return "현재 값" if from_result else "기본값"


def form_scope(cfg: dict, prof: dict) -> list:
    """설정 패널의 데이터 범위 칸을 만든다: 범위·설비 차원마다 값 고르기 칸, 날짜 열이 있으면 기간 칸.

    칸은 데이터의 차원·기간으로 정해지므로 layout.yaml이 아니라 여기서 만든다.
    입력: cfg — 설정 dict(filters, date_filter), prof — 소스 프로필 dict
          (dims: [{col, label, values}], date_col, date_range: [최소, 최대], dates: [{col, label}])
    반환: 설정 패널 칸 list(차원 칸은 type "multi", 기간 칸은 type "daterange")
    """
    f = cfg.get("filters") or {}
    out = [{"key": f"filters.{d['col']}", "label": d["label"], "type": "multi", "options": [[v, v] for v in d["values"]],
            "value": [str(v) for v in f.get(d["col"], [])], "hint": "고르지 않으면 전체"} for d in prof.get("dims", [])]
    dc, rng = prof.get("date_col"), prof.get("date_range")
    if dc and rng:
        cur = cfg.get("date_filter") or {}
        out.append({"key": "date_filter", "label": next((x["label"] for x in prof.get("dates", []) if x["col"] == dc), dc), "type": "daterange",
                    "col": dc, "min": rng[0], "max": rng[1], "value": {"start": cur.get("start"), "end": cur.get("end")}})
    return out


def _range_view(full: dict, backend, smap, pool, log) -> tuple[str, dict | None]:
    """정상범위 칸의 안내와 변수별 범위 표: 지금 범위에서 범위 밖 값이 있는 변수와 개수, 선택한 처리 결과.

    입력: full — 기본값을 채운 설정 · backend · smap — 컬럼 정보 · pool — 변수 후보 · log — 처리 기록 {단계: 항목}
    반환: (안내 문장, 표 dict(summary · columns · rows) 또는 None)
    """
    raw, _ = cd.load(full, backend)  # 범위만 자른 원본(같은 조건이면 캐시) — 처리 전 값으로 센다
    rows = []
    for x in pool:
        rng = cd.bounds_of(x["col"], smap, full.get("normal_by_col"))
        if rng is None or x["col"] not in raw.columns:
            continue
        s = pd.to_numeric(raw[x["col"]].astype(str).str.replace(",", "", regex=False), errors="coerce")
        rows.append((x["label"], cd.range_text(rng), int(cd.out_of(s, rng).sum())))
    if not rows:
        return "이 데이터에는 정상범위를 정한 변수가 없습니다", None
    rows.sort(key=lambda r: (-r[2], r[0]))
    bad = [r for r in rows if r[2]]
    mode = full.get("normal_range", "nan")
    head = "정상범위 = 변수마다 센서 오류 · 기록 실수를 거르는 값의 범위(대화로 고침). "
    if not bad:
        tail = "지금 범위 밖 값 없음"
    else:
        what = " · ".join(f"{r[0]} {r[2]}개(범위 {r[1]})" for r in bad[:3]) + (f" 외 {len(bad) - 3}개 변수" if len(bad) > 3 else "")
        n_drop = (log.get("normal_range") or {}).get("count") if mode == "drop_row" else None
        tail = f"벗어난 값: {what}" + {"nan": " → 그 값만 지우고 아래 결측치 처리로 채움", "off": " → 그대로 씀",
                                    "drop_row": f" → 그 값이 있는 {n_drop}행 제외" if n_drop else " → 그 값이 있는 행 제외"}.get(mode, "")
    return head + tail, {"summary": f"변수별 정상범위 보기 ({len(rows)}개)", "columns": ["변수", "정상범위", "범위 밖 값"],
                         "rows": [[a, b, f"{c}개" if c else "-"] for a, b, c in rows]}


def steps(cfg: dict, backend, sprof: dict, uses=PREP_KEYS, not_used: dict | None = None, asked=(), proposed=(), from_result=False,
          scope_notes=None, unit="행") -> tuple[list, dict]:
    """설정 패널의 공통 단계(데이터 범위 → 전처리 → 변수 선택)를 화면 JSON으로 만든다. 단계 구성은 같은 폴더 layout.yaml. 각 단계에 요약 문장 · 안내 · 칸 값과 이름표(tag)를 채운다.

    입력: cfg — 설정 dict · backend — 백엔드 · sprof — 소스 프로필(범위 칸 구성) · uses — 이 분석이 쓰는 전처리 키(기본 PREP_KEYS) · not_used — 쓰지 않는 처리 {키: 이유}(참고 문장으로만) · asked — 요청한 키 · proposed — 제안으로 바뀐 키 · from_result — 결과 화면에서 왔는지 · scope_notes — 범위 칸에 붙일 안내 문장 목록 · unit — 행 단위 이름
    반환: (단계 목록[scope · prep · vars 순, 각 단계는 화면 JSON], 처리 결과 dict(data() 반환값))
    """
    p = data(cfg, backend)
    full, smap, pool, log = p["cfg"], p["smap"], p["pool"], {e["step"]: e for e in p["log"]}
    problems = p["problems"] or {}
    uses = set(uses)
    by = dict(full.get("impute_by_col") or {})
    plan = p["plan"] if "impute" in uses else []
    used = [x for x in pool if x["status"] is None]
    out_by = {}
    for x in pool:
        if x["status"]:
            out_by.setdefault(x["status"], []).append(x["label"])

    notes1 = [f"'{', '.join(v['requested'])}' 값이 {cd.label(c, smap)}에 없습니다. 가능한 값: {', '.join(map(str, v['available'][:8]))}"
              for c, v in problems.items()] + list(scope_notes or [])
    need = {"unique": "min_unique", "categorical": "categorical", "impute": "impute"}  # 이 분석이 쓰는 처리의 기록만
    prep_notes = [e["detail"] for k in ("string_numeric", "normal_range", "drop_row", "na_ratio", "unique", "categorical", "impute")
                  if (e := log.get(k)) and need.get(k, k) in uses | {"string_numeric", "normal_range", "drop_row", "na_ratio"}]
    prep_notes += [f"이 분석에는 쓰지 않는 처리 — {why}" for why in (not_used or {}).values()]
    n_fill = sum(1 for m in plan if m["method"] != "none")  # 채우는 변수(채우지 않음 제외)
    s_prep = " · ".join(x for x in [("문자로 저장된 숫자 변환" if "string_numeric" in log else ""),
                                    cd.RANGE_TEXT.get(full.get("normal_range", "nan"), ""),
                                    cd.na_rule_text(full.get("na_ratio_max", 0.3)),
                                    (f"범주형 {dict(CAT_CHOICES).get(full.get('categorical'))}" if "categorical" in uses else ""),
                                    (("채울 결측 없음" if not plan else (f"결측 채움 {n_fill}개 변수({'자동 추천' if full.get('impute') == 'auto' else IMPUTE_TEXT.get(full.get('impute'), full.get('impute'))}"
                                      + (f", {len(by)}개 직접 지정" if by else "") + ")" if n_fill else "") + (f"{' · ' if n_fill else ''}결측 그대로 {len(plan) - n_fill}개 변수" if len(plan) > n_fill else ""))
                                     if "impute" in uses else "")] if x)
    groups: dict = {}
    for x in pool:
        if x["status"] in (None, "직접 뺌"):
            g = "목표 지표 후보" if x["role"] == "y" else x["category"] or "기타"
            groups.setdefault(g, []).append([x["col"], x["label"]])
    n_y = sum(1 for x in used if x["role"] == "y")
    s_vars = f"{len(used)}개 변수 사용 (목표 지표 후보 {n_y}개 · 영향 요인 후보 {len(used) - n_y}개)" + \
        (f" · 직접 뺀 변수 {len(out_by.get('직접 뺌', []))}개" if out_by.get("직접 뺌") else "")
    vars_notes = [f"자동으로 빠짐 — {why}: {', '.join(labels)}" for why, labels in out_by.items() if why != "직접 뺌"]
    rows = [{"key": m["col"], "label": m["label"], "info": f"{m['ratio'] * 100:.1f}%",
             "default": f"{'자동 추천' if full.get('impute') == 'auto' else '요청한 방법'}: {IMPUTE_TEXT.get(m['method'], m['method'])}"
                        + (f" · {m['reason']}" if full.get("impute") == "auto" and m.get("reason") and m["reason"] != "직접 지정" else "")}
            for m in plan]
    dropped = [x for x in pool if x["status"] == "결측 비율"]
    rng_hint, rng_detail = _range_view(full, backend, smap, pool, log)
    cats = (log.get("categorical") or {}).get("columns") or [x["col"] for x in pool if x["role"] != "y" and x["status"] is None
                                                             and cd.is_categorical(p["df"][x["col"]])]
    vals = {"uses": {k: True for k in uses}, "scope": {"summary": f"{p['filters_text']} → {p['n_rows']:,}{unit}", "fields": form_scope(full, sprof),
                                                     "notes": notes1 or None, "warn": True if problems else None},
            "prep": {"summary": s_prep, "notes": prep_notes or None}, "vars": {"summary": s_vars, "notes": vars_notes or None},
            "normal_range": full.get("normal_range", "nan"), "range_choices": RANGE_CHOICES, "cat_choices": CAT_CHOICES,
            "range_hint": rng_hint, "range_detail": rng_detail,
            "na_ratio_max": full.get("na_ratio_max", 0.3),
            "na_hint": ("지금 빠지는 변수: " + ", ".join(f"{x['label']} {x['missing']:.0%}" for x in dropped)) if dropped else ("결측 비율로는 빼지 않습니다" if float(full.get("na_ratio_max", 0.3)) >= 1 else "결측 비율이 이 값을 넘는 변수는 뺍니다"),
            "min_unique": full.get("min_unique", 2), "categorical": full.get("categorical", "exclude"),
            "cat_hint": ("값이 글자인 변수: " + ", ".join(cd.label(c, smap) for c in cats)) if cats else "값이 글자인 변수",
            "impute_choice": [["auto", "변수별 자동 추천"], [full.get("impute"), f"모두 {IMPUTE_TEXT.get(full.get('impute'), full.get('impute'))}"]]
            if "impute" in uses and full.get("impute") != "auto" else None,
            "impute_rows": rows or None, "impute_by_col": by, "uses_knn": "impute" in uses and (full.get("impute") == "knn" or "knn" in by.values()),
            "knn_k": full.get("knn_k", 5), "var_exclude": list(full.get("var_exclude") or []),
            "var_groups": [{"label": g, "options": opts} for g, opts in groups.items()],
            "exclude_result_like": full.get("exclude_result_like", True) is not False}
    out = []
    asked, proposed = set(asked or []), set(proposed or [])
    for sid in ("scope", "prep", "vars"):
        st = {k: v for k, v in L.render(STEPS[sid], vals).items() if v is not None}
        keys = {f["key"].split(".")[0] for f in st["fields"]}
        st["tag"] = tag(keys, asked, proposed, from_result)
        out.append(st)
    return out, p

# ----------------------------------------------------------------------------- 연결(SQL 웨어하우스 · 기본 테이블 · LLM)

WAREHOUSE_ID = os.getenv("DATABRICKS_WAREHOUSE_ID", "")
DEFAULT_SOURCE = os.getenv("DEFAULT_SOURCE", "demo_sudong_catalog.analysis_agent.fermentation_batch")
LLM = {"client": None, "model": None, "skills": lambda: []}  # 첫 제안에 쓸 LLM: 실행기(agent.py)가 configure로 끼운다
_backend = None


def configure(client, model: str, skills) -> None:
    """실행기가 첫 제안에 쓸 LLM을 끼운다. 입력: client — 동기 LLM 클라이언트를 돌려주는 함수, model — 모델 이름, skills — 할 수 있는 일 [(제목, 설명)]을 돌려주는 함수."""
    LLM.update(client=client, model=model, skills=skills)


def backend():
    """SQL 백엔드를 한 번만 만들어 공유한다(처음 호출 때 WAREHOUSE_ID로 생성, 이후 같은 객체). 반환: cd.SqlBackend."""
    global _backend
    if _backend is None:
        _backend = cd.SqlBackend(WAREHOUSE_ID)
    return _backend


# ----------------------------------------------------------------------------- 테이블 · 첫 제안 · 작업 데이터(실행기가 부른다)

def default_source():
    """기본 테이블(환경변수 DEFAULT_SOURCE)을 소스 dict로 돌려준다. 입력 없음 → 반환 {"table": 이름}."""
    return {"table": DEFAULT_SOURCE}


def source_profile(src=None) -> dict:
    """소스 프로필(실제 값, 첫 제안 기준): 범위 차원·기간·지표 후보·행 단위."""
    return S.profile(src or default_source(), backend())


def activate(conv, src=None, emit=None) -> None:
    """이 테이블의 데이터 처리 첫 제안이 아직 없으면 받는다(테이블마다 한 번, 그 테이블로 처음 질문할 때). 테이블을 정하지 않았으면 하지 않는다.

    입력: conv — 대화(없을 수 있음), src — 소스 dict(생략 시 대화의 소스), emit — 화면 이벤트 전달 함수(생략 가능)
    반환: 없음(부작용: 첫 제안 생성, 화면 알림)
    """
    src = src or (conv.source if conv else None)
    if src and "table" in src and not first.ready(src["table"]):
        first.ensure(src["table"], backend(), LLM["client"](), LLM["model"], emit, skills=LLM["skills"]())


def prefetch(conv, cfg: dict) -> None:
    """첫 제안을 받는 동안 그 요청의 범위 데이터와 테이블 행 수·기간을 미리 읽어 둔다(둘 다 첫 제안과 무관하다). 이미 제안이 있으면 하지 않고, 기간 컬럼을 모르면 범위 데이터는 읽지 않는다.

    입력: conv — 대화, cfg — 도구 cfg(source · filters · date_filter, 없으면 작업 데이터 값)
    반환: 없음(부작용: 뒤에서 common.data.load · sources.table_summary 캐시를 채운다)
    """
    try:
        src = resolve_source(cfg["source"]) if cfg.get("source") else conv.source
        if not src or "table" not in src or first.ready(src["table"]):
            return
        w = work_of(conv, src) if S.source_key(src) == S.source_key(conv.source) else {}
        dfl = cfg["date_filter"] if "date_filter" in cfg else w.get("date_filter")
        full = None if isinstance(dfl, dict) and not dfl.get("col") else cd.normalize_common(  # 기간 컬럼을 모르면(첫 제안 뒤에 정해진다) 범위 데이터는 건너뛴다
            {"source": src, "filters": dict((cfg["filters"] if "filters" in cfg else w.get("filters")) or {}), "date_filter": dfl})
    except Exception:  # noqa: BLE001  (미리 읽기는 실패해도 된다)
        return
    if full:
        threading.Thread(target=lambda: _quiet(cd.load, full, backend()), daemon=True).start()
    threading.Thread(target=lambda: _quiet(S.table_summary, src, backend()), daemon=True).start()  # 전체 행 수 · 기간(소스 알림·프로필)


def _quiet(fn, *a):
    try:
        fn(*a)
    except Exception:  # noqa: BLE001
        pass


def source_label(src) -> str:
    key = S.source_key(src) or ""
    try:
        title = S.title(key, backend())
    except Exception:  # noqa: BLE001
        title = ""
    return (f"{title} — " if title and title != S.short(key) else "") + f"테이블 `{S.short(key)}`"


def source_md(src) -> str:
    """LLM에 주는 소스 설명: 컬럼 표(표시명·역할·값·정상범위·규격·설명) + 기본 지표."""
    out = S.describe_md(S.describe(src, backend()))
    py = (source_profile(src).get("y") or {})
    if py:
        out += f"\n- 기본 지표(지표를 말하지 않으면): `{py['col']}` ({py['label']})"
    return out


def resolve_source(v) -> dict:
    """등록 테이블 이름(전체 이름 또는 짧은 이름)을 등록된 테이블로 바꾼다. 등록되지 않았으면 등록 목록과 함께 거부한다(Unity Catalog 태그로 등록한 테이블만 분석 가능).

    입력: v — 이름 문자열 또는 {"table": 이름}(제안·설정 패널의 cfg)
    반환: {"table": 등록된 전체 이름}. 미등록이면 cd.PipelineError를 던진다.
    """
    v = str((v.get("table") if isinstance(v, dict) else v) or "").strip()
    items = [i for i in S.data_items(S.list_sources(backend())) if i["kind"] == "테이블"]
    hit = [i for i in items if v and (i["name"] == v or i["short"] == v or i["name"].endswith("." + v))]
    if not hit:
        raise cd.PipelineError(f"분석 대상으로 등록되지 않은 테이블입니다: {v}",
                               {"registered": [i["name"] for i in items], "hint": "Unity Catalog 태그로 등록한 테이블만 분석할 수 있습니다."})
    return {"table": hit[0]["name"]}


def unknown_values(src: dict, cfg: dict) -> dict:
    """cfg 필터 값 중 그 테이블(표본)에 없는 값 {컬럼: [값]} — 컬럼이 없으면 그 컬럼 전체."""
    df = S.sample(src, backend())
    out = {}
    for col, vals in (cfg.get("filters") or {}).items():
        vals = vals if isinstance(vals, list) else [vals]
        have = set(df[col].dropna().astype(str)) if col in df.columns else set()
        miss = [v for v in vals if str(v) not in have]
        if miss:
            out[col] = miss
    return out


def set_source(conv, src: dict, emit, prepare: bool = True) -> None:
    """대화의 테이블을 정하고 화면에 알린다. prepare(질문으로 정했을 때)면 분석에 필요한 첫 제안을 받고 행 수와 단위를 함께 알린다.

    입력: conv — 대화, src — 소스 dict, emit — 화면 이벤트 전달 함수, prepare — 첫 제안 준비 여부(기본 True)
    반환: 없음(부작용: conv.source · conv.meta 갱신, 'source' 이벤트 전송)
    """
    if prepare:
        activate(conv, src, emit)
    conv.source = src
    conv.meta = None  # 첫 화면 정보를 이 테이블로 다시 만든다
    ev = {"type": "source", "label": source_label(src), "key": S.source_key(src)}
    if prepare:
        prof = source_profile(src)
        ev.update(rows=prof["rows"], unit=prof["unit"])
    emit(ev)


def pick_source(conv, name: str, emit) -> None:
    """화면 데이터 패널에서 고른 테이블로 바꾼다. LLM 없이 처리하고 대화 기록에 그 사실을 남긴다. 첫 제안은 첫 질문 때 받는다.

    입력: conv — 대화, name — 등록 테이블 이름, emit — 화면 이벤트 전달 함수
    반환: 없음(부작용: 소스 교체, 대화 기록에 user·assistant 메시지 2개 추가)
    """
    src = resolve_source(name)
    set_source(conv, src, emit, prepare=False)  # 첫 제안은 첫 질문 때
    conv.messages += [{"role": "user", "content": f"[화면의 데이터 패널에서 `{S.source_key(src)}`를 골랐다. 이후 분석은 이 테이블로]"},
                      {"role": "assistant", "content": f"데이터를 {S.short(S.source_key(src))}(으)로 바꿨습니다."}]


def work_of(conv, src) -> dict:
    """이 소스의 작업 데이터(없거나 다른 소스면 빈 것)."""
    w = (conv.work if conv else None) or {}
    return w if w.get("source") == S.source_key(src) else {}


def remember_work(conv, merged: dict) -> None:
    """분석 cfg(병합 뒤)의 공통 데이터 처리 키를 작업 데이터로 남긴다(다음 분석이 같은 데이터를 쓰게)."""
    src = merged.get("source") or conv.source or default_source()
    conv.work = {**work_of(conv, src), **{k: merged[k] for k in KEYS if k in merged}, "source": S.source_key(src)}


def work_md(conv, src) -> str:
    w = work_of(conv, src)
    if not w:
        return "없음 — 아직 정하지 않았다(테이블 전체, 기본 처리)."
    return "cfg: " + json.dumps({k: w[k] for k in KEYS if k in w}, ensure_ascii=False, default=str)
