"""데이터 소스 카탈로그: Unity Catalog 태그로 등록한 테이블 목록, 컬럼 자동 진단, 표본, 기초 통계, 소스 프로필.

용도:
- 분석할 수 있는 소스 = SOURCE_TAGS(쉼표로 여러 개, "키" 또는 "키=값")의 태그가 하나라도 붙은 테이블. SOURCE_TAGS가 비면 SOURCE_SCHEMAS의 테이블 전부.
- 컬럼을 읽어 식별자 · 날짜 · 차원 · 수치 역할을 추정한다. 데이터 처리 skill의 첫 제안(테이블마다 한 번, LLM이 자연어 컬럼 · 테이블 설명과 값으로 만듦)이 오면 표시명 · 단위 · 분류 · 규격 · 역할 · 정상범위 · 기본 지표 · 행 단위로 덮는다.
- 기초 통계(전체 SQL 집계)와 소스 프로필(범위 차원 · 기간 · 기본 지표 · 설비 차원)을 만든다.

목적: 관리자는 UC에서 태그만 달거나 떼면 되고 앱을 다시 배포하지 않는다. 읽은 목록 · 표본 · 통계는 앱 메모리에 캐시하고(원본은 Unity Catalog · SQL 웨어하우스), 첫 제안이 바뀌면 진단 · 프로필 · 통계를 다시 만든다(캐시 키에 제안 상태를 넣는다).
"""
from __future__ import annotations

import os
import re
import threading
import time

import pandas as pd

from common import data as cd

HERE = os.path.dirname(os.path.abspath(__file__))
SCHEMAS = [s.strip() for s in os.getenv("SOURCE_SCHEMAS", "demo_sudong_catalog.analysis_agent").split(",") if s.strip()]
SOURCE_TAGS = [t.strip() for t in os.getenv("SOURCE_TAGS", "analysis_agent=registered").split(",") if t.strip()]
_CACHE: dict = {}


def _ver(key):
    """캐시 키에 넣는 첫 제안 상태(제안이 오면 다시 만든다)."""
    return cd.spec_provider.key(key) if cd.spec_provider and key else None


def _tmeta(key) -> dict:
    """첫 제안의 테이블 이름 · 기본 목표 지표 · 행 단위."""
    return cd.spec_provider.table_meta(key) if cd.spec_provider and key else {}


def source_key(src) -> str | None:
    if not src:
        return None
    return src.get("table") or src.get("path")


def short(key: str) -> str:
    return key.split("/")[-1] if "/" in key else key.split(".")[-1]


# ----------------------------------------------------------------------------- 목록

def _tag_filter():
    """SOURCE_TAGS → (SQL 조건, 파라미터). 태그가 하나라도 맞으면 등록."""
    conds, params = [], {}
    for i, t in enumerate(SOURCE_TAGS):
        k, _, v = t.partition("=")
        params[f"k{i}"] = k.strip()
        if v.strip():
            params[f"v{i}"] = v.strip()
            conds.append(f"(tag_name = :k{i} AND tag_value = :v{i})")
        else:
            conds.append(f"tag_name = :k{i}")
    return " OR ".join(conds), params


def registered(be) -> list:
    """등록한 테이블 [cat.sch.tbl]. 권한이 있는 것만 보인다(system.information_schema)."""
    if not SOURCE_TAGS:  # 태그 설정이 없으면 지정 스키마 전체
        tables = []
        for sch in SCHEMAS:
            cat, schema = sch.split(".")
            tables += [f"{cat}.{schema}.{n}" for n in be.query(
                f"SELECT table_name FROM `{cat}`.information_schema.tables WHERE table_schema = :s", {"s": schema})["table_name"]]
        return sorted(tables)
    where, params = _tag_filter()
    t = be.query(f"SELECT DISTINCT catalog_name, schema_name, table_name FROM system.information_schema.table_tags WHERE {where}", params)
    return sorted(f"{r.catalog_name}.{r.schema_name}.{r.table_name}" for r in t.itertuples())


def list_sources(be) -> list:
    """등록한 테이블 목록(5분 캐시). Unity Catalog 메타데이터(테이블 이름 · 설명 · 컬럼 이름 · 형식 · 컬럼 설명)만 읽고 테이블 데이터는 읽지 않는다.

    입력: be — 백엔드(등록 테이블 조회용)
    반환: 항목 dict 목록(name · short · kind · rows(None: 행 수는 분석할 때 센다) · n_cols · comment · columns · col_info · meta), 이름순.
    참고: kind가 "컬럼 정보 표"인 것은 표시명 · 역할 등을 담은 설정 테이블이다.
    """
    hit = _CACHE.get("list")
    if hit and time.time() - hit[0] < 300:
        return hit[1]
    tables = registered(be)
    by_schema: dict = {}
    for full in tables:
        cat, sch, tbl = full.split(".")
        by_schema.setdefault((cat, sch), set()).add(tbl)
    from databricks.sdk import WorkspaceClient
    w = WorkspaceClient()
    out = []
    for (cat, schema), names_ in by_schema.items():  # 테이블 설명·컬럼은 Unity Catalog REST(웨어하우스 SQL보다 빠르다)
        for t in w.tables.list(cat, schema):
            if t.name not in names_:
                continue
            info = [{"column": c.name, "type": str(c.type_text or c.type_name or ""), "comment": c.comment or ""} for c in (t.columns or [])]
            names = [c["column"] for c in info]
            kind = "컬럼 정보 표" if {"column_name", "display_name", "role"} <= set(names) else "테이블"
            nc = sum(1 for c in info if c["comment"])
            out.append({"name": f"{cat}.{schema}.{t.name}", "short": t.name, "kind": kind, "rows": None,  # 행 수는 그 테이블로 분석할 때(프로필) 센다
                        "n_cols": len(names), "comment": t.comment or "", "columns": names, "col_info": info,
                        "meta": f"컬럼 설명 {nc}/{len(names)}" if nc else "없음"})
    out.sort(key=lambda i: i["name"])
    _CACHE["list"] = (time.time(), out)
    return out


def data_items(items: list) -> list:
    """화면 카드와 같은 순서·번호의 분석 가능한 소스(컬럼 정보 표 제외)."""
    return [s for s in items if s["kind"] != "컬럼 정보 표"]


# ----------------------------------------------------------------------------- 컬럼 진단

def _read(src, be, limit=20000) -> pd.DataFrame:
    if "table" in src:
        return be.query(f"SELECT * FROM {be._table(src['table'])} LIMIT {int(limit)}")
    return cd.read_path(src["path"], be)


def sample(src: dict, be) -> pd.DataFrame:
    """소스 표본(최대 20,000행). 첫 제안과 무관해 대화끼리 같이 쓴다."""
    key = source_key(src)
    df = _CACHE.get(("df", key))
    if df is None:
        df = _CACHE[("df", key)] = _read(src, be)
    return df


def describe(src: dict, be) -> dict:
    """컬럼별 형식 · 결측 · 값 범위와 역할을 추정한다. 이 테이블의 첫 제안이 있으면 표시명 · 역할 · 분류 · 정상범위 · 규격을 그 제안으로 덮는다. 결과는 캐시한다(첫 제안이 바뀌면 다시 계산).

    입력: src — 소스 dict · be — 백엔드
    반환: {"source", "key", "rows"(표본 행 수), "columns"(컬럼별 진단: col · type · role · missing · range · values · label · name · normal · spec · desc 등), "spec_table"(첫 제안 테이블 또는 None), "n_meta"(제안으로 덮은 컬럼 수), "guess"(식별자 · 날짜 · 시간 순서 · 기본 지표 추정)}
    참고: 역할 — date(날짜), id(값이 행마다 다른 정수, 또는 짧은 고유 문자열), dimension(문자열 값 50개 이하), num(수치, 문자로 저장된 숫자 포함), text(그 밖의 문자열).
    """
    key = source_key(src)
    ck = ("desc", key, _ver(key))
    hit = _CACHE.get(ck)
    if hit:
        return hit
    df = sample(src, be)
    cols = []
    for c in df.columns:
        s = df[c]
        nn = s.notna().sum()
        nu = int(s.nunique(dropna=True))
        miss = round(float(1 - nn / max(1, len(s))), 3)
        if cd.is_datetime(s) or (s.dtype == object and nn and pd.to_datetime(s.dropna().head(50), errors="coerce").notna().all()
                                  and s.dropna().astype(str).str.match(r"^\d{4}-\d{2}-\d{2}").all()):
            d = pd.to_datetime(s, errors="coerce")
            cols.append({"col": c, "type": "date", "role": "date", "missing": miss, "range": [str(d.min())[:10], str(d.max())[:10]]})
        elif cd.is_num(s):
            role = "id" if nu == len(s) and nu > 100 and pd.api.types.is_integer_dtype(s) else "num"
            cols.append({"col": c, "type": "num", "role": role, "missing": miss, "unique": nu,
                         "range": [float(s.min()), float(s.median()), float(s.max())] if nn else None})
        else:
            st = s.dropna().astype(str)
            numeric_like = nn and pd.to_numeric(st.str.replace(",", "", regex=False), errors="coerce").notna().mean() >= 0.8
            if numeric_like:
                cols.append({"col": c, "type": "num(문자열)", "role": "num", "missing": miss, "unique": nu})
            elif nu >= 0.95 * nn and nn > 100:
                cols.append({"col": c, "type": "text", "role": "id" if st.str.len().mean() < 30 else "text", "missing": miss, "unique": nu})
            elif nu <= 50:
                vc = st.value_counts()
                cols.append({"col": c, "type": "cat", "role": "dimension", "missing": miss, "unique": nu,
                             "values": {k: int(v) for k, v in vc.head(12).items()}})
            else:
                cols.append({"col": c, "type": "text", "role": "text", "missing": miss, "unique": nu})
    spec_table = cd.UC_SPEC + src["table"] if "table" in src and isinstance(be, cd.SqlBackend) else None  # 컬럼 정보 = 첫 제안
    try:
        spec = cd.load_spec({"spec_table": spec_table}, be) if spec_table else None
    except Exception:  # noqa: BLE001
        spec = None
    n_meta = 0
    if spec is not None:
        sm = {r.column_name: r for r in spec.itertuples()}
        for x in cols:
            r = sm.get(x["col"])
            if r is None or not any(isinstance(v, str) and v for v in (r.display_name, r.role, r.description)):
                continue
            n_meta += 1
            x["label"] = cd.label(x["col"], sm)
            if isinstance(r.display_name, str) and r.display_name:
                x["name"] = r.display_name
            if isinstance(r.role, str) and r.role:
                x["role"] = r.role if x["role"] != "date" else "date"
                x["declared"] = True
            if isinstance(r.category, str) and r.category:
                x["category"] = r.category
            if cd.bounds(r):
                x["normal"] = list(cd.bounds(r))
            if pd.notna(r.spec_min) or pd.notna(r.spec_max):
                x["spec"] = [None if pd.isna(v) else float(v) for v in (r.spec_min, r.spec_max)]
            if isinstance(r.description, str):
                x["desc"] = r.description[:60]
    ids = [x["col"] for x in cols if x["role"] == "id"]
    dates = [x["col"] for x in cols if x["role"] == "date"]
    timed = [c for c in dates[1:] if (pd.to_datetime(df[c], errors="coerce").dropna().dt.normalize()
                                       != pd.to_datetime(df[c], errors="coerce").dropna()).any()]  # 시각까지 있는 날짜 = 같은 날 안의 순서
    dy = _tmeta(key).get("default_y") if "table" in src else None
    out = {"source": src, "key": key, "rows": int(len(df)), "columns": cols,
           "spec_table": spec_table if n_meta else None, "n_meta": n_meta,
           "guess": {"id_col": ids[0] if ids else None, "date_col": dates[0] if dates else None,
                     "order_col": timed[0] if timed else None,
                     "y": dy if dy in df.columns else None}}
    _CACHE[ck] = out
    return out


def describe_md(d: dict) -> str:
    meta = f"컬럼 정보 {d['n_meta']}/{len(d['columns'])}" if d.get("n_meta") else "첫 제안 전(컬럼 이름으로 추정)"
    out = [f"### `{d['key']}` · {d['rows']:,}행 (최대 20,000행 표본) · {meta}",
           f"- 식별자 `{d['guess']['id_col']}`, 시간 순서 `{d['guess']['date_col']}`" + (f", 기본 지표 `{d['guess']['y']}`" if d["guess"].get("y") else ""),
           "| 컬럼 | 표시명 | 형식 | 역할 | 결측 | 값 | 정상범위·설명 |", "|---|---|---|---|---|---|---|"]
    for c in d["columns"]:
        if c.get("values"):
            v = ", ".join(f"{k}({n})" for k, n in c["values"].items())
        elif c.get("range") and c["type"] == "date":
            v = f"{c['range'][0]}–{c['range'][1]}"
        elif c.get("range"):
            v = "최소·중앙·최대 " + " / ".join(f"{x:.4g}" for x in c["range"])
        else:
            v = f"고유값 {c.get('unique', '-')}개"
        spec = "~".join("" if v is None else f"{v:g}" for v in c["spec"]) if c.get("spec") else ""
        extra = (f"정상 {cd.range_text(c['normal'])} " if c.get("normal") else "") + (f"규격 {spec} " if spec else "") + (c.get("desc") or "")
        out.append(f"| `{c['col']}` | {c.get('label', '-')} | {c['type']} | {c['role']} | {c['missing']:.0%} | {v} | {extra or '-'} |")
    if not d.get("n_meta"):
        out.append("\n- 첫 제안이 없어 표시명은 컬럼명 그대로이고, 결과성 변수(결과가 나온 뒤 정해지는 값) 자동 제외가 되지 않는다. "
                   "이름으로 결과성으로 보이는 컬럼(예: final_*, *_end, 사용량 합계)은 사용자에게 한 문장으로 알리고 x_exclude 후보로 제안한다.")
    return "\n".join(out)


# ----------------------------------------------------------------------------- 기초 통계 (첫 화면)

_NUM_TYPES = ("TINYINT", "SMALLINT", "INT", "BIGINT", "LONG", "SHORT", "BYTE", "FLOAT", "DOUBLE", "DECIMAL")
_DATE_TYPES = ("DATE", "TIMESTAMP")
TOP_MAX = 20  # 값 종류가 이 이하인 문자열 컬럼은 값별 건수를 보여준다


def table_stats(src: dict, be) -> dict:
    """테이블 전체를 SQL로 집계한 기초 통계(표본 아님). 컬럼마다 결측 비율을 내고, 수치는 최소 · 평균 · 최대, 날짜는 기간, 문자열은 값 종류 수(TOP_MAX 이하면 값별 건수)를 낸다.

    입력: src — 소스 dict(table 필수) · be — 백엔드
    반환: {"rows", "n_cols", "date"(추정 날짜 컬럼의 기간 또는 None), "columns"(컬럼별 통계)}. 첫 제안에 정상범위가 있으면 그 밖의 값 수(out_of_range)를 덧붙인다. 결과는 캐시한다.
    참고: 문자로 저장된 숫자(describe가 num(문자열)로 본 컬럼)는 숫자로 읽어 수치처럼 집계하고, 숫자로 읽히지 않는 값(분석에서 결측이 되는 값)은 따로 센다.
    """
    key = source_key(src)
    ck = ("stats", key, _ver(key))
    hit = _CACHE.get(ck)
    if hit:
        return hit
    base = _base_stats(src, be)
    meta = {x["col"]: x for x in describe(src, be)["columns"]}
    ranges = {c["col"]: meta[c["col"]]["normal"] for c in base["columns"] if c["kind"] == "num" and meta.get(c["col"], {}).get("normal")}
    oo = {}
    if ranges:  # 첫 제안 정상범위 밖 값 수 (분석에서는 결측으로 처리되는 값)
        def cond(c, rng):
            q, parts = base["exprs"][c], []
            if rng[0] is not None:
                parts.append(f"{q} < {float(rng[0])}")
            if rng[1] is not None:
                parts.append(f"{q} > {float(rng[1])}")
            return " OR ".join(parts)
        row = be.query("SELECT " + ", ".join(f"SUM(CASE WHEN {cond(c, r)} THEN 1 ELSE 0 END) AS oo{i}" for i, (c, r) in enumerate(ranges.items()))
                       + f" FROM {be._table(src['table'])}").iloc[0]
        oo = {c: int(row[f"oo{i}"]) for i, c in enumerate(ranges) if not pd.isna(row[f"oo{i}"]) and int(row[f"oo{i}"])}
    out_cols = []
    for c in base["columns"]:
        m = meta.get(c["col"], {})
        x = {**c, "label": m.get("label") or c["col"], "category": m.get("category"), "role": m.get("role")}
        if c["col"] in oo:
            x["out_of_range"], x["normal"] = oo[c["col"]], ranges[c["col"]]
        out_cols.append(x)
    dcol = describe(src, be)["guess"]["date_col"]
    date = next(({"col": x["col"], "label": x["label"], "min": str(x["min"])[:10], "max": str(x["max"])[:10]}
                 for x in out_cols if x["col"] == dcol and x.get("min")), None)
    out = {"rows": base["rows"], "n_cols": base["n_cols"], "date": date, "columns": out_cols}
    _CACHE[ck] = out
    return out


def _base_stats(src: dict, be) -> dict:
    """첫 제안과 무관한 전체 집계(대화끼리 같이 쓴다)."""
    key = source_key(src)
    hit = _CACHE.get(("stats0", key))
    if hit:
        return hit
    t = be._table(src["table"])
    item = next((i for i in list_sources(be) if i["name"] == src["table"]), None) or {}  # 컬럼 형식은 등록 목록(UC REST, 캐시)에 있다
    cols = [(c["column"], str(c["type"]).upper()) for c in item.get("col_info", [])]
    if not cols:
        cat, sch, tbl = src["table"].split(".")
        types = be.query(f"SELECT column_name, data_type FROM `{cat}`.information_schema.columns "
                         "WHERE table_schema = :s AND table_name = :t ORDER BY ordinal_position", {"s": sch, "t": tbl})
        cols = [(r.column_name, str(r.data_type).upper()) for r in types.itertuples()]
    kind = {c: "num" if ty.startswith(_NUM_TYPES) else "date" if ty.startswith(_DATE_TYPES) else "cat" for c, ty in cols}
    df = sample(src, be)
    textnum = {c for c in kind if kind[c] == "cat" and c in df.columns and not cd.is_num(df[c]) and df[c].notna().any()
               and pd.to_numeric(df[c].dropna().astype(str).str.replace(",", "", regex=False), errors="coerce").notna().mean() >= 0.8}
    num_expr = lambda c: f"TRY_CAST(REPLACE(TRIM(`{c}`), ',', '') AS DOUBLE)" if c in textnum else f"`{c}`"  # 문자열 숫자 변환과 같은 규칙
    for c in textnum:
        kind[c] = "num"
    exprs = ["COUNT(*) AS n"]
    for i, (c, _) in enumerate(cols):
        q = num_expr(c) if kind[c] == "num" else f"`{c}`"
        exprs.append(f"COUNT(`{c}`) AS nn{i}")
        if c in textnum:
            exprs.append(f"COUNT({q}) AS nv{i}")
        if kind[c] == "num":
            exprs += [f"MIN({q}) AS lo{i}", f"AVG({q}) AS av{i}", f"MAX({q}) AS hi{i}"]
        elif kind[c] == "date":
            exprs += [f"CAST(MIN({q}) AS STRING) AS lo{i}", f"CAST(MAX({q}) AS STRING) AS hi{i}"]
        else:
            exprs.append(f"COUNT(DISTINCT {q}) AS nd{i}")
    row = be.query(f"SELECT {', '.join(exprs)} FROM {t}").iloc[0]
    n = int(row["n"])
    few = [c for i, (c, _) in enumerate(cols) if kind[c] == "cat" and 0 < int(row[f"nd{i}"]) <= TOP_MAX]
    q_top = " UNION ALL ".join(f"SELECT '{c}' AS col, CAST(`{c}` AS STRING) AS v, COUNT(*) AS cnt FROM {t} WHERE `{c}` IS NOT NULL GROUP BY `{c}`"
                               for c in few)  # 값 종류가 적은 문자열 컬럼의 값별 건수
    q_bad = " UNION ALL ".join(f"SELECT '{c}' AS col, CAST(`{c}` AS STRING) AS v, COUNT(*) AS cnt FROM {t} "
                               f"WHERE `{c}` IS NOT NULL AND {num_expr(c)} IS NULL GROUP BY `{c}`" for c in textnum)  # 숫자로 읽히지 않는 값별 건수
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=2) as ex:  # 두 집계는 서로 무관해 동시에(SQL마다 연결을 열어 차례로 하면 느리다)
        f_top, f_bad = (ex.submit(be.query, q) if q else None for q in (q_top, q_bad))
        tops, bad = {}, {}
        for f, dst in ((f_top, tops), (f_bad, bad)):
            if f is not None:
                for r in f.result().sort_values("cnt", ascending=False).itertuples():
                    dst.setdefault(r.col, []).append([r.v, int(r.cnt)])
    out_cols = []
    for i, (c, _) in enumerate(cols):
        x = {"col": c, "kind": kind[c], "missing": round(1 - int(row[f"nn{i}"]) / n, 4) if n else 0.0}
        if kind[c] == "num":
            x.update({k: None if pd.isna(row[f"{p}{i}"]) else float(row[f"{p}{i}"]) for k, p in (("min", "lo"), ("mean", "av"), ("max", "hi"))})
            if c in textnum:
                x["text_num"] = {"non_numeric": int(row[f"nn{i}"]) - int(row[f"nv{i}"]), "values": bad.get(c, [])[:4]}
        elif kind[c] == "date":
            x.update({"min": row[f"lo{i}"], "max": row[f"hi{i}"]})
        else:
            x["distinct"] = int(row[f"nd{i}"])
            if c in tops:
                x["top"] = tops[c]
        out_cols.append(x)
    out = {"rows": n, "n_cols": len(cols), "columns": out_cols, "exprs": {c: num_expr(c) for c, _ in cols}}
    _CACHE[("stats0", key)] = out
    return out


# ----------------------------------------------------------------------------- 소스 프로필 (예시 질문·다음 단계 버튼용 실제 값)

EQUIP_CATS = cd.EQUIP_CATS  # 분류가 이 값인 차원 = 설비 단위


_SUMMARY_LOCK = threading.Lock()


def table_summary(src: dict, be) -> dict:
    """테이블 전체 행 수와 날짜·시각 형식 컬럼마다 기간(SQL 한 번, 캐시). 첫 제안과 무관해 첫 제안을 받는 동안 미리 읽어 둘 수 있다.

    입력: src — 소스 dict · be — 백엔드
    반환: {"rows": 전체 행 수(SQL 테이블이 아니거나 실패하면 None), "ranges": {컬럼: (시작, 끝)}}
    """
    key = source_key(src)
    with _SUMMARY_LOCK:  # 미리 읽기와 본 요청이 겹쳐도 한 번만 읽는다
        if ("summary", key) in _CACHE:
            return _CACHE[("summary", key)]
        out = {"rows": None, "ranges": {}}
        if "table" in src and isinstance(be, cd.SqlBackend):
            try:
                item = next((i for i in list_sources(be) if i["name"] == src["table"]), None) or {}
                dates = [c["column"] for c in item.get("col_info", []) if c["type"].lower().startswith(("date", "timestamp"))]
                sel = ", ".join(["COUNT(*) AS n"] + [f"CAST(MIN(`{c}`) AS STRING) AS lo{i}, CAST(MAX(`{c}`) AS STRING) AS hi{i}"
                                                     for i, c in enumerate(dates)])
                r = be.query(f"SELECT {sel} FROM {be._table(src['table'])}")
                out["rows"] = int(r["n"][0])
                for i, c in enumerate(dates):
                    lo, hi = pd.to_datetime(r[f"lo{i}"][0], errors="coerce"), pd.to_datetime(r[f"hi{i}"][0], errors="coerce")
                    if not (pd.isna(lo) or pd.isna(hi)):
                        out["ranges"][c] = (lo, hi)
            except Exception:  # noqa: BLE001  (행 수·기간은 없어도 된다 — 다음에 다시 읽는다)
                return out
        _CACHE[("summary", key)] = out
        return out


def _date_range(src, be, col, df):
    """표본의 기간(파일·Spark 또는 날짜 형식이 아닌 컬럼)."""
    d = pd.to_datetime(df[col], errors="coerce")
    lo, hi = d.min(), d.max()
    return (None, None) if pd.isna(lo) or pd.isna(hi) else (lo, hi)


def title(key: str | None, be) -> str:
    """소스 이름: 첫 제안의 테이블 이름 → 테이블 설명(UC comment)의 첫 구절(30자 이하) → 테이블·파일 이름."""
    t = _tmeta(key).get("title") if key else None
    if t:
        return t
    try:
        c = next((i["comment"] for i in list_sources(be) if i["name"] == key and i["kind"] == "테이블"), "")
    except Exception:  # noqa: BLE001
        c = ""
    head = re.split(r"\s[—–-]\s|[.(:]", c or "")[0].strip()
    return head if 2 <= len(head) <= 30 else short(key or "")


def profile(src: dict, be) -> dict:
    """소스의 실제 값 요약(컬럼 진단 + 표본, 첫 제안 기준). 설정 패널의 범위 칸 · 첫 화면 · 시연 문장이 쓴다. 결과는 캐시한다.

    입력: src — 소스 dict · be — 백엔드
    반환: {"key", "short", "title", "rows"(테이블이면 전체 행 수), "unit"(행 단위), "id_col", "date_col", "date_range"(["시작", "끝"] 또는 None), "dates", "dims"(차원: col · label · category · values), "scope"(범위 차원 컬럼 목록), "equip"(설비 차원 또는 None), "y"(기본 지표 또는 None), "ys"(목표 지표 후보 목록)}
    참고: 범위 차원은 설비 차원과 하위 구분(상위 값 하나에 묶이는 차원)을 뺀 것을 값 종류가 적은 순으로 둔다. 설비 차원은 분류가 EQUIP_CATS인 차원이다. 행 단위는 첫 제안의 row_unit, 없으면 식별자 이름에서 ID · 번호 · 코드를 뺀 말, 그것도 없으면 "행".
    """
    key = source_key(src)
    ck = ("prof", key, _ver(key))
    if ck in _CACHE:
        return _CACHE[ck]
    d = describe(src, be)
    df = sample(src, be)
    cols = d["columns"]
    by = {x["col"]: x for x in cols}
    name = lambda c: (by.get(c) or {}).get("name") or c

    dims = [x for x in cols if x["role"] == "dimension" and x.get("values") and 2 <= x.get("unique", 0) <= 50
            and (x.get("declared") or not d["n_meta"])]  # 첫 제안이 있으면 역할을 정한 차원만
    equip = next((x for x in dims if str(x.get("category") or "").lower() in EQUIP_CATS), None)
    scope = sorted([x for x in dims if x is not equip], key=lambda x: x["unique"])
    scope = [x for x in scope if not any(  # 다른 범위 차원의 하위 구분(예: 제품 안의 균주)은 뺀다: 값마다 상위 값이 하나, 종류는 더 많음
        o is not x and 1 < o["unique"] < x["unique"] and int(df.groupby(x["col"])[o["col"]].nunique().max()) == 1 for o in scope)]

    ys = [x for x in cols if x["role"] == "y"]
    num_ys = [x for x in ys if x["type"].startswith("num") and x["col"] in df.columns]
    ycol = d["guess"].get("y") or (num_ys[0]["col"] if num_ys else None)

    date_col = d["guess"]["date_col"]

    id_col = d["guess"]["id_col"]
    unit = (_tmeta(key).get("row_unit") if "table" in src else None) or \
        (re.sub(r"\s*(ID|id|번호|코드)$", "", name(id_col)).strip() if id_col and name(id_col) != id_col else "")
    rows, (lo, hi) = d["rows"], (None, None)
    sm = table_summary(src, be)
    rows = sm["rows"] or rows
    if date_col:
        lo, hi = sm["ranges"].get(date_col) or _date_range(src, be, date_col, df)  # 날짜 형식이 아닌 컬럼(문자 날짜)은 표본으로
    out = {"key": key, "short": short(key or ""), "title": title(key, be),
           "rows": rows, "unit": unit or "행", "id_col": id_col, "date_col": date_col,
           "date_range": [lo.strftime("%Y-%m-%d"), hi.strftime("%Y-%m-%d")] if hi is not None else None,
           "dates": [{"col": x["col"], "label": name(x["col"])} for x in cols if x["role"] == "date"],
           "dims": [{"col": x["col"], "label": name(x["col"]), "category": x.get("category"),
                     "values": sorted(str(v) for v in x["values"])} for x in dims],
           "scope": [x["col"] for x in scope], "equip": {"col": equip["col"], "label": name(equip["col"])} if equip else None,
           "y": {"col": ycol, "label": name(ycol)} if ycol else None,
           "ys": [{"col": x["col"], "label": name(x["col"])} for x in ys]}
    _CACHE[ck] = out
    return out
