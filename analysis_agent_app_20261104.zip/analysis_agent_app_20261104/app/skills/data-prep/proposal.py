"""데이터 처리 skill의 첫 제안: 테이블마다 LLM이 한 번 정하는 컬럼 정보와 작업 데이터 시작값.

용도:
- 테이블마다 한 번(그 테이블로 처음 분석·데이터 처리를 할 때) LLM에 자연어 테이블·컬럼 설명과 값 요약을 보내 제안을 받는다.
  컬럼을 묶음(CHUNK개씩)으로 나눠 동시에 묻고, 테이블 이름·기본 지표는 작은 호출 하나로 같이 묻는다(한 번에 다 쓰게 하면 출력이 길어 느리다).
- 제안은 두 가지를 담는다. (1) 컬럼 정보: 표시명 · 단위 · 분류 · 설비 여부 · 규격, 테이블 이름 · 행 단위
  (데이터 카탈로그가 보여 준다). (2) 작업 데이터 시작값: 역할(범위 구분 · 영향 요인 · 목표 지표 후보 · 결과 뒤 값 · 식별자 · 날짜 · 메모),
  변수별 정상범위, 기본 목표 지표(데이터 처리 skill이 쓴다).
- 첫 화면 예시 질문은 제안이 끝난 뒤 따로 만든다(분석을 기다리게 하지 않는다). 끝나면 제안의 examples에 들어간다.
목적: 사람이 컬럼마다 설정하지 않아도 되게 하면서, 대화에서 고친 값(normal_by_col · var_roles)은 그 대화의 작업 데이터에만 남기고 이 제안은 바꾸지 않는다.
common.data의 spec_provider로 끼워져 load_spec·sources가 이 제안을 쓴다.
"""
from __future__ import annotations

import json
import os
import re
import sys
import contextvars
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import numpy as np
import pandas as pd

from common import data as cd

ROLES = ("id", "date", "dimension", "x", "y", "result", "text")
FIELDS = ("label", "unit", "category", "role", "equipment", "normal", "spec")
MODEL = os.getenv("PROPOSAL_MODEL")  # 비우면 앱 모델
_BY_TABLE: dict[str, dict] = {}                 # 테이블 → 제안
_PENDING: dict[str, threading.Event] = {}      # 제안 받는 중(같은 테이블을 두 번 받지 않게)
_LOCK = threading.Lock()
_HERE = os.path.dirname(os.path.abspath(__file__))
_PROMPT = os.path.join(_HERE, "proposal_prompt.md")
_EX_PROMPT = os.path.join(_HERE, "examples_prompt.md")
CHUNK = 12        # 한 호출에 묻는 컬럼 수
MAX_PARALLEL = 6  # 동시에 보내는 호출 수(모델 분당 한도)


def ready(table: str | None) -> bool:
    return bool(table) and table in _BY_TABLE


def key(table: str | None) -> str | None:
    """캐시 키를 돌려준다. 제안이 있으면 "p"(제안 전에 만든 진단·통계는 제안이 오면 다시 만든다), 없으면 None.

    입력: table — 테이블 이름(None 가능)
    반환: "p" 또는 None
    """
    return "p" if ready(table) else None


def get(table: str | None) -> dict | None:
    """테이블의 제안 dict를 돌려준다(없으면 None). 제안 dict는 table · columns 키를 가진다.

    입력: table — 테이블 이름(None 가능)
    반환: 제안 dict 또는 None
    """
    return _BY_TABLE.get(table or "")


def spec_frame(table: str) -> pd.DataFrame | None:
    """common.data.load_spec이 부른다: 제안을 컬럼 정보 표(SPEC_COLS)로 바꾼다. 제안이 없으면 None.

    설비 여부가 true면 분류를 "설비"로 쓴다. 정상범위·규격은 숫자 두 값이고 없으면 NaN이다.
    입력: table — 테이블 이름
    반환: SPEC_COLS 형식 DataFrame 또는 None
    """
    d = get(table)
    if not d:
        return None
    rows = []
    for c, v in d["columns"].items():
        nmin, nmax = v.get("normal") or [None, None]
        smin, smax = v.get("spec") or [None, None]
        rows.append({"column_name": c, "display_name": v.get("label"), "unit": v.get("unit"),
                     "category": "설비" if v.get("equipment") else v.get("category"), "role": v.get("role"),
                     "normal_min": _f(nmin), "normal_max": _f(nmax), "spec_min": _f(smin), "spec_max": _f(smax),
                     "description": v.get("comment")})
    return pd.DataFrame(rows, columns=cd.SPEC_COLS)


def table_meta(table: str | None) -> dict:
    """테이블 이름 · 기본 목표 지표 · 행 단위를 돌려준다. 제안이 없으면 빈 dict.

    입력: table — 테이블 이름(None 가능)
    반환: dict(title, default_y, row_unit, description) 또는 빈 dict
    """
    return (get(table) or {}).get("table") or {}


cd.spec_provider = sys.modules[__name__]  # common.data가 이 모듈의 spec_frame · table_meta · key를 쓴다


def ensure(table: str, backend, client, model: str, emit=None, skills=None) -> dict:
    """이 테이블의 제안이 없으면 LLM에 한 번 받는다. 다른 요청이 받는 중이면 그 결과를 기다린다.

    같은 테이블을 여러 요청이 동시에 받지 않게 한다. 기다리는 쪽은 최대 180초 기다리고, 그래도 끝나지 않으면 오류를 낸다.
    입력: table — 테이블 이름, backend — 데이터 어댑터, client — OpenAI 호환 LLM 클라이언트,
          model — 앱 모델(환경변수 PROPOSAL_MODEL이 있으면 그 값을 쓴다), emit — 진행 알림 콜백(선택),
          skills — 앱이 할 수 있는 일 [(제목, 설명)](예시 질문에 쓴다, 없으면 예시 질문을 만들지 않는다)
    반환: 제안 dict(table, columns, 나중에 examples). 제안 실패 시 예외를 그대로 올린다.
    """
    while True:
        with _LOCK:
            if table in _BY_TABLE:
                return _BY_TABLE[table]
            ev = _PENDING.get(table)
            mine = ev is None
            if mine:
                ev = _PENDING[table] = threading.Event()
        if emit:
            emit({"type": "activity", "text": "이 테이블을 처음 써서 컬럼 구성을 파악하는 중"})
        if not mine:
            ev.wait(180)
            with _LOCK:
                if table in _BY_TABLE:
                    return _BY_TABLE[table]
                if _PENDING.get(table) is ev:  # 기다리던 제안이 끝나지 않았다
                    raise cd.PipelineError("데이터 처리 첫 제안이 끝나지 않았습니다. 잠시 뒤 다시 시도해 주세요.")
            continue  # 앞선 제안이 실패했으면 다시 받는다
        try:
            d = propose(table, backend, client, MODEL or model)
            with _LOCK:
                _BY_TABLE[table] = d
            if skills:  # 예시 질문은 뒤에서 만든다(기다리지 않는다, 이 요청의 추적과 섞지 않게 새 맥락에서)
                threading.Thread(target=contextvars.Context().run, args=(_add_examples, d, client, MODEL or model, skills), daemon=True).start()
            return d
        finally:
            with _LOCK:
                _PENDING.pop(table, None)
            ev.set()


# ----------------------------------------------------------------------------- 제안

def profile_columns(table: str, backend) -> tuple[str, list]:
    """LLM에 보낼 테이블 프로필을 만든다: 테이블 설명과 컬럼마다 이름 · 형식 · 자연어 설명 · 값 요약.

    값 요약은 수치면 최소·1%·중앙값·99%·최대(숫자로 못 읽힌 값 상위 4개 포함), 날짜면 최소~최대,
    그 밖이면 값 빈도 상위 8개다. 목록과 표본은 sources 모듈 함수로 읽는다.
    입력: table — 테이블 이름, backend — 데이터 어댑터
    반환: (테이블 설명 문자열, 컬럼 정보 dict list). 등록된 테이블이 아니면 PipelineError.
    """
    import sources as S
    item = next((i for i in S.list_sources(backend) if i["name"] == table), None)
    if item is None:
        raise cd.PipelineError(f"등록된 테이블이 아닙니다: {table}")
    df = S.sample({"table": table}, backend)
    out = []
    for c in item["col_info"]:
        s = df[c["column"]] if c["column"] in df.columns else pd.Series(dtype=object)
        info = {**c, "missing": round(float(s.isna().mean()), 3) if len(s) else None, "distinct": int(s.nunique())}
        num = s if cd.is_num(s) else pd.to_numeric(s.astype(str).str.replace(",", "", regex=False).str.strip(), errors="coerce")
        if num.notna().mean() >= 0.8 and s.nunique() > 2 and not cd.is_datetime(s):
            q = num.quantile([0, 0.01, 0.5, 0.99, 1]).round(4).tolist()
            info["numeric"] = {"min": q[0], "p1": q[1], "median": q[2], "p99": q[3], "max": q[4]}
            bad = s[s.notna() & num.isna()].astype(str).value_counts().head(4).to_dict()
            if bad:
                info["non_numeric"] = bad
        elif cd.is_datetime(s):
            info["date_range"] = [str(s.min())[:19], str(s.max())[:19]]
        else:
            info["top"] = {str(k): int(v) for k, v in s.astype(str).value_counts().head(8).items()}
        out.append(info)
    return item["comment"], out


def propose(table: str, backend, client, model: str) -> dict:
    """LLM에 첫 제안(컬럼 정보 · 역할 · 정상범위 · 기본 목표 지표)을 받는다. 컬럼 묶음마다 한 호출 + 테이블 정보 한 호출을 동시에 보낸다.

    묶음마다 테이블 전체 컬럼 이름·설명을 같이 보내 분류가 테이블 안에서 일관되게 한다. 응답 값은 엔진이 깨지지 않도록 형식만 맞춘다.
    입력: table — 테이블 이름, backend — 데이터 어댑터, client — OpenAI 호환 LLM 클라이언트, model — 호출 모델 이름
    반환: dict — table(title, default_y, row_unit, description), columns({컬럼: label · unit · category · role ·
          equipment · normal · spec · comment}). 어느 호출이든 두 번 모두 JSON을 못 읽으면 PipelineError.
    """
    t0 = time.time()
    tcomment, cols = profile_columns(table, backend)
    t1 = time.time()
    with open(_PROMPT, encoding="utf-8") as fp:
        system = fp.read()
    base = {"table_name": table, "table_description": tcomment, "today": time.strftime("%Y-%m-%d"),
            "all_columns": {c["column"]: c.get("comment") or "" for c in cols}}
    chunks = [cols[i:i + CHUNK] for i in range(0, len(cols), CHUNK)]
    jobs = [("table", {"task": "table", **base})] + [("columns", {"task": "columns", **base, "columns": ch}) for ch in chunks]
    import mlflow  # 추적이 꺼져 있으면 span은 아무 일도 하지 않는다
    names = ["테이블 정보"] + [f"컬럼 {i * CHUNK + 1}~{i * CHUNK + len(ch)}" for i, ch in enumerate(chunks)]
    with mlflow.start_span(name="첫 제안 (테이블마다 한 번)", span_type="CHAIN") as sp:
        sp.set_inputs({"table": table, "columns": len(cols), "calls": names})
        with ThreadPoolExecutor(max_workers=min(MAX_PARALLEL, len(jobs))) as ex:  # 호출마다 지금 맥락을 복사해 넘긴다(이 span 아래에 묶인다)
            futs = [ex.submit(contextvars.copy_context().run, _named, n, client, model, system, j[1], j[0]) for n, j in zip(names, jobs)]
            answers = [f.result() for f in futs]
        sp.set_outputs({"table": answers[0].get("table"), "columns_answered": sum(len(a.get("columns") or {}) for a in answers[1:])})
    print(f"[proposal] {table}: 표본 {t1 - t0:.1f}s · LLM {len(jobs)}건 동시 {time.time() - t1:.1f}s", file=sys.stderr, flush=True)
    t = answers[0]["table"]
    got = {}
    for a in answers[1:]:
        got.update(a.get("columns") or {})
    columns = {}
    for c in cols:  # 형식만 맞춘다(엔진이 깨지지 않게): 역할은 정해진 값, 범위는 숫자 두 개
        v = got.get(c["column"]) or {}
        if isinstance(v, list):  # [label, unit, category, role, equipment, normal, spec]
            v = dict(zip(FIELDS, v))
        columns[c["column"]] = {
            "label": str(v.get("label") or c["column"])[:30], "unit": (str(v["unit"])[:15] if v.get("unit") else None),
            "category": (str(v["category"])[:12] if v.get("category") else None),
            "role": v.get("role") if v.get("role") in ROLES else None, "equipment": bool(v.get("equipment")),
            "normal": _clean_range(v.get("normal")), "spec": _clean_range(v.get("spec")), "comment": c["comment"]}
    dy = t.get("default_y") if (t.get("default_y") in columns and columns[t["default_y"]]["role"] == "y") else \
        next((c for c, v in columns.items() if v["role"] == "y"), None)
    values = {c["column"]: (list(c["top"])[:6] if c.get("top") else c.get("date_range")) for c in cols  # 예시 질문에 쓸 실제 값
              if columns[c["column"]]["role"] in ("dimension", "date") and (c.get("top") or c.get("date_range"))}
    return {"table": {"title": str(t.get("title") or table.split(".")[-1])[:30], "default_y": dy,
                      "row_unit": (str(t["row_unit"])[:6] if t.get("row_unit") else None), "description": tcomment},
            "columns": columns, "_values": values}


def _named(name: str, client, model: str, system: str, payload: dict, need: str) -> dict:
    """첫 제안 호출 하나를 이름 붙은 span으로(추적 화면에서 '컬럼 1~12'처럼 보이게)."""
    import mlflow
    with mlflow.start_span(name=f"첫 제안 · {name}", span_type="CHAIN"):
        return _ask_json(client, model, system, payload, 4000, need=need)


def _ask_json(client, model: str, system: str, payload: dict, max_tokens: int, need: str | None = None) -> dict:
    """LLM 한 번 호출해 JSON 객체를 받는다. 깨지거나 need 키(dict)가 없으면 한 번 더.
    입력: 시스템 프롬프트 · 사용자 JSON(dict) · 꼭 있어야 하는 키 → 반환: dict(두 번 다 실패면 PipelineError)."""
    user = json.dumps(payload, ensure_ascii=False, default=str)
    raw = ""
    for _ in range(2):
        r = client.chat.completions.create(model=model, max_tokens=max_tokens, messages=[
            {"role": "system", "content": system}, {"role": "user", "content": user}])
        raw = _text(r.choices[0].message.content)
        m = re.search(r"\{.*\}", raw, re.S)
        try:
            ans = json.loads(m.group(0)) if m else None
        except json.JSONDecodeError:
            ans = None
        if isinstance(ans, dict) and (need is None or isinstance(ans.get(need), dict)):
            return ans
    raise cd.PipelineError("데이터 처리 첫 제안을 읽지 못했습니다.", {"raw": raw[:300]})


def _add_examples(d: dict, client, model: str, skills) -> None:
    """첫 화면 예시 질문을 만들어 제안 dict의 examples에 넣는다(뒤에서 돈다, 실패하면 예시 없이 둔다).

    입력: d — 제안 dict(columns · table), client · model — LLM, skills — 할 수 있는 일 [(제목, 설명)]
    반환: 없음(부작용: d["examples"])
    """
    try:
        with open(_EX_PROMPT, encoding="utf-8") as fp:
            system = fp.read()
        tbl, hint = d["table"], d.get("_values") or {}
        cols = [{"label": v["label"], "role": v["role"], **({"values": hint[c]} if c in hint else {})}
                for c, v in d["columns"].items() if v["role"] in ("dimension", "date", "y", "x")]
        payload = {"table": tbl["title"], "description": tbl.get("description"), "row_unit": tbl.get("row_unit"),
                   "default_y": d["columns"].get(tbl.get("default_y") or "", {}).get("label"), "columns": cols,
                   "can_do": [{"title": a, "summary": b} for a, b in skills]}
        ans = _ask_json(client, model, system, payload, 800, need=None)
        d["examples"] = [str(e)[:80] for e in (ans.get("examples") or []) if isinstance(e, str)][:5]
    except Exception as e:  # noqa: BLE001  (예시 질문은 없어도 된다)
        print(f"[proposal] 예시 질문 실패: {type(e).__name__}: {e}", file=sys.stderr, flush=True)


def _text(content) -> str:
    if isinstance(content, str):
        return content
    return "".join(p.get("text", "") if isinstance(p, dict) else str(p) for p in content or [])


def _f(v):
    try:
        return float(v) if v is not None else np.nan
    except (TypeError, ValueError):
        return np.nan


def _clean_range(v):
    """[min, max](한쪽은 null 가능) → 숫자 두 개 또는 None."""
    if not isinstance(v, (list, tuple)) or len(v) != 2:
        return None
    a, b = (_f(x) for x in v)
    if np.isnan(a) and np.isnan(b):
        return None
    if not np.isnan(a) and not np.isnan(b) and a > b:
        a, b = b, a
    return [None if np.isnan(a) else a, None if np.isnan(b) else b]
