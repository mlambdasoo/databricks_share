"""데이터 처리 skill 도구: 작업 데이터(공통 데이터 처리) 정하기·보기 도구(prepare_data)를 등록하고 처리한다.

용도:
- 대화에서 바꾼 작업 데이터 설정(cfg)을 기존 설정과 합치고, 공통 데이터 처리로 불러와 미리보기를 만든다.
- 처리 결과는 "work" 오브젝트로 대화에 보내고, 이후 분석은 이 작업 데이터로 실행된다.
목적: 계산은 engine.py(실행기 work.data가 불러 처리), 첫 제안은 proposal.py(테이블마다 한 번)에 두고,
이 파일은 도구 정의와 화면에 보낼 값 조립만 맡는다.
"""
from __future__ import annotations

from common import data as cd
from common import result_format as C
import sources as S
import work as W

NAME = "data-prep"
TOOLS = [
    {"type": "function", "function": {
        "name": "prepare_data",
        "description": "작업 데이터(공통 데이터 처리: 데이터 범위 → 전처리 → 변수 선택)를 정하거나 바꾸고, 처리한 데이터를 대화에 오브젝트로 보여준다. "
                       "바꿀 키만 넣는다(빈 cfg = 지금 작업 데이터 보기). 이후 분석은 이 작업 데이터로 실행된다.",
        "parameters": {"type": "object", "properties": {
            "cfg": {"type": "object", "description": "바꿀 키만 (skill '데이터 처리'의 키: source, filters, date_filter, normal_range, normal_by_col, na_ratio_max, "
                                                     "min_unique, categorical, impute, impute_by_col, knn_k, impute_constant, var_exclude, var_roles, exclude_result_like)"}},
            "required": ["cfg"]}}},
]
LABELS = {"prepare_data": "작업 데이터 준비"}


def handle(name: str, args: dict, ctx) -> dict:
    """prepare_data 호출을 처리한다: 바뀐 설정을 합쳐 작업 데이터를 만들고, 대화에 미리보기를 보낸다.

    date_filter에 col이 없으면 테이블 기본 날짜 컬럼을 넣는다. 처리 결과의 채운 칸은 강조해서 보여준다.
    입력: name — 도구 이름(prepare_data만 허용), args — {"cfg": 바꿀 키만 담은 dict}(빈 dict면 지금 작업 데이터를 보여 준다),
          ctx — 대화 컨텍스트(source · work · set_work · backend · progress · emit · unit · source_name)
    반환: {"text": 모델에게 줄 요약 문장(작업 데이터 id, 범위, 행 수, 채운 결측 칸, 변수 수, 처리 기록, 변수별 방법)}
    부작용: ctx.set_work로 작업 설정을 저장하고, ctx.emit으로 "work" 오브젝트를 보내며, 진행 상태를 표시한다.
            필터 값이 데이터와 맞지 않으면 PipelineError(filter_problems 포함)를 낸다.
    """
    if name != "prepare_data":
        raise cd.PipelineError(f"알 수 없는 도구: {name}")
    src = ctx.source()
    new = W.merged(ctx.work(), args.get("cfg") or {})
    d = S.describe(src, ctx.backend())
    if isinstance(new.get("date_filter"), dict) and not new["date_filter"].get("col"):
        new["date_filter"] = {**new["date_filter"], "col": d["guess"]["date_col"]}
    full = {**{k: v for k, v in d["guess"].items() if k in ("id_col", "date_col") and v}, "source": src,
            "spec_table": d.get("spec_table"), **{k: new[k] for k in W.KEYS if k in new}}
    ctx.progress("범위로 불러와 전처리하는 중")
    p = W.data(full, ctx.backend(), impute=True)
    if p["problems"]:
        raise cd.PipelineError("필터 값이 데이터와 일치하지 않습니다.", {"filter_problems": p["problems"]})
    ctx.set_work({k: new[k] for k in W.KEYS if k in new})
    unit = ctx.unit()
    pv = W.preview(p, unit)
    wid = cd.run_id("w_")
    statuses: dict = {}
    for x in p["pool"]:
        if x["status"]:
            statuses[x["status"]] = statuses.get(x["status"], 0) + 1
    applied = C.applied_scope(full, p["smap"], ctx.source_name(full)) + [
        {"label": "정상범위 밖 값", "value": cd.RANGE_LABELS.get(full.get("normal_range", "nan"), full.get("normal_range"))},
        {"label": "결측 대치", "value": ", ".join(f"{x['label']} {cd.IMPUTE_LABELS.get(x['method'], x['method']) if x['method'] != 'value' else x['value']}"
                                                  for x in p["plan"]) or "채울 결측 없음"},
        {"label": "변수 선택", "value": f"{len(p['selected'])}개 사용" + "".join(f" · {why} {n}개" for why, n in statuses.items())}]
    plan = [{"label": x["label"], "missing": f"{x['ratio']:.1%}", "method": cd.IMPUTE_LABELS.get(x["method"], x["method"]) if x["method"] != "value" else f"값 {x['value']}",
             "reason": x["reason"]} for x in p["plan"]]
    ctx.emit({"type": "work", "data": {"id": wid, "title": "처리한 데이터", "subtitle": f"{p['filters_text']} · {p['n_rows']:,}{unit}",
                                       "applied": applied, "log": [e["detail"] for e in p["log"]], "plan": plan, **pv}})
    return {"text": f"작업 데이터 `{wid}`: {p['filters_text']} · {p['n_rows']:,}{unit}, 채운 결측 {pv['n_filled']}칸, 변수 {len(p['selected'])}개 — 대화에 오브젝트로 표시됨(채운 칸 강조). "
                    "이후 분석은 이 작업 데이터로 실행된다. 원본 조회는 원본 기준이라 처리가 반영되지 않는다.\n"
                    + "\n".join(f"- {e['detail']}" for e in p["log"])
                    + ("\n- 변수별 방법: " + "; ".join(f"{x['label']} {x['method']}({x['reason']})" for x in plan) if plan else "")}
