"""데이터 처리 skill의 계산: 공통 데이터 처리(범위 → 전처리 → 변수 선택). 정해진 코드로 계산한다.

용도:
- 데이터 범위(필터·기간)로 불러온 데이터를 전처리하고, 분석에 쓸 변수 묶음을 고른다.
- 결과 df와 처리 기록(log), 변수 후보(pool), 사용 변수(selected)를 돌려준다.
목적: 실행기(work.data)가 이 함수로 처리한 데이터를 만들어 두고, 분석 skill은 그 결과를 받아 계산만 한다(이 함수를 직접 부르지 않는다).
규칙 하나하나(문자 숫자 변환·정상범위·결측 비율·값 종류·결측 대치)는 common/data.py에 있다.
역할·정상범위의 시작값은 첫 제안(proposal.py)이고, 대화에서 고친 값(cfg normal_by_col · var_roles)이 그 위에 덮인다.
"""
from __future__ import annotations

import pandas as pd

from common.data import (apply_impute, bounds_of, cfg_lines, impute_entry, impute_methods, is_categorical, is_datetime, is_num, label, load,
                         load_spec, normal_range, normalize_common, out_of, roles, spec_map, string_numeric)

COMMON_DEFAULTS = {"filters": {}, "date_filter": None, "normal_range": "nan", "normal_by_col": {}, "na_ratio_max": 0.3, "min_unique": 2,
                   "categorical": "exclude", "impute": "auto", "impute_by_col": {}, "knn_k": 5, "impute_constant": 0.0,
                   "var_exclude": [], "var_roles": {}, "exclude_result_like": True}
MAX_CATEGORIES = 20


def process(cfg: dict, backend, impute: bool = False, df: pd.DataFrame | None = None) -> dict:
    """공통 데이터 처리: 범위로 불러온 뒤(df를 주면 그 데이터로) 세 단계를 거친다.

    ① 전처리 — 문자로 저장된 숫자 변환 → 정상범위 밖 값 → 결측 비율 → 값 종류 → 범주형
       (목표 지표 후보는 값만 정리하고 빼지 않는다)
    ② 변수 선택 — 결과 뒤 값(역할)과 직접 뺀 변수(var_exclude)를 뺀 나머지가 분석에 쓸 변수 묶음(selected)
    ③ impute면 고른 영향 요인의 결측을 변수마다 채운다(분석 엔진은 자기 행이 정해진 뒤 직접 채운다)

    입력: cfg — 설정 dict(source, filters, date_filter, normal_range 등 COMMON_DEFAULTS 키),
          backend — 데이터 어댑터, impute — True면 결측을 실제로 채운다(False면 계획과 기록만),
          df — 이미 불러온 데이터(없으면 load로 읽는다)
    반환: dict — df(정리된 데이터, 범위 컬럼과 변수 후보 포함. pool의 status가 None인 변수만 사용),
          filled(채운 칸 표식), log(처리 기록 list), plan(결측 대치 계획), pool(변수 후보 + status · missing),
          selected(사용 변수), n_rows, filters_text, smap, cfg(기본값을 채운 설정), problems(필터 값 불일치).
          부작용: 없음(cfg와 입력 df는 바꾸지 않는다).
    """
    full = {**COMMON_DEFAULTS, **cfg, "filters": dict(cfg.get("filters") or {})}
    full["var_exclude"] = list(full.get("var_exclude") or [])
    normalize_common(full)
    problems = {}
    if df is None:
        df, problems = load(full, backend)
    smap = spec_map(load_spec(full, backend))
    pool = variable_pool(df, full, smap)
    role = {p["col"]: p["role"] for p in pool}
    log = []
    X, entry = string_numeric(df[[p["col"] for p in pool]], 0.8, smap)
    if entry:
        log.append(entry)
    mode = full.get("normal_range", "nan")
    if mode != "drop_row":  # 범위 밖 값 → 결측(nan) 또는 그대로(off). 행 제외(drop_row)는 변수를 고른 뒤
        X, _bad, _hits, entry = normal_range(X, mode, full.get("normal_by_col") or {}, smap)
        if entry:
            log.append(entry)
    status = {c: None for c in X.columns}       # None = 사용, 아니면 빠진 이유
    xs = [c for c in X.columns if role[c] != "y"]  # 영향 요인 쪽(목표 지표 후보는 결측·값 종류로 빼지 않는다)
    side, entry = na_filter(X[xs], float(full.get("na_ratio_max", 0.3)), smap)
    if entry:
        log.append(entry)
        status.update({c: "결측 비율" for c in entry["columns"]})
    side, entry = unique_filter(side, int(full.get("min_unique", 2)), MAX_CATEGORIES, smap)
    if entry:
        log.append(entry)
        status.update({c: "값 종류" for c in entry["columns"]})
    cats = [c for c in side.columns if is_categorical(side[c])]
    if cats and full.get("categorical", "exclude") == "exclude":
        log.append({"step": "categorical", "columns": cats, "detail": f"범주형 {len(cats)}개 제외: " + ", ".join(label(c, smap) for c in cats)})
        status.update({c: "범주형" for c in cats})
    for c in X.columns:
        if status[c] is None and role[c] == "result" and full.get("exclude_result_like", True) is not False:
            status[c] = "결과 뒤 값"
        if status[c] is None and c in full["var_exclude"]:
            status[c] = "직접 뺌"
    selected = [c for c in X.columns if status[c] is None]
    xsel = [c for c in selected if role[c] != "y"]
    if mode == "drop_row":  # 분석에 쓰는 영향 요인 중 범위 밖 값이 있는 행
        rows = out_of_any(X[xsel], smap, full.get("normal_by_col") or {}) if xsel else pd.Series(False, index=X.index)
        X, df = X[~rows], df.loc[~rows]
        if rows.any():
            log.append({"step": "normal_range", "detail": f"범위 밖 값이 있는 {int(rows.sum())}행 제외", "count": int(rows.sum())})
    num = [c for c in xsel if is_num(X[c])]
    filled = X[num].isna()
    methods, plan = impute_methods(X[num], full, smap)
    filled[[c for c, m in methods.items() if m == "none"]] = False  # 채우지 않는 변수는 결측 그대로(채운 칸 아님)
    n_missing = int(filled.values.sum())
    if n_missing and impute:
        X[num] = apply_impute(X[num], methods, full)
    if methods:
        log.append(impute_entry(methods, full, smap, n_missing, impute))
    out = df.copy()
    for c in X.columns:
        out[c] = X[c]
    for p in pool:
        p["status"] = status[p["col"]]
        p["missing"] = round(float(X[p["col"]].isna().mean()), 4) if len(X) else 0.0
    return {"df": out.reset_index(drop=True), "filled": filled.reset_index(drop=True), "log": log, "plan": plan, "pool": pool,
            "selected": selected, "n_rows": int(len(out)), "filters_text": cfg_lines(full, smap)[1], "smap": smap, "cfg": full,
            "problems": problems}


# ----------------------------------------------------------------------------- 전처리 · 변수 선택 단계(이 skill만 쓴다)

def out_of_any(X: pd.DataFrame, smap, overrides: dict | None = None) -> pd.Series:
    """행마다 정상범위 밖 값이 하나라도 있는지 본다(수치 컬럼만).

    입력: X — 변수 DataFrame, smap — {컬럼: 컬럼 정보 행}, overrides — normal_by_col dict 또는 None
    반환: 행 단위 bool Series
    """
    bad = pd.Series(False, index=X.index)
    for c in X.columns:
        rng = bounds_of(c, smap, overrides)
        if rng is not None and is_num(X[c]):
            bad |= out_of(X[c], rng)
    return bad


def na_filter(X: pd.DataFrame, max_ratio: float, smap) -> tuple[pd.DataFrame, dict | None]:
    """결측 비율이 max_ratio를 넘는 변수를 뺀다.

    입력: X — 변수 DataFrame, max_ratio — 허용 결측 비율(예: 0.3), smap — {컬럼: 컬럼 정보 행}
    반환: (남은 X, 처리 기록 항목 또는 None — 뺀 변수가 없으면 None)
    """
    na = X.isna().mean()
    drop = na[na > max_ratio].index.tolist()
    if not drop:
        return X, None
    return X.drop(columns=drop), {"step": "na_ratio", "columns": drop,
                                  "detail": f"결측 {max_ratio:.0%} 초과 {len(drop)}개 제외: " + ", ".join(f"{label(c, smap)} {na[c]:.0%}" for c in drop)}


def unique_filter(X: pd.DataFrame, min_unique: int, max_categories: int, smap) -> tuple[pd.DataFrame, dict | None]:
    """값 종류로 거른다. 수치·불리언은 고유값이 min_unique 미만이면 뺀다. 범주형은 2종류 미만이거나 max_categories를 넘으면 뺀다.

    입력: X — 변수 DataFrame, min_unique — 수치 최소 고유값 수, max_categories — 범주 최대 종류 수, smap — {컬럼: 컬럼 정보 행}
    반환: (남은 X, 처리 기록 항목 또는 None — 뺀 변수가 없으면 None)
    """
    drop = []
    for c in X.columns:
        nu = X[c].nunique(dropna=True)
        if is_num(X[c]) or pd.api.types.is_bool_dtype(X[c]):
            if nu < min_unique:
                drop.append((c, f"값 {nu}종류"))
        elif nu < 2 or nu > max_categories:
            drop.append((c, f"범주 {nu}개"))
    if not drop:
        return X, None
    return X.drop(columns=[c for c, _ in drop]), {"step": "unique", "columns": [c for c, _ in drop],
                                                  "detail": f"값 종류 기준 {len(drop)}개 제외: " + ", ".join(f"{label(c, smap)} {why}" for c, why in drop)}


def variable_pool(df: pd.DataFrame, cfg: dict, smap) -> list:
    """분석에 쓸 수 있는 변수 후보 목록을 만든다.

    후보 = 역할이 영향 요인·목표 지표 후보·결과 뒤 값이거나 역할을 모르는 값 컬럼.
    식별자·날짜·범위 구분·메모, 그리고 필터·기간 조건 컬럼은 변수가 아니다(범위를 정하는 데 쓴다).
    입력: df — 데이터, cfg — 설정 dict(filters, date_filter, id_col, var_roles), smap — {컬럼: 컬럼 정보 행}
    반환: [{col, label, role, category}] list
    """
    fixed = set(cfg.get("filters") or {}) | ({cfg["date_filter"]["col"]} if cfg.get("date_filter") else set())
    rl = roles(smap, cfg)
    out = []
    for c in df.columns:
        r = smap.get(c)
        role = rl.get(c)
        if c in fixed or c == cfg.get("id_col") or role in ("id", "date", "dimension", "text") or is_datetime(df[c]):
            continue
        cat = getattr(r, "category", None) if r is not None else None
        out.append({"col": c, "label": label(c, smap), "role": role, "category": cat if isinstance(cat, str) and cat else None})
    return out
