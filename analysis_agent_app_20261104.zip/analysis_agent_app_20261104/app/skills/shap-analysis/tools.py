"""shap-analysis skill의 도구 모듈: LLM에 보이는 도구 명세, 도구 실행, 화면 데이터(공통 형식)를 담는다. 진행·제안·해석·다음 단계는 SKILL.md(LLM)가 맡는다.

용도:
- TOOLS: LLM에 보이는 도구 3개(shap_preview · shap_run · shap_explain)의 명세. description 문자열은 LLM에 그대로 전달되므로 수정하지 않는다.
- handle: 도구 호출을 받아 engine.py(sp)를 실행하고 결과를 대화·결과 패널에 보낸다.
- settings_view · ui_result · ui_explain · explain_md: 엔진 결과를 화면 양식(layout.yaml)과 LLM 요약 형식으로 바꾼다.

목적:
- 계산(engine.py)과 화면·LLM 사이를 이 파일이 잇는다. engine.py는 파일 경로로 따로 불러와 sp로 쓴다.
- 실행기가 이 skill에 맞춰 동작하는 차이는 여기서 선언한다(FROM_RESULT_TOOLS · NULLABLE_KEYS). 앱 코드는 이 skill을 모르므로 폴더를 지우면 앱에서 빠진다.
"""
from __future__ import annotations

import importlib.util
import json
import os

import numpy as np
import pandas as pd

from common import layout as L
from common import result_format as C
from common import data as cd
import work as W

HERE = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location("skill_shap_engine", os.path.join(HERE, "engine.py"))
sp = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(sp)

NAME = "shap-analysis"
ENGINE_DEFAULTS = sp.DEFAULTS
SETTINGS = True  # 화면의 세부 설정 시트(단계 ①~⑥) 제공
RUN_TOOL = "shap_run"  # 설정 시트·[제안대로 실행]이 부르는 실행 도구
FROM_RESULT_TOOLS = ("shap_explain",)  # 이전 결과에서 일하는 도구(테이블을 정하지 않아도 되고, 작업 데이터를 바꾸지 않는다)
NULLABLE_KEYS = ("x_include",)  # null로 보내면 해제인 키


TOOLS = [
    {"type": "function", "function": {
        "name": "shap_preview",
        "description": "SHAP 분석 제안: 이 cfg로 데이터를 진단하고(행 수, 필터 값 불일치, 목표 지표 후보, 전처리 영향) 대화에 분석 설정 오브젝트(제안 카드)를 띄운다.",
        "parameters": {"type": "object", "properties": {
            "cfg": {"type": "object", "description": "제안할 분석 설정 dict (skill 설정 키). 요청한 조건 + 내가 제안하는 설정"}},
            "required": ["cfg"]}}},
    {"type": "function", "function": {
        "name": "shap_run",
        "description": "SHAP 분석 실행. 요인 표와 차트는 결과 패널에 표시된다.",
        "parameters": {"type": "object", "properties": {
            "cfg": {"type": "object", "description": "분석 설정 dict"}}, "required": ["cfg"]}}},
]
TOOLS.append({"type": "function", "function": {
    "name": "shap_explain",
    "description": "행(관측 단위) 하나의 결과를 SHAP 기여로 설명한다: 그 행의 모델 예측이 평균 예측에서 어떤 변수로 얼마나 움직였는지(변수별 기여), "
                   "그 변수 값이 분석 범위에서 평소 대비 어느 위치인지(중앙값·백분위), 실제값과 예측의 차이. "
                   "run_id가 SHAP 결과면 그 모델을 그대로 쓰고, 다른 분석의 결과면 그 범위(필터·기간·그룹)로 SHAP을 새로 실행한 뒤 설명한다. "
                   "run_id가 없으면 이 대화에서 그 행을 포함한 가장 최근 SHAP 결과를 쓰고, 없으면 cfg 범위로 새로 실행한다.",
    "parameters": {"type": "object", "properties": {
        "row_id": {"type": "string", "description": "설명할 행의 식별값(데이터의 식별자 컬럼 값)"},
        "run_id": {"type": "string", "description": "그 행을 고른 결과(생략 가능)"},
        "y": {"type": "string", "description": "설명할 지표 컬럼(생략 시 그 결과의 지표)"},
        "cfg": {"type": "object", "description": "새로 실행해야 할 때의 범위 설정(생략 가능)"},
        "top": {"type": "integer", "description": "보여줄 변수 수(기본 8)"}},
        "required": ["row_id"]}}})
LAYOUT = L.load(__file__)  # 화면 양식(layout.yaml): 결과·설정 패널의 블록 구성
LABELS = {"shap_preview": "데이터 진단과 설정 제안", "shap_run": "모델 학습과 SHAP 계산",
          "shap_explain": "한 건 설명 (SHAP 기여)"}


# ----------------------------------------------------------------------------- 분석 설정 패널 (진단 + 공통 단계)

def _num(v):
    return f"{v:,.4g}"


def settings_view(prof: dict, ctx, rec_items=None, requested=(), from_result=False, run_tool="shap_run") -> dict:
    """분석 설정 패널을 만든다: 진단 숫자 + 공통 단계(데이터 범위 → 전처리 → 변수 선택, 칸으로 표시). SHAP 설정은 패널에 없고 LLM이 정한다. 칸을 바꿀 때마다 화면이 cfg를 다시 보내면 이 함수로 패널을 새로 만든다.

    입력: prof — engine.profile() 결과, ctx — 실행 문맥, rec_items — 제안에서 바뀐 항목 list(key·changed 포함, 없으면 None), requested — 요청에서 사용자가 직접 정한 키 목록, from_result — 결과 화면의 [설정 수정]에서 왔는지, run_tool — 실행 버튼이 부를 도구 이름
    반환: 설정 payload dict(C.settings_payload). 필터 불일치·진단 오류·Y 없음·분석 행 30건 미만이면 can_run=False와 blockers 사유를 담는다
    """
    cfg = {k: v for k, v in prof["cfg"].items() if k != "output_dir"}
    p = prof.get("prep") or {}
    smap = _smap({"cfg": cfg}, ctx)
    u = cd.row_unit(cfg, smap)
    asked = set(requested or [])
    proposed = {it["key"] for it in (rec_items or []) if it.get("changed") and it.get("key")}
    problems = prof.get("filter_problems") or {}
    n_rows = p.get("n_rows", prof["n_after_filter"])

    steps, _w = W.steps(cfg, ctx.backend(), ctx.profile(cfg), asked=asked, proposed=proposed, from_result=from_result, unit=u)

    ys = p.get("y_series_stats") or {}
    n2 = f"평균 {_num(ys['mean'])}, 범위 {_num(ys['min'])} ~ {_num(ys['max'])}" if "mean" in ys else \
         f"{p['classes']['positive']} {ys.get('n_positive')}건, 나머지 {ys.get('n_negative')}건" if ys and p.get("classes") else None

    blockers = []
    if problems:
        blockers.append("데이터 범위의 값을 먼저 고쳐 주세요")
    if prof.get("error"):
        blockers.append(prof["error"].get("message", "진단 오류"))
    if not cfg.get("y"):
        blockers.append("목표 지표를 알려 주세요")
    elif p and n_rows < 30:
        blockers.append(f"분석하려면 30{u} 이상이 필요합니다(지금 {n_rows}{u})")
    data = {"title": "SHAP 요인 분석 설정",
            "filters_text": prof["filters_text"], "unit": u, "n_rows": n_rows, "n_variables": p.get("n_variables", 0),
            "y_label_or_dash": prof.get("y_label") or "-", "y_note": n2,
            "missing_pct": f"{p['missing_cell_ratio'] * 100:.1f}" if p.get("missing_cell_ratio") is not None else None,
            "warnings": [{"type": "text", "tone": "warn", "text": w} for w in p.get("warnings", [])]}
    view = L.render(LAYOUT["settings"], data)
    return C.settings_payload(NAME, run_tool, cfg, view["title"], view["subtitle"], view["metrics"], steps, view["sections"],
                              can_run=not blockers, blockers=blockers, from_result=from_result)


def settings(cfg: dict, ctx, from_result: bool = False) -> dict:
    """설정 패널을 새 cfg로 다시 만든다. cfg를 완성하고 데이터를 불러 진단(profile)을 다시 계산한 뒤 settings_view로 그린다.

    입력: cfg — 화면이 보낸 설정 dict, ctx — 실행 문맥, from_result — 결과 화면의 [설정 수정]에서 왔는지
    반환: 설정 payload dict. 부작용: 데이터 조회(ctx.data)
    """
    full = ctx.cfg(cfg)
    prof = ctx.compute(sp, "profile", full, ctx.data(full))
    return settings_view(prof, ctx, from_result=from_result)


# ----------------------------------------------------------------------------- 결과 화면 (공통 형식)

DIR = {"증가": ("높을수록 증가", "up"), "감소": ("높을수록 감소", "down"), "비단조": ("구간마다 다름", "mixed")}
def _smap(res, ctx):
    return cd.spec_map(cd.load_spec(res["cfg"], ctx.backend()))


def round_frame(res: dict, r_idx: int, smap) -> tuple[pd.DataFrame, list]:
    """회차 하나의 행 단위 표를 만든다: 식별자·날짜·범주 차원(값 50개 이하 문자열) + Y + 예측 + X 값 + 변수별 SHAP 기여(shap:<컬럼>). 분류면 __y(1/0)와 __group(두 그룹 이름) 열을 더한다. 분석에서 뺀 숫자 컬럼은 값의 절반 이상이 숫자일 때만 원값으로 넣는다.

    입력: res — 결과 dict(_mem 필요), r_idx — 회차 번호(0부터), smap — 컬럼 정의 맵
    반환: (DataFrame, 필드 정의 list(C.fields_of 결과))
    """
    mem = res["_mem"]
    rd = mem["rounds"][r_idx]
    X, vals, base = rd["X"].reset_index(drop=True), rd["vals"], rd["base"]
    rows = mem["rows"]
    cfg = res["cfg"]
    f = pd.DataFrame(index=X.index)
    labels = {}
    # 식별자 + 날짜 + 범주 차원(값 50개 이하 문자열) — 어떤 테이블이든 차트의 x·색 구분으로 쓸 수 있게
    keep = [cfg.get("id_col")] + [c for c in rows.columns if c not in X.columns and c != cfg["y"] and
                                  (cd.is_datetime(rows[c]) or (not cd.is_num(rows[c]) and rows[c].nunique() <= 50))]
    for c in dict.fromkeys(k for k in keep if k and k in rows.columns):
        f[c] = pd.to_datetime(rows[c]).values if cd.is_datetime(rows[c]) else rows[c].astype(str).values
    if cfg["y"] in rows.columns:
        f[cfg["y"]] = pd.to_numeric(rows[cfg["y"]], errors="coerce").values if res["task"] == "regression" or cfg.get("y_quantile") \
            else rows[cfg["y"]].astype(str).values
    if res["task"] == "classification":
        f["__y"] = mem["y"].values
        labels["__y"] = f"{res['classes']['positive']} 여부(1/0)"
        nm = res["classes"].get("names") or [res["classes"]["positive"], res["classes"]["negative"]]
        f["__group"] = np.where(np.asarray(mem["y"].values) == 1, str(nm[0]), str(nm[1]))  # 두 그룹 이름(표·상자그림의 그룹 축)
        labels["__group"] = "구분"
    f["__pred"] = base + vals.sum(axis=1)
    labels["__pred"] = "모델 예측" if res["task"] == "regression" else "모델 예측(로그 오즈)"
    for j, c in enumerate(X.columns):
        f[c] = X[c].values
        f[f"shap:{c}"] = vals[:, j]
        labels[f"shap:{c}"] = f"기여: {cd.label(c, smap)}"
    for c in rows.columns:  # 분석에서 뺀 숫자 컬럼(결과성·다른 Y 등)도 차트용으로 (원값)
        if c not in f.columns and c not in X.columns:
            v = pd.to_numeric(rows[c], errors="coerce")
            if v.notna().mean() >= 0.5:
                f[c] = v.values
    return f, C.fields_of(f, smap, labels)


def _class_title(res) -> str:
    """분류 결과 제목: 두 그룹 이름(Golden 대 Worst · 오염 대 정상). 이름을 주지 않은 값(1/0 등)이면 지표 이름을 앞에."""
    c = res["classes"]
    pos, neg = (c.get("names") or [c["positive"], c["negative"]])[:2]
    return f"{pos} 대 {neg}" if c.get("named") else f"{res['y_label']} {pos} 대 {neg}"


def _round_view(res, r_idx, run_id, smap, prefix="", prev=None):
    """회차 하나의 화면 보기 데이터를 만든다(layout.yaml의 result.run.views가 그린다): 변수 순위 표(직전 결과 대비 순위 변화 포함), 제외된 변수, 의존성·구간별 차트 대상, 대표 사례 3건(예측 최저·중앙·최고)의 기여 데이터셋.

    입력: res — 결과 dict, r_idx — 회차 인덱스(0부터), run_id — 결과 id(본문에서 쓰지 않음), smap — 컬럼 정의 맵, prefix — 데이터셋 이름 접두어(차트 편집 결과용), prev — 직전 결과(마지막 회차 순위·CV 비교용, 없으면 None)
    반환: (보기 dict, 행 데이터셋 이름, 대표 사례 데이터셋 dict)
    """
    rd = res["rounds"][r_idx]
    prev_rank = {t["feature"]: t["rank"] for t in prev["rounds"][-1]["top"]} if prev else {}
    cfg = res["cfg"]
    ds = f"{prefix}rows_r{rd['round']}"
    yfield = "__y" if res["task"] == "classification" else cfg["y"]
    top = rd["top"]
    rank_rows = []
    for t in top:
        text, tone = DIR[t["direction"]]
        if "=" in t["feature"] and t["direction"] != "비단조":
            text = "해당하면 증가" if t["direction"] == "증가" else "해당하면 감소"
        pr = prev_rank.get(t["feature"]) if prev else None
        delta = None if not prev else ("new" if pr is None else (pr - t["rank"]))
        rank_rows.append({"rank": t["rank"], "label": t["label"], "share": t["share"], "dir": text, "dir_tone": tone, "delta": delta,
                          "sub": f"기여가 가장 큰 구간 {t['best_range']}, 가장 작은 구간 {t['worst_range']}" if t.get("best_range") else None})
    excluded = [next((x["label"] for r in res["rounds"] for x in r["top"] if x["feature"] == f), cd.label(f, smap))
                for f in rd["excluded_before"]]
    feats = [t["feature"] for t in top]
    X = res["_mem"]["rounds"][r_idx]["X"]
    dep = [{**t, "chart": "box" if X[t["feature"]].nunique() <= 2 else "scatter"} for t in top[: cfg["dependence_top"]]]
    ybin = [t for t in top if "=" not in t["feature"] and X[t["feature"]].nunique() > 5][:6]
    mem = res["_mem"]["rounds"][r_idx]
    pred = mem["base"] + mem["vals"].sum(axis=1)
    order = np.argsort(pred)
    ids = res["_mem"]["rows"][cfg["id_col"]].astype(str).tolist() if cfg.get("id_col") else None
    datasets, cases = {}, []
    for key, name, i in (("low", "예측 최저", order[0]), ("mid", "예측 중앙", order[len(order) // 2]), ("high", "예측 최고", order[-1])):
        v = mem["vals"][i]
        top8 = np.argsort(-np.abs(v))[:8]
        dname = f"{prefix}case_{key}_r{rd['round']}"
        datasets[dname] = {"fields": [{"key": "label", "label": "변수", "type": "cat"}, {"key": "value", "label": "기여", "type": "num"}],
                           "rows": [{"label": cd.label(X.columns[j], smap), "value": float(round(v[j], 5))} for j in top8],
                           "editable": False}
        cases.append({"key": key, "name": name, "who": ids[i] if ids else f"행 {i}", "pred": float(pred[i]), "dataset": dname})
    cv = rd["cv"]
    pcv = prev["rounds"][-1]["cv"] if prev else None
    multi = len(res["rounds"]) > 1
    view = {"round": rd["round"], "label": f"{rd['round']}회차" if multi else "결과", "sub": f"변수 {rd['n_features']}개" if multi else None,
            "n_variables": rd.get("n_variables", rd["n_features"]), "cv": cv, "cv_tone": C.grade_tone(cv["grade"]),
            "prev_text": f" · 직전 {pcv['mean']:.3f}" if pcv else "", "excluded_text": ", ".join(excluded), "ranking": rank_rows,
            "ds": ds, "yfield": yfield, "dist_fields": feats[:12], "dep": dep, "ybin": ybin, "cases": cases, "corr_fields": feats[:10] + [yfield]}
    return view, ds, datasets


REASON_SHORT = {"결과성 변수(누수 위험)": "결과 뒤에 정해지는 값", "다른 결과(Y) 변수": "다른 결과 지표", "식별·필터 차원": "범위 구분·날짜",
                "필터 조건 컬럼": "필터 조건", "날짜/시각": "날짜", "자유 텍스트": "메모", "식별자": "식별자", "선택 분류 외": "분류 제한"}


def _impute_text(res: dict, smap) -> str:
    """남은 결측을 변수마다 어떻게 채웠는지(엔진 로그의 변수별 방법)."""
    by = next((e.get("by_col") for e in res["preprocess_log"] if e.get("step") == "impute"), None) or {}
    if not by:
        return "남은 결측 없음"
    items = [f"{cd.label(c, smap)} {m}" for c, m in by.items()]
    return "남은 결측 변수별 처리: " + ", ".join(items[:6]) + (f" 외 {len(items) - 6}개" if len(items) > 6 else "")


def _request_parts(user_cfg: dict, merged: dict, smap, extra: dict | None = None, settings_first=False, with_y=True) -> list:
    """사용자가 요청에서 바꾼 설정을 사람이 읽는 말로 요약한다. 범위(filters · 기간)와 지표는 merged에서 가져온다.

    입력: user_cfg — 사용자가 요청에서 직접 준 설정(없으면 빈 dict), merged — 기본값이 합쳐진 설정,
          smap — {컬럼: 컬럼 정보 행}, extra — 덧붙일 문장 dict(값만 쓴다), with_y — 지표(y)를 범위 요약에 넣을지,
          settings_first — False면 범위가 앞, True면 처리 방법 항목이 앞이고 범위는 뒤에 온다
    반환: 요약 문장 list
    """
    u, out = user_cfg or {}, []
    scope = []
    for c, v in (merged.get("filters") or {}).items():
        scope.append("/".join(map(str, v if isinstance(v, list) else [v])))
    p = C.period_text(merged.get("date_filter"))
    if p:
        scope.append(p)
    if with_y and merged.get("y"):
        scope.append(f"지표 {cd.label(merged['y'], smap)}")
    if not settings_first:
        out += scope
    if u.get("y_quantile"):
        q = u["y_quantile"]
        out.append(f"상·하위 {float(q.get('top', 0.1)):.0%} 자동 선정")
    if u.get("y_positive"):
        out.append(f"{u['y_positive']} 대 {u.get('y_negative') or '나머지'}")
    if "impute" in u:
        out.append(f"결측 {cd.IMPUTE_LABELS.get(u['impute'], u['impute'])}")
    if u.get("impute_by_col"):
        out.append("결측 개별 " + ", ".join(f"{cd.label(c, smap)} {cd.IMPUTE_LABELS.get(m, m) if isinstance(m, str) else f'값 {m:g}'}"
                                           for c, m in list(u["impute_by_col"].items())[:3]))
    if u.get("categorical") == "onehot":
        out.append("범주형 포함")
    if "model" in u:
        out.append(sp.MODEL_LABELS.get(u["model"], u["model"]))
    if "cv_folds" in u:
        out.append(f"{u['cv_folds']}겹 교차검증")
    if "top_n" in u:
        out.append(f"상위 {u['top_n']}개")
    if u.get("x_exclude"):
        out.append("제외 " + ", ".join(cd.label(c, smap) for c in u["x_exclude"][:3]) + (" 등" if len(u["x_exclude"]) > 3 else ""))
    if u.get("exclude_result_like") is False:
        out.append("결과성 변수 포함")
    if u.get("auto_rounds"):
        out.append("지배 변수 자동 반복")
    if u.get("normal_range") == "drop_row":
        out.append("정상범위 밖 행 삭제")
    if "na_ratio_max" in u:
        out.append(cd.na_rule_text(u["na_ratio_max"]))
    for k, v in (extra or {}).items():
        out.append(v)
    return out + scope if settings_first else out


def applied(res: dict, ctx, smap) -> list:
    """결과 패널의 "적용된 설정" 항목 목록을 만든다. 순서는 데이터·필터 → 전처리 → 영향 요인(X) → 목표 지표(Y) → 모델 → 반복이다. 실제 적용된 값만 담는다.

    입력: res — 결과 dict, ctx — 실행 문맥(source_name 사용), smap — 컬럼 정의 맵
    반환: {label, value} dict list
    """
    cfg = res["cfg"]
    items = C.applied_scope(cfg, smap, ctx.source_name(cfg))
    conv = next((e.get("columns") for e in res["preprocess_log"] if e.get("step") == "string_numeric"), None) or []
    prep = ([f"문자로 저장된 숫자 변환({', '.join(cd.label(c, smap) for c in conv[:4])}{' 등' if len(conv) > 4 else ''})"] if conv else []) + [
            cd.na_rule_text(cfg["na_ratio_max"]), cd.unique_rule_text(cfg["min_unique"]),
            cd.RANGE_TEXT.get(cfg["normal_range"], cfg["normal_range"]), f"범주형 {cd.CAT_LABELS.get(cfg['categorical'], cfg['categorical'])}",
            _impute_text(res, smap)]
    items.append({"label": "전처리", "value": " · ".join(prep)})  # 고객 As-Is 용어(결측·정상범위·범주형) 그대로
    auto = next((e.get("by_reason") for e in res["preprocess_log"] if e.get("step") == "auto_exclude"), None) or {}
    x = [f"{res['rounds'][0].get('n_variables', res['rounds'][0]['n_features'])}개 사용"]  # 범주형은 값별 칸이 아니라 변수 하나로 센다
    if auto:
        x.append(f"자동 제외 {sum(len(v) for v in auto.values())}개(" + ", ".join(f"{REASON_SHORT.get(r, r)} {len(v)}" for r, v in auto.items() if v) + ")")
    if cfg.get("x_exclude"):
        x.append("직접 제외 " + ", ".join(cd.label(c, smap) for c in cfg["x_exclude"][:6]) + (" 등" if len(cfg["x_exclude"]) > 6 else ""))
    if cfg.get("x_categories"):
        x.append("분류 " + ", ".join(cfg["x_categories"]))
    items.append({"label": "영향 요인 후보", "value": " · ".join(x)})
    if res["task"] == "classification":
        neg = res["classes"].get("negative")
        y = f"{res['y_label']}: {res['classes']['positive']} 대 {'/'.join(neg) if isinstance(neg, list) else neg}"
    else:
        y = res["y_label"]
    if cfg.get("y_quantile"):
        q = cfg["y_quantile"]
        y = f"{cd.label(cfg['y'], smap)} 상위 {float(q.get('top', 0.1)):.0%} 대 하위 {float(q.get('bottom', 0.1)):.0%}"
    items.append({"label": "목표 지표", "value": y})
    items.append({"label": "모델", "value": f"{res['model']} · {cfg['cv_folds']}겹 교차검증"})
    if cfg.get("rounds", 1) > 1 and cfg.get("drop_top_per_round"):
        rep = f"상위 {cfg['drop_top_per_round']}개씩 빼며 {cfg['rounds']}회"
    elif cfg.get("auto_rounds"):
        rep = f"지배 변수가 있으면 빼고 다시(최대 {cfg['auto_rounds']}회), 실제 {len(res['rounds'])}회"
    else:
        rep = "1회"
    items.append({"label": "반복", "value": rep})
    return items


def ui_result(res: dict, ctx, prefix="") -> tuple[dict, dict]:
    """SHAP 결과를 화면 결과 dict로 바꾼다(구성은 layout.yaml의 result.run). 회차별 보기, 회차 비교표, 지배 변수 안내, 적용된 설정, 제목 범위를 담는다. 접두어가 없는 일반 결과일 때만 직전 결과(같은 Y·분류)와 비교해 순위 변화를 붙인다.

    입력: res — run() 결과, ctx — 실행 문맥(previous·source_name 등), prefix — 차트 편집 결과의 데이터셋 이름 접두어(빈 문자열이면 일반 결과)
    반환: (화면 결과 dict, 데이터셋 이름별 DataFrame dict). 부작용: ctx.previous 조회
    """
    smap = _smap(res, ctx)
    rounds, datasets, frames = [], {}, {}
    prev = None if prefix else ctx.previous(NAME, lambda p: p["y"] == res["y"] and p["task"] == res["task"] and p["run_id"] != res["run_id"])
    for i in range(len(res["rounds"])):
        view, ds, extra = _round_view(res, i, res["run_id"], smap, prefix, prev if i == len(res["rounds"]) - 1 else None)
        frame, fields = round_frame(res, i, smap)
        frames[ds.removeprefix(prefix)] = frame
        datasets[ds] = {"fields": fields, "url": f"/api/data/{res['run_id']}/{ds.removeprefix(prefix)}", "editable": True,
                        "id_field": res["cfg"].get("id_col")}
        datasets.update(extra)
        rounds.append(view)
    last = res["rounds"][-1]
    isclass = res["task"] == "classification"
    rc, rc_data = res.get("round_compare"), None
    if rc:
        cols = [{"key": "label", "label": "변수", "type": "text"}] + \
               [{"key": f"r{i + 1}", "label": f"{i + 1}회차", "type": "text"} for i in range(len(rc["cv"]))]
        rows = [{"label": "모델 설명력", **{f"r{i + 1}": f"{c['metric']} {c['mean']:.3f}" for i, c in enumerate(rc["cv"])}, "_strong": True}]
        for f in rc["features"]:
            rows.append({"label": f["label"], **{f"r{i + 1}": ("제외" if x == "제외" else "-" if x is None else f"{x['rank']}위 {x['share']:.0%}")
                                                 for i, x in enumerate(f["ranks"])}})
        rc_data = {"columns": cols, "rows": rows, "stop_text": f" · 자동 반복 종료: {res['stop_reason']}" if res.get("stop_reason") else ""}
    d = last["top"][0] if last["dominance"] else None
    data = {"is_class": isclass, "class_title": _class_title(res) if isclass else None, "y_label": res["y_label"],
            "filters_text": res["filters_text"], "n_rows": res["n_rows"], "unit": cd.row_unit(res["cfg"], smap), "model": res["model"],
            "dom": {**d, "label_ga": cd.josa(d["label"], "이가")} if d else None, "rc": rc_data, "rounds": rounds, "prefix": prefix}
    log = [{"label": sp.STEP_LABELS.get(e["step"], e["step"]), "detail": e["detail"]} for e in res["preprocess_log"]]
    cfg = {k: v for k, v in res["cfg"].items() if k != "output_dir"}
    ui = {"skill": NAME, "kind": "run", "run_id": res["run_id"], "pdf": True, "settings": True,
          **L.render(LAYOUT["result"]["run"], data),
          "log": log, "warnings": res["warnings"], "cfg": json.loads(json.dumps(cfg, default=str)), "datasets": datasets,
          "badge": f"{last['cv']['metric']} {last['cv']['mean']:.3f} {last['cv']['grade']}, 1위 {last['top'][0]['label'] if last['top'] else '-'}",
          "short": " · ".join(["SHAP"] + _request_parts({k: res["cfg"].get(k) for k in ("impute", "impute_by_col", "categorical", "model", "y_quantile", "auto_rounds", "x_exclude")
                                                           if res["cfg"].get(k) not in (None, [], {}, 0, "auto", "exclude", "xgboost")}, res["cfg"], smap,
                                                          settings_first=True, with_y=res["cfg"].get("y") != _default_y(ctx))[:5]),
          "compared_to": prev["run_id"] if prev and not prefix else None, "target_label": res["y_label"],
          "applied": applied(res, ctx, smap)}
    scope = [] if prefix else _request_parts({}, res["cfg"], smap, with_y=False)  # 카드 제목에 범위(조건 · 기간)
    if scope:
        ui["title"] = " · ".join(scope) + " · " + ui["title"]
    return ui, frames


def _default_y(ctx):
    try:
        return ctx.cfg({}).get("y")
    except Exception:  # noqa: BLE001
        return None


def llm_result_summary(res: dict) -> str:
    last = res["rounds"][-1]
    top = [{k: t.get(k) for k in ("rank", "feature", "label", "share", "direction", "best_range", "worst_range")}
           for t in last["top"][:10]]
    cfg = {k: v for k, v in res["cfg"].items() if k != "output_dir"}
    return (sp.result_md(res) + "\n\n```json\n" +
            json.dumps({"run_id": res["run_id"], "top_last_round": top, "dominance": last["dominance"], "cfg": cfg},
                       ensure_ascii=False, default=str) + "\n```\n(결과 패널에 표와 차트가 표시됨)")


# ----------------------------------------------------------------------------- 실행

def _lazy(cfg: dict, user_cfg: dict | None) -> dict:
    """화면 차트는 브라우저가 그리므로 PDF용 정적 차트는 PDF를 만들 때 만든다(사용자가 차트 목록을 정했으면 그대로)."""
    if "charts" not in (user_cfg or {}):
        cfg["charts"] = []
    return cfg


def handle(name: str, args: dict, ctx) -> dict:
    """도구 이름에 따라 실행을 나눈다. shap_preview는 진단 후 제안 카드를 띄우고, shap_run은 분석 후 결과 패널을 띄우고, shap_explain은 행 하나를 설명한다. 각 단계에서 ctx.emit으로 화면에 보낸다.

    입력: name — 도구 이름, args — LLM이 준 인자 dict(cfg·row_id 등), ctx — 실행 문맥(cfg·data·compute·emit·register 등)
    반환: {"text": LLM에 돌려줄 문자열} 이고, shap_run과 shap_explain은 "summarize": ("result", id)를 더한다. 알 수 없는 도구면 PipelineError. 부작용: 화면 이벤트 발송, 결과 등록, 미리보기 cfg 저장
    """
    if name == "shap_preview":
        cfg = ctx.cfg(args.get("cfg"))
        requested = list((args.get("cfg") or {}).keys())
        prof = ctx.compute(sp, "profile", cfg, ctx.data(cfg))
        view = settings_view(prof, ctx, None, requested)
        ctx.set_preview(NAME, view["cfg"])
        ctx.emit({"type": "proposal", "data": C.proposal(view, head="이렇게 분석해 볼게요")})
        out = sp.profile_md(prof) + "\n(대화에 제안 카드가 표시됨: [설정 열기] · [이대로 실행])"
        out += "\n\n```json\n" + json.dumps({"filter_problems": prof["filter_problems"], "y_candidates": prof["y_candidates"],
                                             "error": prof.get("error"), "cfg": view["cfg"]}, ensure_ascii=False, default=str) + "\n```"
        return {"text": out}
    if name == "shap_run":
        full = _lazy(ctx.cfg(args.get("cfg")), args.get("cfg"))
        res = ctx.compute(sp, "run", full, ctx.data(full), progress=True)
        ui, frames = ui_result(res, ctx)
        ctx.register(res["run_id"], NAME, res, ui, frames)
        ctx.emit({"type": "result", "data": ui})
        return {"text": llm_result_summary(res), "summarize": ("result", res["run_id"])}
    if name == "shap_explain":
        return _explain(args, ctx)
    raise cd.PipelineError(f"알 수 없는 도구: {name}")


# ----------------------------------------------------------------------------- 행 하나 설명 (실제 모델의 SHAP 값으로)

def _ids(res):
    col = res["cfg"].get("id_col")
    return res["_mem"]["rows"][col].astype(str).tolist() if col and col in res["_mem"]["rows"].columns else []


def _shap_run_with(ctx, row_id, y=None):
    for st in reversed(list(ctx.conv.runs.values())):
        r = st["res"]
        if st["skill"] == NAME and "explain" not in r and "_mem" in r and (y is None or r["y"] == y) \
                and row_id in _ids(r):
            return st
    return None


def _scope_from(st_other, row_id):
    """다른 skill 결과에서 그 행이 속한 범위(소스·필터·기간·그룹)를 SHAP 설정으로 옮긴다."""
    r = st_other["res"]
    cfg = {k: r["cfg"][k] for k in ("source", "filters", "date_filter") if r["cfg"].get(k)}
    rows = r.get("_mem", {}).get("rows")
    idc = r["cfg"].get("id_col")
    gb = r["cfg"].get("group_by") or []
    if rows is not None and idc in rows.columns and gb:
        hit = rows[rows[idc].astype(str) == row_id]
        if len(hit):
            cfg["filters"] = {**cfg.get("filters", {}), **{c: [str(hit.iloc[0][c])] for c in gb if c in hit.columns}}
    return cfg, r["cfg"].get("y")


def explain(res, row_id, top=8, smap=None):
    """학습된 마지막 회차 모델의 SHAP 값으로 행 하나의 예측을 변수별 기여로 나눈다. 각 변수의 값, 중앙값, 분석 범위 안 백분위를 함께 계산한다(문장은 만들지 않음). 분류에서 XGBoost·LightGBM은 로그 오즈를 확률로 바꿔 보인다.

    입력: res — 결과 dict(_mem 필요), row_id — 행 식별값(문자열), top — 보여줄 변수 수(기여 절댓값 순), smap — 컬럼 정의 맵
    반환: 설명 dict(row_id·base·pred·actual·residual·rest·top 목록 등). 행이 없으면 PipelineError
    """
    mem = res["_mem"]
    ids = _ids(res)
    if row_id not in ids:
        raise cd.PipelineError(f"이 분석 범위에 {cd.row_unit(res['cfg'], smap or {})} {cd.josa(row_id, '이가')} 없습니다.", {"hint": "다른 결과나 범위를 지정하세요", "examples": ids[:5]})
    i = ids.index(row_id)
    rd = mem["rounds"][-1]
    X, vals, base = rd["X"].reset_index(drop=True), rd["vals"], rd["base"]
    contrib = vals[i]
    pred = float(base[i] + contrib.sum())
    clf = res["task"] == "classification"
    margin = clf and res["model"] in ("XGBoost", "LightGBM")
    disp = (lambda z: float(1 / (1 + np.exp(-z)))) if margin else (lambda z: float(z))
    out = []
    for j in np.argsort(-np.abs(contrib))[:top]:
        c = X.columns[j]
        col = X[c]
        v = float(col.iloc[i])
        pct = float((col < v).mean() + 0.5 * (col == v).mean())
        out.append({"feature": c, "label": cd.label(c, smap or {}), "value": v, "median": float(col.median()), "share_on": float((col >= 0.5).mean()),
                    "pct": round(pct, 3), "contrib": float(contrib[j]), "onehot": "=" in c})
    rest = float(contrib.sum() - sum(o["contrib"] for o in out))
    actual = float(mem["y"].iloc[i]) if not clf else None
    return {"row_id": row_id, "unit": cd.row_unit(res["cfg"], smap or {}), "base": float(base[i]), "pred": pred, "base_disp": disp(float(base[i])), "pred_disp": disp(pred),
            "actual": actual, "actual_class": (int(mem["y"].iloc[i]) if clf else None),
            "residual": None if clf else float(actual - pred), "rest": rest, "top": out,
            "task": res["task"], "classes": res["classes"], "margin": margin, "run_id": res["run_id"], "y_label": res["y_label"],
            "cv": res["rounds"][-1]["cv"], "model": res["model"], "n_rows": res["n_rows"], "filters_text": res["filters_text"]}


def _pos(o):
    return f"하위 {o['pct']:.0%}" if o["pct"] < 0.5 else f"상위 {1 - o['pct']:.0%}"


def ui_explain(e: dict, res: dict, smap, eid: str) -> tuple[dict, dict]:
    """행 하나 설명 화면 데이터를 만든다(구성은 layout.yaml의 result.explain): 변수별 기여 표, 기여 분해 워터폴 데이터셋, 행 데이터셋 참조, 예측·실제·잔차, 설명력.

    입력: e — explain() 결과, res — 근거 SHAP 결과, smap — 컬럼 정의 맵, eid — 설명 결과 id
    반환: (화면 결과 dict, 빈 dict(데이터셋 프레임 없음))
    """
    clf = e["task"] == "classification"
    u = e.get("unit") or "행"
    rows_tbl = []
    for o in e["top"]:
        lab = cd.label(o["feature"], smap)
        if o["onehot"]:
            val, med, pos = ("해당" if o["value"] >= 0.5 else "아님"), f"해당 {u} {o['share_on']:.0%}", "-"
        else:
            val, med, pos = _num(o["value"]), _num(o["median"]), _pos(o)
        rows_tbl.append({"label": lab, "value": val, "median": med, "pos": pos, "contrib": round(o["contrib"], 4),
                         "dir": "높이는 쪽" if o["contrib"] > 0 else "낮추는 쪽", "tone": "up" if o["contrib"] > 0 else "down"})
    wf = [{"label": r["label"], "value": r["contrib"]} for r in rows_tbl] + \
         ([{"label": "나머지 변수", "value": round(e["rest"], 4)}] if abs(e["rest"]) > 1e-9 else [])
    datasets = {f"wf_{eid}": {"fields": [{"key": "label", "label": "변수", "type": "cat"}, {"key": "value", "label": "기여", "type": "num"}],
                              "rows": wf, "editable": False}}
    r_last = len(res["rounds"])
    ds_rows = f"{res['run_id']}:rows_r{r_last}"
    datasets[ds_rows] = {"fields": round_frame(res, -1, smap)[1], "url": f"/api/data/{res['run_id']}/rows_r{r_last}", "editable": True,
                         "id_field": res["cfg"].get("id_col")}
    pct = (lambda v: f"{v:.0%}") if e["margin"] else _num
    data = {"unit": u, "row_id": e["row_id"], "y_label": e["y_label"], "filters_text": e["filters_text"], "base_run": e["run_id"], "n_rows": e["n_rows"],
            "is_reg": not clf, "is_class": clf, "actual_text": _num(e["actual"]) if not clf else None,
            "actual_class_text": (e["classes"]["positive"] if e["actual_class"] == 1 else e["classes"]["negative"]) if clf else None,
            "pred_text": pct(e["pred_disp"]), "pred_note": "양성 확률" if e["margin"] else None, "base_text": pct(e["base_disp"]),
            "residual_text": _num(e["residual"]) if e["residual"] is not None else None, "model": e["model"], "cv": e["cv"],
            "cv_tone": C.grade_tone(e["cv"]["grade"]), "contrib": rows_tbl, "ds_rows": ds_rows, "ds_wf": f"wf_{eid}",
            "base": round(e["base"], 5), "pred": round(e["pred"], 5),
            "pos": [{"k": k, "feature": o["feature"], "label": cd.label(o["feature"], smap), "value": round(o["value"], 5)}
                    for k, o in enumerate([o for o in e["top"] if not o["onehot"]][:3])]}
    ui = {"skill": NAME, "kind": "explain", "run_id": eid, "pdf": True, "settings": False,
          **L.render(LAYOUT["result"]["explain"], data),
          "log": [], "warnings": [], "cfg": {}, "datasets": datasets,
          "badge": f"예측 {_num(e['pred_disp'])} · 1위 기여 {rows_tbl[0]['label'] if rows_tbl else '-'}",
          "short": f"{u} 설명 · {e['row_id']}", "target_label": e["y_label"]}
    return ui, {}


def explain_md(e: dict, smap) -> str:
    """행 하나 설명을 마크다운으로 만든다: 범위, 평균 예측에서 이 행의 예측(실제값·잔차 포함)까지, 변수별 표(값·중앙값·범위 안 위치·기여), 나머지 합계.

    입력: e — explain() 결과, smap — 컬럼 정의 맵
    반환: 마크다운 문자열
    """
    unit, u = (" (양성 확률)" if e["margin"] else ""), e.get("unit") or "행"
    lines = [f"### {u} {e['row_id']} 설명 (근거 SHAP 결과 `{e['run_id']}`, {e['model']}, {e['cv']['metric']} {e['cv']['mean']:.3f} {e['cv']['grade']})",
             f"- 범위: {e['filters_text']} · {e['n_rows']}{u}",
             f"- 평균 예측 {_num(e['base_disp'])} → 이 {u} 예측 {_num(e['pred_disp'])}{unit}"
             + (f" · 실제 {_num(e['actual'])} · 모델이 설명 못 한 차이 {_num(e['residual'])}" if e["residual"] is not None else ""),
             f"| 변수 | 이 {u} 값 | 평소(중앙값) | 분석 범위 안 위치 | 기여 |", "|---|---|---|---|---|"]
    for o in e["top"]:
        if o["onehot"]:
            lines.append(f"| {cd.label(o['feature'], smap)} | {'해당' if o['value'] >= 0.5 else '아님'} | 해당 {u} {o['share_on']:.0%} | - | {o['contrib']:+.3g} |")
        else:
            lines.append(f"| {cd.label(o['feature'], smap)} | {_num(o['value'])} | {_num(o['median'])} | {_pos(o)} | {o['contrib']:+.3g} |")
    lines.append(f"- 나머지 변수 합계 기여 {e['rest']:+.3g}")
    return "\n".join(lines)


def _check_row(bid, ctx, src_st):
    """데이터에 없는 식별값이면 모델을 학습하지 않고 바로 알린다(비슷한 식별값 제안)."""
    import difflib
    src_cfg = ((src_st or {}).get("res") or {}).get("cfg") or {}
    base = ctx.cfg({"source": src_cfg["source"]} if src_cfg.get("source") else {})
    idc, src = base.get("id_col"), base.get("source") or {}
    if not idc or "table" not in src or not isinstance(ctx.backend(), cd.SqlBackend):
        return
    be = ctx.backend()
    hit = be.query(f"SELECT CAST(`{idc}` AS STRING) AS v FROM {be._table(src['table'])} WHERE CAST(`{idc}` AS STRING) = :b LIMIT 1", {"b": bid})
    if len(hit):
        return
    near = be.query(f"SELECT CAST(`{idc}` AS STRING) AS v FROM {be._table(src['table'])} WHERE CAST(`{idc}` AS STRING) LIKE :p LIMIT 200",
                    {"p": bid[:4] + "%"})["v"].tolist()
    raise cd.PipelineError(f"데이터에 {cd.row_unit(base, cd.spec_map(cd.load_spec(base, be)))} {cd.josa(bid, '이가')} 없습니다.", {"similar": difflib.get_close_matches(bid, near, n=3, cutoff=0.4)})


def _explain(args, ctx):
    """행 하나를 설명한다. 이 행을 담은 SHAP 모델을 찾아 쓰고(같은 목표 지표), 없으면 식별값을 확인한 뒤 그 행의 범위로 SHAP을 새로 학습한다. 설명 결과를 등록하고 화면에 보낸다.

    입력: args — shap_explain 인자(row_id 필수, run_id·y·cfg·top 선택), ctx — 실행 문맥
    반환: {"text": 설명 마크다운과 안내, "summarize": ("result", 설명 id)}. 빈 식별값이면 PipelineError. 부작용: 필요하면 새 SHAP 학습, 결과·설명 등록, 화면 이벤트 발송
    """
    bid = str(args.get("row_id") or "").strip()
    if not bid:
        raise cd.PipelineError("설명할 행의 식별값이 없습니다.")
    y = args.get("y")
    src_st = ctx.conv.runs.get(args.get("run_id") or "") if args.get("run_id") else None
    st = None
    if src_st and src_st["skill"] == NAME and "_mem" in src_st["res"] and (y is None or src_st["res"]["y"] == y) and bid in _ids(src_st["res"]):
        st = src_st
    if st is None:
        st = _shap_run_with(ctx, bid, y)
    if st is None:  # 이 행을 담은 SHAP 모델이 없으면 그 범위로 실제로 새로 분석한다 (먼저 데이터에 있는 식별값인지 확인)
        _check_row(bid, ctx, src_st)
        cfg = dict(args.get("cfg") or {})
        if src_st and src_st["skill"] != NAME:
            scope, y0 = _scope_from(src_st, bid)
            cfg = {**scope, **cfg}
            y = y or y0
        if y:
            cfg["y"] = y
        ctx.progress(f"{cd.josa(bid, '이가')} 속한 범위로 SHAP 모델 학습")
        full = _lazy(ctx.cfg(cfg), cfg)
        res = ctx.compute(sp, "run", full, ctx.data(full), progress=True)
        ui, frames = ui_result(res, ctx)
        ctx.register(res["run_id"], NAME, res, ui, frames)
        ctx.emit({"type": "result", "data": ui})
        st = ctx.conv.runs[res["run_id"]]
    res = st["res"]
    smap = _smap(res, ctx)
    e = explain(res, bid, int(args.get("top") or 8), smap)
    eid = cd.run_id("exp_")
    ui, frames = ui_explain(e, res, smap, eid)
    ctx.register(eid, NAME, {"explain": e, "output_dir": res["output_dir"], "base_run": res["run_id"], "_id": eid}, ui, frames, main=False)
    ctx.emit({"type": "result", "data": ui})
    return {"text": explain_md(e, smap) + f"\n(결과 패널에 기여 분해와 변수 위치 차트가 표시됨. 이 설명 결과의 id = `{eid}` — PDF·차트 편집은 이 id)",
            "summarize": ("result", eid)}


def report_parts(state: dict) -> dict:
    """PDF에 넣을 이 skill의 내용(표 · 그림 · 파일 이름). PDF는 실행기가 common/report.py로 만든다.

    분석 결과: 회차별 요인 순위 표(상위 10개) + 엔진 차트(SHAP 분포 · 의존성 등, 없으면 지금 그림).
    한 건 설명: 변수별 기여 표 + 기여 막대 그림.
    입력: state — 결과 상태(explain 키가 있으면 한 건 설명)
    반환: {"file": 파일 이름, "tables": [표 블록], "images": [그림 경로]}
    """
    if "explain" in state:
        return _explain_parts(state)
    sp.ensure_charts(state)
    tables = []
    for rd in state["rounds"]:
        cv = rd["cv"]
        tables.append({"type": "table", "title": f"{rd['round']}회차 요인 순위 — 영향 요인 {rd['n_features']}개 · 설명력 {cv['metric']} {cv['mean']} ({cv['grade']})",
                       "columns": ["순위", "변수", "비중", "방향", "좋은 구간", "나쁜 구간"],
                       "rows": [[r["rank"], r["label"], f"{r['share']:.1%}", r["direction"], r.get("best_range") or "-", r.get("worst_range") or "-"]
                                for r in rd["top"][:10]]})
    return {"file": f"shap_report_{state['run_id']}.pdf", "tables": tables, "images": [c for rd in state["rounds"] for c in rd["charts"]]}


def _explain_parts(state: dict) -> dict:
    import matplotlib.pyplot as plt
    from common.plot import PALETTE, save, setup_font
    e = state["explain"]
    setup_font()
    u = e.get("unit") or "행"
    rows = [[o.get("label") or o["feature"], ("해당" if o["value"] >= 0.5 else "아님") if o["onehot"] else _num(o["value"]),
             f"해당 {u} {o['share_on']:.0%}" if o["onehot"] else _num(o["median"]), "-" if o["onehot"] else _pos(o), f"{o['contrib']:+.3g}"]
            for o in e["top"]]
    vals = [o["contrib"] for o in e["top"]][::-1]
    names = [o.get("label") or o["feature"] for o in e["top"]][::-1]
    fig, ax = plt.subplots(figsize=(8, 0.45 * len(vals) + 1.5))
    ax.barh(names, vals, color=[PALETTE["bar"] if v >= 0 else PALETTE["neg"] for v in vals])
    ax.axvline(0, color="#9AA0A6", lw=0.8)
    ax.set_title(f"{e['row_id']} 변수별 기여 (평균 예측 {e['base_disp']:.4g} → 예측 {e['pred_disp']:.4g})", fontsize=10)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    png = save(fig, state["output_dir"], f"explain_{e['row_id']}.png".replace("/", "_"))
    return {"file": f"explain_{e['row_id']}.pdf".replace("/", "_"),
            "tables": [{"type": "table", "title": f"{u} {e['row_id']} 변수별 기여 (나머지 변수 합계 {e['rest']:+.3g})",
                        "columns": ["변수", f"이 {u} 값", "평소(중앙값)", "분석 범위 안 위치", "기여"], "rows": rows}],
            "images": [png]}


# ----------------------------------------------------------------------------- 다음 단계 (고정 규칙)
