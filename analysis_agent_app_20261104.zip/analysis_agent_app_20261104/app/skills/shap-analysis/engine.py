"""SHAP 요인 분석 엔진 (skill: shap-analysis). 계산만 하며, 제안·해석·다음 단계는 SKILL.md를 읽은 LLM이 맡는다.

용도:
- 실행기가 데이터 처리 skill로 미리 처리한 데이터(범위 → 전처리 → 변수 선택 결과)를 받아 SHAP 분석을 한다.
- 목표 지표 정리, 영향 요인 고르기, 범주형 0/1, 결측 대치, 모델 학습·교차검증, SHAP, 차트, 결과 표, PDF를 정해진 코드로 수행한다.
- 데이터를 직접 읽지 않는다. 테이블 조회와 필터는 호출 쪽(실행기)이 맡는다.

목적:
- 같은 입력이면 같은 결과가 나오도록 계산 규칙을 코드에 고정하고, 해석과 제안은 LLM에 맡겨 역할을 나눈다.

사용 예:
    prof = profile(cfg, data)                   # 실행 전 진단 (행 수·전처리 영향·목표 지표 후보)
    res = run(cfg, data)                        # 분석 실행
"""
from __future__ import annotations

import json
import os
import re
import warnings

import numpy as np
import pandas as pd

from common import data as cd_impute
from common.data import PipelineError, SqlBackend  # noqa: F401  (SqlBackend: 호출 쪽 편의)
from common.data import cfg_lines as _cfg_lines
from common.data import is_num as _is_num
from common.data import label as _label
from common.data import bounds_of as _bounds_of, out_of as _out_of, roles as _roles
from common.data import josa, nested_parents, normalize_common, top_scope_dims
from common.data import require_cols as _require_cols
from common.data import run_id as _new_run_id
from common.plot import PALETTE
from common.plot import grid as _grid
from common.plot import save as _save
from common.plot import setup_font as _setup_font

warnings.filterwarnings("ignore")

DEFAULTS = {
    "source": None,                 # {"table": "catalog.schema.table"} | {"path": "/Volumes/.../file.pkl"}
    "spec_table": None,             # 컬럼 정보(첫 제안): column_name, display_name, unit, category, role, normal_min, normal_max
    "id_col": None,                 # 개별 행 식별 컬럼(특정 건 설명에 사용)
    "filters": {},                  # {컬럼: 값 또는 [값, ...]}  — 값 목록 중 하나와 일치(IN)
    "date_filter": None,            # {"col": 컬럼, "start": "YYYY-MM-DD", "end": "YYYY-MM-DD"}  — 양 끝 포함
    "y": None,                      # 목표 변수
    "task": "auto",                 # auto | regression | classification
    "y_positive": None,             # 분류: 양성 클래스 값
    "y_negative": None,             # 분류: 음성 클래스 값(지정 시 두 클래스 행만 사용, 미지정 시 양성 vs 나머지)
    "y_quantile": None,             # 수치 Y로 상·하위 그룹 자동 선정: {"top": 0.1, "bottom": 0.1, "labels": ["Golden", "Worst"]}
    "y_labels": None,               # 분류 두 값의 화면 이름 [양성, 음성](예: 오염 여부 1/0 → ["오염", "정상"])
    "x_include": None,              # X를 이 목록으로 고정(지정 시 자동 선택 무시)
    "x_exclude": [],                # 이번 분석에서만 X에서 제외(상위 변수 빼고 다시 등)
    "var_exclude": [],              # 공통 변수 선택(작업 데이터)에서 뺀 변수 — 모든 분석에 이어진다
    "x_categories": None,           # 컬럼 분류(category) 값 목록으로 X 제한
    "exclude_result_like": True,    # 역할 result(결과 뒤 값·누수 변수) 자동 제외
    "var_roles": {},                # 공통 · 대화에서 고친 변수 역할 {컬럼: y|x|result} — 첫 제안보다 우선
    "string_numeric": True,         # 숫자로 읽히는 문자열 컬럼을 숫자로 변환
    "string_numeric_min_ratio": 0.8,
    "normal_range": "nan",          # nan(범위 밖 값→결측) | drop_row(범위 밖 값 있는 행 제거) | off
    "normal_by_col": {},            # 공통 · 대화에서 고친 변수별 정상범위 {컬럼: [최소, 최대] | null} — 첫 제안보다 우선
    "na_ratio_max": 0.3,            # 결측 비율이 이 값을 초과하는 X 제외(1이면 빼지 않음)
    "min_unique": 2,                # 수치형: 고유값 개수가 이 값 미만이면 제외(1이면 빼지 않음)
    "max_categories": 20,           # 범주형: 고유값 개수가 이 값 초과면 제외
    "categorical": "exclude",       # exclude | onehot
    "impute": "auto",               # auto(변수마다 분포로 정함) | mean | median | constant | mode | knn | none(채우지 않음) — 모든 변수에 같은 방법
    "impute_constant": 0.0,
    "impute_by_col": {},            # 컬럼마다 다른 결측 대치 {컬럼: mean|median|mode|constant|knn|none 또는 채울 숫자}. 없는 컬럼은 impute
    "knn_k": 5,
    "model": "xgboost",             # xgboost | lightgbm | random_forest
    "cv_folds": 5,
    "top_n": 15,
    "dependence_top": 9,             # 의존성 그리드에 넣을 상위 변수 수(3열 그리드, 구간 분석은 상위 6개까지)
    "rounds": 1,                    # 재분석 반복 횟수
    "drop_top_per_round": 0,        # 라운드마다 제외할 상위 변수 개수
    "auto_rounds": 0,               # >0이면 지배 변수(1위 비중 50% 이상)가 사라질 때까지 그 변수를 빼며 최대 N회 더 반복
    "charts": None,                 # 만들 차트 목록(None=전체): importance, beeswarm, dependence_grid, ybins_grid, cases, correlation
    "explain_ids": [],              # 개별 설명(waterfall)할 id_col 값 목록
    "plot_max_rows": 2000,
    "output_dir": "outputs",
}

STEP_LABELS = {
    "string_numeric": "문자열 숫자 변환",
    "normal_range": "정상범위 필터",
    "na_ratio": "결측 비율 필터",
    "unique": "고유값 필터",
    "categorical": "범주형 처리",
    "impute": "결측 대치",
    "auto_exclude": "X 자동 제외",
    "y_rows": "Y 결측·범위 행 제거",
    "y_quantile": "상·하위 그룹 선정",
}
MODEL_LABELS = {"xgboost": "XGBoost", "lightgbm": "LightGBM", "random_forest": "RandomForest"}
IMPUTE_LABELS = cd_impute.IMPUTE_LABELS
auto_impute = cd_impute.auto_impute

def _cfg(user_cfg: dict) -> dict:
    """사용자 설정을 기본값(DEFAULTS)에 덮어 완성된 cfg를 만든다. 공통 키를 정규화하고 값 범위를 검사한다.

    입력: user_cfg — 사용자가 준 설정 dict(None 가능). DEFAULTS에 없는 키는 오류
    반환: 검사가 끝난 cfg dict. 잘못된 값이면 PipelineError
    """
    cfg = json.loads(json.dumps(DEFAULTS))
    for k, v in (user_cfg or {}).items():
        if k not in DEFAULTS:
            raise PipelineError(f"알 수 없는 설정 키: {k}", {"valid_keys": sorted(DEFAULTS)})
        cfg[k] = v
    normalize_common(cfg)
    for k in ("x_exclude", "var_exclude", "explain_ids"):
        cfg[k] = list(cfg[k] or [])
    if cfg["impute"] not in IMPUTE_LABELS:
        raise PipelineError(f"impute 값 오류: {cfg['impute']}", {"choices": list(IMPUTE_LABELS)})
    cfg["impute_by_col"] = dict(cfg.get("impute_by_col") or {})
    bad = {c: m for c, m in cfg["impute_by_col"].items()
           if not (m in IMPUTE_LABELS or (isinstance(m, (int, float)) and not isinstance(m, bool)))}
    if bad:
        raise PipelineError(f"impute_by_col 값 오류: {bad}", {"choices": list(IMPUTE_LABELS) + ["채울 숫자"]})
    if cfg["categorical"] not in ("exclude", "onehot"):
        raise PipelineError(f"categorical 값 오류: {cfg['categorical']}", {"choices": ["exclude", "onehot"]})
    if cfg["normal_range"] not in ("nan", "drop_row", "off"):
        raise PipelineError(f"normal_range 값 오류: {cfg['normal_range']}", {"choices": ["nan", "drop_row", "off"]})
    if cfg["model"] not in MODEL_LABELS:
        raise PipelineError(f"model 값 오류: {cfg['model']}", {"choices": list(MODEL_LABELS)})
    return cfg


# ----------------------------------------------------------------------------- prepare

def _resolve_task(y, cfg):
    task = cfg["task"]
    if task == "auto":
        task = "regression" if (_is_num(y) and y.nunique() > 2) else "classification"
    return task


def _prepare(data, cfg, impute=True):
    """처리된 데이터를 SHAP 입력(X, y)으로 바꾼다. 범위·전처리·변수 선택은 이미 끝나 있으므로 여기서는 다음만 한다.
    목표 지표 정리(결측 행과 수치 Y의 정상범위 밖 행 제거, y_quantile이면 상·하위 그룹만 남김, 분류면 양성·음성 지정) → 영향 요인 X 고르기(변수 선택에 남은 것에 x_include·x_exclude·x_categories 적용, 목표 지표와 결과 뒤 값은 이유와 함께 기록) → 범주형 0/1 → 결측 대치.

    입력: data — 처리된 데이터(df·smap·log·pool·problems), cfg — 완성된 설정, impute — False면 결측 대치를 하지 않음(profile 미리보기용)
    반환: (X DataFrame, y Series, meta dict[task·classes·log·warnings·n_rows·missing_top 등]). 목표 지표가 없거나 조건이 맞지 않으면 PipelineError
    """
    df, smap = data["df"], data["smap"]
    log, warn = [e for e in data["log"] if e["step"] != "impute"], []
    ycol = cfg["y"]
    if ycol is None:
        raise PipelineError("목표 변수(y)가 지정되지 않았습니다.", {"y_candidates": _y_candidates(df, smap, cfg)})
    if ycol in (cfg["var_exclude"] or []):
        raise PipelineError(f"목표 지표 {_label(ycol, smap)}{josa(_label(ycol, smap), '이가')} 변수 선택에서 빠져 있습니다.",
                            {"hint": "변수 선택(var_exclude)에서 다시 넣거나 다른 목표 지표를 고르세요."})
    _require_cols([ycol] + ([cfg["id_col"]] if cfg["id_col"] else []), list(df.columns))
    df = df.copy()

    # Y 정리
    n0 = len(df)
    task = _resolve_task(df[ycol].dropna(), cfg)
    if task == "regression":
        df[ycol] = pd.to_numeric(df[ycol], errors="coerce")
    df = df[df[ycol].notna()]
    rng = _bounds_of(ycol, smap, cfg.get("normal_by_col"))
    if task == "regression" and cfg["normal_range"] != "off" and rng is not None:
        df = df[~_out_of(df[ycol], rng)]
    classes = None
    quant = None
    if cfg["y_quantile"]:
        if task != "regression":
            raise PipelineError("상·하위 그룹 선정(y_quantile)은 수치형 Y에서만 쓸 수 있습니다.", {"y": ycol})
        q = cfg["y_quantile"]
        top, bot = float(q.get("top", 0.1)), float(q.get("bottom", 0.1))
        labs = list(q.get("labels") or ["Golden", "Worst"])
        hi, lo = float(df[ycol].quantile(1 - top)), float(df[ycol].quantile(bot))
        n_in = len(df)
        df = df[(df[ycol] >= hi) | (df[ycol] <= lo)]
        n_hi, n_lo = int((df[ycol] >= hi).sum()), int((df[ycol] <= lo).sum())
        n0 -= n_in - len(df)  # 선정에서 빠진 행은 y_rows 집계에서 제외
        quant = hi
        task = "classification"
        classes = {"positive": f"{labs[0]}(상위 {top:.0%})", "negative": f"{labs[1]}(하위 {bot:.0%})", "names": labs[:2], "named": True}
        log.append({"step": "y_quantile", "detail": f"{_label(ycol, smap)} 상위 {top:.0%}(≥{hi:.4g}) {n_hi}행을 {labs[0]}, "
                    f"하위 {bot:.0%}(≤{lo:.4g}) {n_lo}행을 {labs[1]}로 선정, 중간 {n_in - len(df)}행은 제외",
                    "thresholds": {"high": hi, "low": lo}})
    elif task == "classification":
        vc = df[ycol].astype(str).value_counts()
        pos, neg = cfg["y_positive"], cfg["y_negative"]
        if pos is None:
            if set(vc.index) <= {"0", "1", "0.0", "1.0", "True", "False"}:
                pos = "1" if "1" in vc.index else ("1.0" if "1.0" in vc.index else "True")
            elif len(vc) == 2:
                pos = vc.index[-1]  # 소수 클래스
            else:
                raise PipelineError("분류 Y의 양성 클래스(y_positive)를 지정해야 합니다.",
                                    {"classes": vc.to_dict()})
        pos = str(pos)
        if pos not in vc.index:
            raise PipelineError(f"Y에 '{pos}' 클래스가 없습니다.", {"classes": vc.to_dict()})
        if neg is not None:
            neg = [str(v) for v in (neg if isinstance(neg, list) else [neg])]
            df = df[df[ycol].astype(str).isin([pos] + neg)]
        classes = {"positive": pos, "negative": "/".join(neg) if neg else "나머지 전체"}
        yl = [str(v) for v in (cfg.get("y_labels") or [])][:2]
        classes.update(names=[yl[0] if yl else pos, yl[1] if len(yl) > 1 else classes["negative"]], named=bool(yl))
    if len(df) < n0:
        log.append({"step": "y_rows", "detail": f"Y가 비었거나 범위 밖이거나 비교 대상이 아닌 {n0 - len(df)}행 제외", "count": n0 - len(df)})
    if quant is not None:
        yv = (df[ycol] >= quant).astype(int)
    elif task == "classification":
        yv = (df[ycol].astype(str) == classes["positive"]).astype(int)
    else:
        yv = df[ycol].astype(float)

    # X 후보: 공통 변수 선택에 남은 영향 요인(목표 지표 후보·결과 뒤 값·직접 뺀 변수는 이유와 함께 기록)
    pool = {p["col"]: p for p in data["pool"]}
    auto_ex = {}
    for c, p in pool.items():
        why = {"결과 뒤 값": "결과성 변수(누수 위험)", "직접 뺌": "변수 선택에서 뺌"}.get(p["status"]) or \
            ("다른 결과(Y) 변수" if p["role"] == "y" and p["status"] is None else None)
        if why and c != ycol:
            auto_ex.setdefault(why, []).append(c)
    if cfg["x_include"]:
        _require_cols(cfg["x_include"], list(df.columns))
        cand = [c for c in cfg["x_include"] if c != ycol and c in pool and pool[c]["status"] in (None, "결과 뒤 값", "직접 뺌")]
    else:
        cand = [c for c, p in pool.items() if c != ycol and p["status"] is None and p["role"] != "y"]
        if cfg["x_categories"]:
            out = [c for c in cand if getattr(smap.get(c), "category", None) not in cfg["x_categories"]]
            if out:
                auto_ex["선택 분류 외"] = out
            cand = [c for c in cand if c not in out]
    user_ex = [c for c in cfg["x_exclude"] if c in cand]
    cand = [c for c in cand if c not in cfg["x_exclude"]]
    if auto_ex:
        log.append({"step": "auto_exclude", "detail": ", ".join(f"{k} {len(v)}개({', '.join(_label(c, smap) for c in v)})" for k, v in auto_ex.items()),
                    "columns": sum(auto_ex.values(), []), "by_reason": auto_ex})
    if user_ex:
        log.append({"step": "auto_exclude", "detail": f"이번 분석에서 뺌 {len(user_ex)}개({', '.join(_label(c, smap) for c in user_ex)})",
                    "columns": user_ex})
    X = df.loc[:, cand].copy()
    na = X.isna().mean()
    missing_top = [{"col": c, "label": _label(c, smap), "ratio": round(float(na[c]), 4)}
                   for c in na.sort_values(ascending=False).index if na[c] > 0][:40]

    # 범주형
    cats = [c for c in X.columns if not (_is_num(X[c]) or pd.api.types.is_bool_dtype(X[c]))]
    categoricals = [{"col": c, "label": _label(c, smap), "levels": int(X[c].nunique(dropna=True))} for c in cats]
    _numx = X[[c for c in X.columns if c not in cats]]
    missing_cell_ratio = float(_numx.isna().sum().sum() / max(1, _numx.shape[0] * _numx.shape[1]))
    if cats:
        if cfg["categorical"] == "exclude":
            log.append({"step": "categorical", "detail": f"범주형 {len(cats)}개 제외: " + ", ".join(_label(c, smap) for c in cats),
                        "columns": cats})
            X = X.drop(columns=cats)
        else:
            dummies = pd.get_dummies(X[cats].astype("object"), prefix_sep="=", dummy_na=False, dtype=float)
            log.append({"step": "categorical", "detail": f"범주형 {len(cats)}개({', '.join(_label(c, smap) for c in cats)})를 "
                                                         f"범주별 0/1 컬럼 {dummies.shape[1]}개로 변환",
                        "columns": cats})
            X = pd.concat([X.drop(columns=cats), dummies], axis=1)
    X = X.astype(float)

    # 결측 대치: 변수마다 impute_by_col의 방법 → 없으면 impute(auto면 그 변수 분포로 정함). 규칙은 common.data(작업 데이터와 같음)
    methods, impute_plan = cd_impute.impute_methods(X, cfg, smap)
    n_missing = int(X[[c for c, m in methods.items() if m != "none"]].isna().sum().sum())  # 채우지 않는 변수는 결측 그대로 모델에 넣는다
    if impute and n_missing:
        X = cd_impute.apply_impute(X, methods, cfg)
    if methods:
        log.append(cd_impute.impute_entry(methods, cfg, smap, n_missing, impute))

    if len(X) < 30:
        warn.append(f"분석 행이 {len(X)}건으로 적습니다(30건 미만은 실행 불가).")
    elif len(X) < 100:
        warn.append(f"분석 행이 {len(X)}건으로 적어 결과 변동이 클 수 있습니다.")
    if task == "classification":
        mc = int(yv.value_counts().min()) if yv.nunique() == 2 else 0
        if mc < 10:
            warn.append(f"분류 클래스 최소 건수 {mc}건 (10건 미만은 실행 불가).")
    ids = df.loc[X.index, cfg["id_col"]].astype(str).tolist() if cfg["id_col"] else None
    meta = {"task": task, "classes": classes, "log": log, "warnings": warn, "n_rows": int(len(X)),
            "missing_top": missing_top, "categoricals": categoricals, "impute_plan": impute_plan,
            "missing_cell_ratio": round(missing_cell_ratio, 4),
            "range_hits": sum(e.get("count", 0) for e in log if e["step"] == "normal_range"),
            "n_features": int(X.shape[1]), "n_variables": len({str(c).split("=")[0] for c in X.columns}),  # 원래 변수 수(범주형 값별 칸은 하나로)
            "ids": ids, "y_series_stats": _y_stats(yv, task)}
    return X, yv.loc[X.index], meta


def _y_stats(yv, task):
    if task == "classification":
        return {"positive_rate": round(float(yv.mean()), 4), "n_positive": int(yv.sum()), "n_negative": int((1 - yv).sum())}
    return {k: round(float(v), 4) for k, v in yv.describe()[["mean", "std", "min", "max"]].items()}


def _y_candidates(df, smap, cfg):
    rl = _roles(smap, cfg)
    ys = [c for c, r in rl.items() if r == "y" and c in df.columns and c not in (cfg.get("var_exclude") or [])]
    if ys:
        return ys
    # 첫 제안이 없거나 이 데이터에 맞지 않으면 이름으로 결과 지표 후보를 찾는다
    pat = re.compile(r"yield|titer|productivity|grade|output|quality|수율|역가|생산성|등급|품질", re.I)
    return [c for c in df.columns if pat.search(c) and (_is_num(df[c]) or df[c].nunique() <= 5)][:8]


# ----------------------------------------------------------------------------- profile

def profile(user_cfg: dict, data: dict) -> dict:
    """실행 전 진단(미리보기). 필터 결과 건수·필터 값 불일치·Y 후보·전처리 영향(결측 대치 미적용)을 모은다. 전처리 오류는 예외로 던지지 않고 prof["error"]에 담는다. 필터 문제가 있거나 0행이면 전처리 없이 돌아간다.

    입력: user_cfg — 사용자 설정 dict, data — 처리된 데이터(df·problems·smap 등)
    반환: 진단 dict(cfg·source·filters_text·n_after_filter·filter_problems·y_candidates·columns_meta·prep·error·y_classes 등). prep은 Y가 정해져 전처리가 되면 채워진다
    """
    cfg = _cfg(user_cfg)
    df, problems, smap = data["df"], data["problems"], data["smap"]
    src, ftxt = _cfg_lines(cfg, smap)
    prof = {"cfg": cfg, "source": src, "filters_text": ftxt, "n_after_filter": int(len(df)), "filter_problems": problems,
            "y_label": _label(cfg["y"], smap) if cfg["y"] else None,
            "y_candidates": [{"col": c, "label": _label(c, smap)} for c in _y_candidates(df, smap, cfg)],
            "columns": len(df.columns), "prep": None, "error": None,
            "columns_meta": [{"col": c, "label": _label(c, smap), "category": getattr(smap.get(c), "category", None),
                              "role": getattr(smap.get(c), "role", None), "numeric": bool(_is_num(df[c]))} for c in df.columns]}
    if problems or len(df) == 0:
        return prof
    if cfg["y"]:
        try:
            X, yv, meta = _prepare(data, cfg, impute=False)
            prof["prep"] = {k: meta[k] for k in ("task", "classes", "log", "warnings", "n_rows", "n_features", "n_variables",
                                                 "y_series_stats", "missing_top", "categoricals", "missing_cell_ratio", "impute_plan",
                                                 "range_hits")}
            prof["prep"]["features"] = list(X.columns)
        except PipelineError as e:
            prof["error"] = {"message": str(e), **e.detail}
    prof["y_classes"] = {c: df[c].astype(str).value_counts().to_dict()
                         for c in [y["col"] for y in prof["y_candidates"]] if c in df.columns and not _is_num(df[c])}
    return prof


def _y_stats_text(stats: dict, task: str) -> str:
    if task == "classification":
        return f"양성 {stats.get('n_positive')}건, 음성 {stats.get('n_negative')}건"
    f = lambda v: f"{v:,.4g}"
    return f"평균 {f(stats['mean'])}, 표준편차 {f(stats['std'])}, 범위 {f(stats['min'])}–{f(stats['max'])}"


def profile_md(prof: dict) -> str:
    """진단 결과(profile)를 채팅용 마크다운으로 만든다: 데이터·필터·Y·전처리 미리보기·경고. 필터 값이 맞지 않으면 그 문제만 담고 끝낸다.

    입력: prof — profile() 반환 dict
    반환: 마크다운 문자열(부작용 없음)
    """
    cfg = prof["cfg"]
    out = [f"**데이터** {prof['source']} | 필터: {prof['filters_text']} → **{prof['n_after_filter']}행**"]
    if prof["filter_problems"]:
        for c, p in prof["filter_problems"].items():
            sug = "; ".join(f"'{k}'→{v}" for k, v in p["suggestions"].items())
            out.append(f"- ⚠ 필터 값 불일치 `{c}`: {sug} (가능한 값: {', '.join(p['available'][:15])})")
        return "\n".join(out)
    if prof.get("error"):
        out.append(f"- ⚠ {prof['error']['message']} {json.dumps({k: v for k, v in prof['error'].items() if k != 'message'}, ensure_ascii=False)[:600]}")
    if prof["prep"]:
        p = prof["prep"]
        cls = f" (양성={p['classes']['positive']}, 음성={p['classes']['negative']})" if p["classes"] else ""
        out.append(f"**Y** {prof.get('y_label') or cfg['y']} · {'회귀' if p['task'] == 'regression' else '분류'}{cls} · "
                   f"{_y_stats_text(p['y_series_stats'], p['task'])}")
        out.append(f"**전처리 미리보기** → 사용 행 {p['n_rows']} · X {p['n_features']}개")
        for e in p["log"]:
            out.append(f"- {STEP_LABELS.get(e['step'], e['step'])}: {e['detail']}")
        for w in p["warnings"]:
            out.append(f"- ⚠ {w}")
    else:
        out.append("**Y 후보** " + ", ".join(y["label"] for y in prof["y_candidates"]))
    if not prof["prep"] or prof["prep"]["task"] != "regression":
        for c, v in (prof.get("y_classes") or {}).items():
            out.append(f"- {c} 클래스: {v}")
    return "\n".join(out)


# ----------------------------------------------------------------------------- model / shap

def _make_model(name, task, warn):
    """분석 모델을 만든다. xgboost → lightgbm → random_forest 순으로 쓰고, 불러오지 못하면 다음 모델로 바꾼 뒤 warn에 이유를 남긴다. 시드는 42로 고정.

    입력: name — 모델 이름(xgboost·lightgbm·random_forest), task — regression 또는 classification, warn — 경고를 쌓을 list(변경됨)
    반환: (모델 객체, 실제로 쓴 모델 이름)
    """
    seed = 42
    if name == "xgboost":
        try:
            import xgboost as xgb
            p = dict(n_estimators=300, max_depth=4, learning_rate=0.05, subsample=0.8, colsample_bytree=0.8,
                     random_state=seed, n_jobs=-1, tree_method="hist")
            return (xgb.XGBRegressor(**p) if task == "regression" else xgb.XGBClassifier(eval_metric="logloss", **p)), name
        except Exception:
            warn.append("xgboost를 불러오지 못해 lightgbm으로 대체")
            name = "lightgbm"
    if name == "lightgbm":
        try:
            import lightgbm as lgb
            p = dict(n_estimators=300, num_leaves=15, learning_rate=0.05, subsample=0.8, subsample_freq=1,
                     colsample_bytree=0.8, random_state=seed, verbose=-1)
            return (lgb.LGBMRegressor(**p) if task == "regression" else lgb.LGBMClassifier(**p)), name
        except Exception:
            warn.append("lightgbm을 불러오지 못해 random_forest로 대체")
    from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
    p = dict(n_estimators=300, min_samples_leaf=3, random_state=seed, n_jobs=-1)
    return (RandomForestRegressor(**p) if task == "regression" else RandomForestClassifier(**p)), "random_forest"


def _cv(model, X, y, task, folds):
    """교차검증으로 설명력을 잰다. 회귀는 R²(KFold), 분류는 AUC(StratifiedKFold). 행이 100 미만이면 겹 수를 최대 3으로 줄인다. 모델은 복제해서 쓰므로 원본은 바뀌지 않는다.

    입력: model — 학습 전 모델, X — 독립변수 DataFrame, y — 목표 Series, task — 분석 종류, folds — 기본 겹 수
    반환: dict(metric·mean·std·folds·grade). grade는 회귀 R² 0.6 이상 양호·0.3 이상 보통·그 밖 낮음, 분류 AUC 0.8 이상 양호·0.65 이상 보통·그 밖 낮음
    """
    from sklearn.base import clone
    from sklearn.model_selection import KFold, StratifiedKFold, cross_val_score
    k = min(folds, 3) if len(X) < 100 else folds
    if task == "regression":
        s = cross_val_score(clone(model), X, y, cv=KFold(k, shuffle=True, random_state=42), scoring="r2")
        m = float(np.mean(s))
        grade = "양호" if m >= 0.6 else ("보통" if m >= 0.3 else "낮음")
        return {"metric": "R²", "mean": round(m, 3), "std": round(float(np.std(s)), 3), "folds": k, "grade": grade}
    s = cross_val_score(clone(model), X, y, cv=StratifiedKFold(k, shuffle=True, random_state=42), scoring="roc_auc")
    m = float(np.mean(s))
    grade = "양호" if m >= 0.8 else ("보통" if m >= 0.65 else "낮음")
    return {"metric": "AUC", "mean": round(m, 3), "std": round(float(np.std(s)), 3), "folds": k, "grade": grade}


def _shap_values(model, X, name):
    """모델의 SHAP 기여값을 계산한다. TreeExplainer를 먼저 쓰고, 실패하면 xgboost일 때만 부스터의 pred_contribs로 대신 계산한다. 다차원 결과(분류)는 양성 클래스(인덱스 1) 기준으로 맞춘다.

    입력: model — 학습된 트리 모델, X — 독립변수 DataFrame, name — 모델 이름
    반환: (기여값 배열[행×변수], 기준값 배열[행]). 기준값은 평균 예측
    """
    import shap
    try:
        ex = shap.TreeExplainer(model)(X)
        vals, base = ex.values, ex.base_values
    except Exception:
        if name != "xgboost":
            raise
        import xgboost as xgb
        contrib = model.get_booster().predict(xgb.DMatrix(X), pred_contribs=True)
        vals, base = contrib[:, :-1], contrib[:, -1]
    vals, base = np.asarray(vals), np.asarray(base)
    if vals.ndim == 3:
        vals = vals[:, :, 1]
        base = base[:, 1] if base.ndim == 2 else base
    if base.ndim == 0:
        base = np.full(len(X), float(base))
    return vals, base


def _importance(X, vals, top_n, dep_top, smap):
    """평균 |SHAP| 기준 변수 중요도 표를 만든다. 각 변수에 비중과 방향을 붙인다. 방향은 값과 기여의 Spearman 상관으로 정하고(|ρ| 0.3 미만이면 비단조), 구간 분석은 상위 변수 중 최대 6개에만 넣어 5분위 구간별 평균 기여로 최대·최소 구간을 붙인다. 1위 비중이 50% 이상이면 지배 변수로 본다.

    입력: X — 독립변수 DataFrame, vals — SHAP 기여 배열, top_n — 표에 넣을 변수 수, dep_top — 구간 분석 대상 상위 변수 수(최대 6과 함께 적용), smap — 컬럼 정의 맵
    반환: (행 list[dict(rank·feature·label·mean_abs_shap·share·direction·spearman, 구간이 있으면 bins·best_range·worst_range)], 지배 변수 이름 또는 None)
    """
    from scipy.stats import spearmanr
    mean_abs = np.abs(vals).mean(axis=0)
    total = mean_abs.sum() or 1.0
    order = np.argsort(-mean_abs)
    rows = []
    for rank, j in enumerate(order[:top_n], 1):
        x, s = X.iloc[:, j].values, vals[:, j]
        rho = spearmanr(x, s).statistic if np.nanstd(x) > 0 and np.nanstd(s) > 0 else np.nan
        direction = "비단조" if np.isnan(rho) or abs(rho) < 0.3 else ("증가" if rho > 0 else "감소")
        row = {"rank": rank, "feature": X.columns[j], "label": _label(X.columns[j], smap),
               "mean_abs_shap": round(float(mean_abs[j]), 4), "share": round(float(mean_abs[j] / total), 4),
               "direction": direction, "spearman": None if np.isnan(rho) else round(float(rho), 3)}
        if rank <= min(dep_top, 6) and len(np.unique(x)) > 5:
            bins = pd.qcut(pd.Series(x), q=5, duplicates="drop")
            g = pd.DataFrame({"bin": bins, "s": s}).groupby("bin", observed=True)["s"].agg(["mean", "size"])
            prof = [{"range": f"{iv.left:.4g}–{iv.right:.4g}", "mean_shap": round(float(m), 4), "n": int(n)}
                    for iv, (m, n) in zip(g.index, g.values)]
            row["bins"] = prof
            row["best_range"] = max(prof, key=lambda b: b["mean_shap"])["range"]
            row["worst_range"] = min(prof, key=lambda b: b["mean_shap"])["range"]
        rows.append(row)
    dominance = rows[0]["feature"] if rows and rows[0]["share"] >= 0.5 else None
    return rows, dominance


# ----------------------------------------------------------------------------- charts

def _charts(X, vals, base, rows, labels, outdir, prefix, cfg, ids, title, yv, task):
    """분석 차트를 PNG로 저장한다. cfg["charts"]가 None이면 전체를 만든다: 중요도 막대 · SHAP 분포(beeswarm) · 의존성 그리드(상위 dependence_top개, 3열) · 구간별 실제 Y 격자(수치 상위 6개) · 대표 사례(예측 최저·중앙·최고, 기여 상위 8개) · 상관 히트맵(상위 10개 + Y) · 개별 설명(explain_ids의 waterfall). 행이 plot_max_rows를 넘으면 시드 42로 무작위 표본만 그린다.

    입력: X — 독립변수 DataFrame, vals — SHAP 기여, base — 기준값, rows — 중요도 표, labels — 차트용 변수 이름 list(X 컬럼 순서), outdir — 저장 폴더, prefix — 파일 이름 접두어(예 r1), cfg — 설정, ids — 행 식별값 list 또는 None, title — 차트 제목에 쓸 이름, yv — 목표 Series, task — 분석 종류
    반환: 저장한 PNG 경로 list. 부작용: outdir에 PNG 쓰기, matplotlib figure 생성
    """
    import matplotlib.pyplot as plt
    import shap
    from matplotlib.colors import LinearSegmentedColormap
    files = []
    n = len(X)
    cols = list(X.columns)
    lab = dict(zip(cols, labels))
    idx = np.arange(n)
    if n > cfg["plot_max_rows"]:
        idx = np.random.default_rng(42).choice(n, cfg["plot_max_rows"], replace=False)
    ex = shap.Explanation(values=vals[idx], base_values=base[idx], data=X.values[idx], feature_names=labels)
    ylab = "양성 비율" if task == "classification" else "목표 지표 평균"

    want = set(cfg["charts"] if cfg["charts"] is not None else
               ["importance", "beeswarm", "dependence_grid", "ybins_grid", "cases", "correlation"])

    # 1) 중요도
    if "importance" in want:
        top = rows[: cfg["top_n"]]
        fig, ax = plt.subplots(figsize=(8, 0.42 * len(top) + 1.4))
        ax.barh([lab[r["feature"]] for r in top][::-1], [r["mean_abs_shap"] for r in top][::-1], color=PALETTE["bar"])
        ax.spines[["top", "right"]].set_visible(False)
        for i, r in enumerate(top[::-1]):
            ax.text(r["mean_abs_shap"], i, f" {r['share']:.0%}", va="center", fontsize=8)
        ax.set_xlabel("평균 |SHAP| (목표 지표 단위)")
        ax.set_title(f"변수 중요도 — {title}", fontsize=11)
        fig.tight_layout()
        files.append(_save(fig, outdir, f"{prefix}_importance.png"))

    # 2) SHAP 분포
    if "beeswarm" in want:
        cmap = LinearSegmentedColormap.from_list("bench", [PALETTE["low"], PALETTE["mid"], PALETTE["high"]])
        shap.plots.beeswarm(ex, max_display=cfg["top_n"], show=False, color=cmap)
        plt.gcf().suptitle(f"SHAP 분포 — {title}", fontsize=11)
        files.append(_save(plt.gcf(), outdir, f"{prefix}_beeswarm.png"))

    # 3) 의존성 그리드 (상위 dependence_top개, 3열)
    if "dependence_grid" in want:
        dep = rows[: max(1, min(cfg["dependence_top"], len(rows)))]
        nr, nc = _grid(len(dep))
        fig, axes = plt.subplots(nr, nc, figsize=(4.0 * nc, 3.1 * nr), squeeze=False)
        for k, r in enumerate(dep):
            ax = axes[k // nc][k % nc]
            j = cols.index(r["feature"])
            x, sv = X.values[idx, j], vals[idx, j]
            if len(np.unique(x)) <= 2:
                groups = [sv[x == v] for v in sorted(np.unique(x))]
                ax.boxplot(groups, widths=0.5, patch_artist=True, showfliers=False,
                           boxprops={"facecolor": PALETTE["mid"], "edgecolor": PALETTE["bar"]},
                           medianprops={"color": PALETTE["bar"]}, whiskerprops={"color": PALETTE["bar"]},
                           capprops={"color": PALETTE["bar"]})
                ax.set_xticks(range(1, len(groups) + 1), ["아님", "해당"][: len(groups)])
            else:
                ax.scatter(x, sv, s=7, alpha=0.55, color=PALETTE["bar"], linewidths=0)
            ax.axhline(0, color="#9AA8A9", lw=0.8)
            ax.set_title(f"{r['rank']}. {lab[r['feature']]}  {r['share']:.0%}", fontsize=9.5)
            ax.tick_params(labelsize=8)
            ax.spines[["top", "right"]].set_visible(False)
        for k in range(len(dep), nr * nc):
            axes[k // nc][k % nc].axis("off")
        fig.supxlabel("변수 값", fontsize=9)
        fig.supylabel("SHAP 기여", fontsize=9)
        fig.suptitle(f"의존성 {nr}×{nc} — 변수 값에 따른 기여 변화", fontsize=11)
        fig.tight_layout()
        files.append(_save(fig, outdir, f"{prefix}_dependence_grid.png"))

    # 4) 구간별 실제 Y (상위 수치형 6개, 5분위 구간별 평균 ± 95% 구간)
    if "ybins_grid" in want:
        num = [r for r in rows if "=" not in r["feature"] and X[r["feature"]].nunique() > 5][:6]
        if num:
            nr, nc = _grid(len(num))
            fig, axes = plt.subplots(nr, nc, figsize=(4.0 * nc, 3.0 * nr), squeeze=False)
            yarr = np.asarray(yv, dtype=float)
            for k, r in enumerate(num):
                ax = axes[k // nc][k % nc]
                b = pd.qcut(X[r["feature"]].values, q=5, duplicates="drop")
                g = pd.DataFrame({"b": b, "y": yarr}).groupby("b", observed=True)["y"].agg(["mean", "std", "size"])
                ci = 1.96 * g["std"].fillna(0) / np.sqrt(g["size"].clip(lower=1))
                xs = np.arange(len(g))
                ax.bar(xs, g["mean"], color=PALETTE["mid"], edgecolor=PALETTE["bar"], linewidth=0.8)
                ax.errorbar(xs, g["mean"], yerr=ci, fmt="none", ecolor=PALETTE["bar"], elinewidth=1, capsize=2)
                lo = np.nanmin(g["mean"] - ci)
                hi = np.nanmax(g["mean"] + ci)
                pad = (hi - lo) * 0.25 or 1
                ax.set_ylim(lo - pad, hi + pad)
                ax.set_xticks(xs, [f"{iv.left:.4g}–{iv.right:.4g}" for iv in g.index], rotation=30, ha="right", fontsize=7)
                ax.set_title(f"{r['rank']}. {lab[r['feature']]}", fontsize=9.5)
                ax.tick_params(axis="y", labelsize=8)
                ax.spines[["top", "right"]].set_visible(False)
            for k in range(len(num), nr * nc):
                axes[k // nc][k % nc].axis("off")
            fig.supylabel(ylab, fontsize=9)
            fig.suptitle(f"구간별 실제 {ylab} {nr}×{nc} — 변수 값 5분위", fontsize=11)
            fig.tight_layout()
            files.append(_save(fig, outdir, f"{prefix}_ybins_grid.png"))

    # 5) 대표 사례 1×3 (예측 최저·중앙·최고) — 기여 상위 8개
    if "cases" in want:
        pred = base + vals.sum(axis=1)
        order = np.argsort(pred)
        picks = [("예측 최저", order[0]), ("예측 중앙", order[len(order) // 2]), ("예측 최고", order[-1])]
        fig, axes = plt.subplots(1, 3, figsize=(13, 4.2), squeeze=False)
        for k, (name, i) in enumerate(picks):
            ax = axes[0][k]
            top8 = np.argsort(-np.abs(vals[i]))[:8][::-1]
            v = vals[i][top8]
            ax.barh([lab[cols[j]] for j in top8], v, color=[PALETTE["bar"] if t >= 0 else PALETTE["neg"] for t in v])
            ax.axvline(0, color="#9AA8A9", lw=0.8)
            who = ids[i] if ids else f"행 {i}"
            ax.set_title(f"{name}: {who}\n예측 {pred[i]:.4g} (평균 {base[i]:.4g})", fontsize=9.5)
            ax.tick_params(labelsize=8)
            ax.spines[["top", "right"]].set_visible(False)
        fig.suptitle("대표 사례 1×3 — 평균 대비 예측을 움직인 변수", fontsize=11)
        fig.tight_layout()
        files.append(_save(fig, outdir, f"{prefix}_cases.png"))

    # 6) 상관 히트맵 (상위 10개 + Y, Spearman)
    if "correlation" in want:
        hv = [r["feature"] for r in rows[:10]]
        if len(hv) >= 2:
            frame = X[hv].copy()
            frame["__y__"] = np.asarray(yv, dtype=float)
            corr = frame.corr(method="spearman").values
            names = [lab[c] for c in hv] + ["Y"]
            fig, ax = plt.subplots(figsize=(0.62 * len(names) + 3, 0.55 * len(names) + 2))
            cm = LinearSegmentedColormap.from_list("corr", [PALETTE["neg"], "#FFFFFF", PALETTE["bar"]])
            im = ax.imshow(corr, cmap=cm, vmin=-1, vmax=1)
            ax.set_xticks(range(len(names)), names, rotation=45, ha="right", fontsize=8)
            ax.set_yticks(range(len(names)), names, fontsize=8)
            for a in range(len(names)):
                for b in range(len(names)):
                    ax.text(b, a, f"{corr[a, b]:.2f}", ha="center", va="center", fontsize=6.5,
                            color="#17282A" if abs(corr[a, b]) < 0.6 else "#FFFFFF")
            fig.colorbar(im, ax=ax, shrink=0.75)
            ax.set_title("상위 변수 상관 (Spearman) — 서로 연관된 변수는 기여도를 나눠 가짐", fontsize=10)
            fig.tight_layout()
            files.append(_save(fig, outdir, f"{prefix}_correlation.png"))

    # 7) 개별 설명 (요청한 ID)
    if ids and cfg["explain_ids"]:
        full = shap.Explanation(values=vals, base_values=base, data=X.values, feature_names=labels)
        for target in cfg["explain_ids"]:
            if str(target) in ids:
                i = ids.index(str(target))
                shap.plots.waterfall(full[i], max_display=12, show=False)
                plt.gcf().suptitle(f"개별 설명 — {target}", fontsize=11)
                files.append(_save(plt.gcf(), outdir, f"{prefix}_waterfall_{re.sub(r'[^0-9A-Za-z_-]', '_', str(target))}.png"))
    return files


def _round_compare(rounds: list) -> dict:
    """라운드별 상위 변수 순위·CV 비교표."""
    feats = []
    for rd in rounds:
        for t in rd["top"][:5]:
            if t["feature"] not in [f["feature"] for f in feats]:
                feats.append({"feature": t["feature"], "label": t["label"]})
    for f in feats:
        f["ranks"] = []
        for rd in rounds:
            hit = next((t for t in rd["top"] if t["feature"] == f["feature"]), None)
            f["ranks"].append({"rank": hit["rank"], "share": hit["share"]} if hit else
                              ("제외" if f["feature"] in rd["excluded_before"] else None))
    return {"cv": [rd["cv"] for rd in rounds], "features": feats}


# ----------------------------------------------------------------------------- run

def run(user_cfg: dict, data: dict, progress=None) -> dict:
    """SHAP 분석 전체를 실행한다: 목표 지표 정리 → 회차마다 모델 학습·교차검증·SHAP → 중요도 표 → 차트. rounds와 drop_top_per_round가 있으면 상위 N개를 빼며 반복하고, auto_rounds가 있으면 지배 변수가 있는 동안 그 변수를 빼며 최대 N회 반복한다. 결과 파일(회차별 중요도 CSV·차트 PNG·summary.json)은 output_dir/shap_<run_id>에 쓴다.

    입력: user_cfg — 사용자 설정 dict, data — 처리된 데이터(df·problems·smap·log·pool 등), progress — 단계 문구를 받는 함수(없으면 무시)
    반환: 결과 dict(run_id·output_dir·rounds·round_compare·preprocess_log·warnings·cfg 등). 화면 차트용 원자료는 "_mem" 키에 담고 summary.json에서는 뺀다. 필터 불일치·0행·분석 행 30건 미만·분류 클래스 10건 미만이면 PipelineError
    """
    step = progress or (lambda _t: None)
    cfg = _cfg(user_cfg)
    df, problems, smap = data["df"], data["problems"], data["smap"]
    if problems:
        raise PipelineError("필터 값이 데이터와 일치하지 않습니다.", {"filter_problems": problems})
    if len(df) == 0:
        raise PipelineError("필터 결과가 0행입니다.", {"filters": cfg["filters"], "date_filter": cfg["date_filter"]})
    step(f"목표 지표·영향 요인 정리 ({len(df):,}행)")
    X, yv, meta = _prepare(data, cfg)
    if meta["n_rows"] < 30:
        raise PipelineError(f"분석 가능한 행이 {meta['n_rows']}건입니다(최소 30건).", {"hint": "필터 조건을 완화하세요."})
    if meta["task"] == "classification" and (yv.nunique() < 2 or yv.value_counts().min() < 10):
        raise PipelineError("분류 클래스 건수가 부족합니다(클래스별 최소 10건).", {"counts": yv.value_counts().to_dict()})

    run_id = _new_run_id()
    outdir = os.path.join(cfg["output_dir"], f"shap_{run_id}")
    os.makedirs(outdir, exist_ok=True)
    font_ok = _setup_font()
    warn = list(meta["warnings"])
    if not font_ok:
        warn.append("한글 폰트를 불러오지 못해 차트 라벨을 컬럼명으로 표시합니다.")

    src, ftxt = _cfg_lines(cfg, smap)
    ylabel = _label(cfg["y"], smap)
    title = ylabel if meta["task"] == "regression" else f"{ylabel}={meta['classes']['positive']}"
    rounds, excluded = [], []
    Xr = X
    mem = {"rows": df.loc[X.index].reset_index(drop=True), "y": yv.reset_index(drop=True), "rounds": []}
    model_name = cfg["model"]
    r, stop_reason = 0, None
    while True:
        r += 1
        model, model_name = _make_model(cfg["model"], meta["task"], warn)
        tag = f"{r}회차 · " if int(cfg["rounds"]) > 1 or int(cfg["auto_rounds"]) > 0 else ""
        step(f"{tag}{cfg['cv_folds']}겹 교차검증 ({meta['n_rows']:,}행 · 변수 {Xr.shape[1]}개)")
        cv = _cv(model, Xr, yv, meta["task"], cfg["cv_folds"])
        step(f"{tag}{MODEL_LABELS[model_name]} 학습")
        model.fit(Xr, yv)
        step(f"{tag}SHAP 기여 계산")
        vals, base = _shap_values(model, Xr, model_name)
        rows, dominance = _importance(Xr, vals, cfg["top_n"], cfg["dependence_top"], smap)
        labels = [_label(c, smap) if font_ok else c for c in Xr.columns]
        if not font_ok:
            for row in rows:
                row["label_chart"] = row["feature"]
        if cfg["charts"] != []:
            step(f"{tag}정적 차트")
        charts = _charts(Xr, vals, base, rows, labels, outdir, f"r{r}", cfg, meta["ids"], title, yv, meta["task"])
        pd.DataFrame(rows).drop(columns=["bins"], errors="ignore").to_csv(
            os.path.join(outdir, f"r{r}_importance.csv"), index=False, encoding="utf-8-sig")
        rounds.append({"round": r, "excluded_before": list(excluded), "n_features": int(Xr.shape[1]),
                       "n_variables": len({str(c).split("=")[0] for c in Xr.columns}), "cv": cv,
                       "top": rows, "dominance": dominance, "charts": charts})
        mem["rounds"].append({"X": Xr, "vals": vals, "base": base})
        drop = []
        if r < int(cfg["rounds"]) and int(cfg["drop_top_per_round"]) > 0:
            drop = [row["feature"] for row in rows[: int(cfg["drop_top_per_round"])]]
        elif int(cfg["auto_rounds"]) > 0:
            if dominance and r <= int(cfg["auto_rounds"]):
                drop = [dominance]
            else:
                stop_reason = "지배 변수 없음" if not dominance else f"최대 {cfg['auto_rounds']}회 반복 도달"
        if not drop:
            break
        excluded += drop
        Xr = Xr.drop(columns=drop)
        if Xr.shape[1] < 2:
            warn.append("남은 X가 2개 미만이라 반복을 중단했습니다.")
            break

    res = {"run_id": run_id, "output_dir": outdir, "source": src, "filters_text": ftxt,
           "n_after_filter": int(len(df)), "n_rows": meta["n_rows"], "task": meta["task"], "classes": meta["classes"],
           "y": cfg["y"], "y_label": ylabel, "y_stats": meta["y_series_stats"], "model": MODEL_LABELS[model_name],
           "impute": IMPUTE_LABELS[cfg["impute"]], "preprocess_log": meta["log"], "warnings": list(dict.fromkeys(warn)),
           "rounds": rounds, "cfg": cfg, "font_ok": font_ok, "stop_reason": stop_reason,
           "round_compare": _round_compare(rounds) if len(rounds) > 1 else None}
    with open(os.path.join(outdir, "summary.json"), "w", encoding="utf-8") as fp:
        json.dump(res, fp, ensure_ascii=False, indent=1, default=str)
    res["_mem"] = mem  # 화면 차트용 원자료(행별 X·SHAP·예측). JSON으로 내보내지 않음
    return res


def smap_of(res: dict) -> dict:
    """결과에 남은 표시명으로 컬럼→표시명 대응을 만든다(_label 호환 객체)."""
    class _R:
        def __init__(self, label): self.display_name, self.unit = label, ""
    m = {}
    for rd in res["rounds"]:
        for t in rd["top"]:
            m.setdefault(t["feature"], _R(t["label"]))
    return m


def result_md(res: dict) -> str:
    """SHAP 결과를 마크다운 요약으로 만든다: 조건·Y·모델·전처리 로그, 회차별 변수 표와 CV, 회차 비교표, 경고. 지배 변수가 있으면 제외 후 재분석을 권장하는 문구를 붙인다.

    입력: res — run() 결과
    반환: 마크다운 문자열(부작용 없음)
    """
    cls = f" (양성={res['classes']['positive']}, 음성={res['classes']['negative']})" if res["classes"] else ""
    out = [f"### SHAP 분석 결과 `{res['run_id']}`",
           f"- 데이터: {res['source']} | 필터: {res['filters_text']} | 사용 {res['n_rows']}행 (필터 후 {res['n_after_filter']}행)",
           f"- Y: {res['y_label']} · {'회귀' if res['task'] == 'regression' else '분류'}{cls} · {_y_stats_text(res['y_stats'], res['task'])}",
           f"- 모델: {res['model']} · 결측 대치: {res['impute']}"]
    out += [f"- {STEP_LABELS.get(e['step'], e['step'])}: {e['detail']}" for e in res["preprocess_log"]]
    for rd in res["rounds"]:
        cv = rd["cv"]
        ex = f" · 이전 라운드 제외: {', '.join(_label(c, smap_of(res)) for c in rd['excluded_before'])}" if rd["excluded_before"] else ""
        out.append(f"\n#### Round {rd['round']} — X {rd['n_features']}개 · {cv['folds']}-fold CV {cv['metric']} "
                   f"{cv['mean']}±{cv['std']} ({cv['grade']}){ex}")
        out.append("| 순위 | 변수 | 평균|SHAP| | 비중 | 방향 | 기여 최대 구간 | 기여 최소 구간 |")
        out.append("|---|---|---|---|---|---|---|")
        for r in rd["top"]:
            out.append(f"| {r['rank']} | {r['label']} | {r['mean_abs_shap']} | {r['share']:.1%} | {r['direction']} | "
                       f"{r.get('best_range', '-')} | {r.get('worst_range', '-')} |")
        if rd["dominance"]:
            out.append(f"⚠ 지배 변수: `{rd['dominance']}` 비중 {rd['top'][0]['share']:.0%} — 결과성 변수이거나 Y와 함께 움직이는 변수인지 확인 후 제외 재분석 권장")
        out.append("차트: " + ", ".join(rd["charts"]))
    rc = res.get("round_compare")
    if rc:
        out.append("\n#### 회차 비교" + (f" (자동 반복 종료: {res['stop_reason']})" if res.get("stop_reason") else ""))
        out.append("| 변수 | " + " | ".join(f"{i + 1}회차" for i in range(len(rc["cv"]))) + " |")
        out.append("|---|" + "---|" * len(rc["cv"]))
        out.append("| CV | " + " | ".join(f"{c['metric']} {c['mean']}" for c in rc["cv"]) + " |")
        for f in rc["features"]:
            cells = [("제외" if x == "제외" else "-" if x is None else f"{x['rank']}위 {x['share']:.0%}") for x in f["ranks"]]
            out.append(f"| {f['label']} | " + " | ".join(cells) + " |")
    for w in res["warnings"]:
        out.append(f"- ⚠ {w}")
    return "\n".join(out)


# ----------------------------------------------------------------------------- PDF용 차트(PDF는 실행기가 common/report.py로 만든다)

def ensure_charts(res: dict, kinds=None) -> None:
    """PDF에 쓸 정적 차트를 지금 만든다. 실행 때는 차트를 만들지 않으므로(화면 차트는 브라우저가 그림) 남겨 둔 모델 결과(_mem)로 차트가 없는 회차만 그린다.

    입력: res — run() 결과(_mem 포함), kinds — 만들 차트 목록(None이면 전체)
    반환: 없음. 부작용: 회차별 charts 목록 채우기, PNG 파일 쓰기. 모든 회차에 차트가 있거나 _mem이 없으면 아무 일도 하지 않음
    """
    if all(rd["charts"] for rd in res["rounds"]) or "_mem" not in res:
        return
    font_ok = _setup_font()
    smap = {}
    for rd in res["rounds"]:
        for t in rd["top"]:
            smap.setdefault(t["feature"], t["label"])
    cfg = {**res["cfg"], "charts": kinds}
    mem = res["_mem"]
    ids = mem["rows"][cfg["id_col"]].astype(str).tolist() if cfg.get("id_col") and cfg["id_col"] in mem["rows"].columns else None
    title = res["y_label"] if res["task"] == "regression" else f"{res['y_label']}={res['classes']['positive']}"
    for rd, m in zip(res["rounds"], mem["rounds"]):
        if rd["charts"]:
            continue
        X = m["X"].reset_index(drop=True)
        labels = [smap.get(c, c) if font_ok else c for c in X.columns]
        rd["charts"] = _charts(X, m["vals"], m["base"], rd["top"], labels, res["output_dir"], f"r{rd['round']}", cfg, ids, title,
                               mem["y"], res["task"])
