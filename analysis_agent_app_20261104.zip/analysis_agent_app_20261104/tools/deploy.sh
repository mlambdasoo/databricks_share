#!/usr/bin/env bash
# 앱 배포: 프런트 빌드 → app/ 복사(outputs·캐시 제외) → 워크스페이스 동기화 → 로컬에 없는 원격 파일 삭제 → apps deploy
#   PROFILE=<CLI 프로필> APP=<앱 이름> WS=/Workspace/Users/<사용자>/<폴더>/app bash tools/deploy.sh
#   (앱은 먼저 만들어 둔다: databricks apps create … — SETUP.txt 5번)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PROFILE="${PROFILE:?PROFILE(Databricks CLI 프로필)을 지정하세요}"
APP="${APP:?APP(앱 이름)을 지정하세요}"
WS="${WS:?WS(소스를 올릴 워크스페이스 경로)를 지정하세요}"
SRC="/tmp/analysis_agent_deploy_src_${APP}"

(cd "$ROOT/frontend" && npm run build >/dev/null)
rm -rf "$SRC" && mkdir -p "$SRC"
rsync -a --exclude outputs --exclude __pycache__ --exclude .databricks --exclude mlruns --exclude mlflow.db "$ROOT/app/" "$SRC/"  # mlruns·mlflow.db = 로컬 실행 때 생긴 MLflow 파일
databricks sync "$SRC" "$WS" --full --profile "$PROFILE" | tail -1

# sync는 이전에 올린 파일 목록(snapshot)을 모르면 지운 파일을 원격에서 지우지 않는다 → 직접 비교해 삭제
walk() {
  databricks workspace list "$1" --profile "$PROFILE" -o json | python3 -c '
import json, sys
for o in json.load(sys.stdin): print(o["object_type"], o["path"])' |
  while read -r t p; do if [ "$t" = DIRECTORY ]; then walk "$p"; else echo "${p#"$WS"/}"; fi; done
}
comm -23 <(walk "$WS" | sort) <(cd "$SRC" && find . -type f ! -path './.databricks/*' | sed 's|^\./||' | sort) | while read -r f; do
  echo "원격 삭제: $f"
  databricks workspace delete "$WS/$f" --profile "$PROFILE"
done
# 비게 된 폴더 삭제
walk_dirs() {
  databricks workspace list "$1" --profile "$PROFILE" -o json | python3 -c '
import json, sys
for o in json.load(sys.stdin):
    if o["object_type"] == "DIRECTORY": print(o["path"])' | while read -r d; do walk_dirs "$d"; echo "$d"; done
}
walk_dirs "$WS" | while read -r d; do
  [ -d "$SRC/${d#"$WS"/}" ] || { echo "원격 폴더 삭제: ${d#"$WS"/}"; databricks workspace delete "$d" --recursive --profile "$PROFILE"; }
done

databricks apps deploy "$APP" --source-code-path "$WS" --profile "$PROFILE" | grep -E '"state"|"message"' | tail -2
