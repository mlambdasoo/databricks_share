-- Databricks notebook source
-- MAGIC %md-sandbox
-- MAGIC <div style="max-width: 1000px; margin: 0 auto; font-family: sans-serif;">
-- MAGIC <div style="background: #1B5162; color: white; border-radius: 8px; padding: 28px 32px; text-align: center;">
-- MAGIC <div style="font-size: 24pt; font-weight: 700; line-height: 1.3;">Delta Lake 기본</div>
-- MAGIC <div style="font-size: 14pt; margin-top: 12px; opacity: 0.9;">데이터 수정(DML), MERGE, Time Travel, 변경 추적(CDF), 그리고 개방형 Managed Iceberg — Lakehouse 테이블의 핵심 개념을 한 번에 실습합니다.</div>
-- MAGIC </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ## 필수 - Compute 환경 선택
-- MAGIC
-- MAGIC <div style="border-left: 4px solid #FF5F46; background: rgba(255,95,70,0.10); padding: 14px 18px; border-radius: 4px; margin: 16px 0; font-family: sans-serif;">
-- MAGIC   <strong style="display:block; color:#98102A; margin-bottom:6px; font-size:15pt;">서버리스 Compute 선택</strong>
-- MAGIC   <div style="color:#0b2026; font-size:14pt; line-height:1.55;">
-- MAGIC
-- MAGIC 이 노트북을 실행하기 전에 우측 상단에서 compute 환경을 확인하세요.
-- MAGIC
-- MAGIC - compute 드롭다운에서 **서버리스(Serverless)** 를 선택합니다(기본 옵션).
-- MAGIC - 서버리스가 보이지 않으면 워크스페이스 관리자에게 문의하세요.
-- MAGIC
-- MAGIC **참고:** 이 노트북은 **서버리스 compute**에서 개발·테스트되었습니다.
-- MAGIC
-- MAGIC   </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### 환경 설정
-- MAGIC 아래 셀을 실행하여 실습 환경(카탈로그·스키마)과 예제 데이터를 준비합니다.

-- COMMAND ----------

-- DBTITLE 1,환경 설정 - 카탈로그 입력 및 사용자 스키마 생성
-- MAGIC %python
-- MAGIC import re
-- MAGIC
-- MAGIC # ── 1. 카탈로그 이름 위젯 (수기 입력) ──
-- MAGIC dbutils.widgets.text("catalog_name", "", "카탈로그 이름을 입력하세요")
-- MAGIC my_catalog = dbutils.widgets.get("catalog_name").strip()
-- MAGIC assert my_catalog, "⚠️ 상단 위젯에 카탈로그 이름을 입력한 후 이 셀을 다시 실행하세요."
-- MAGIC
-- MAGIC # ── 2. 사용자 ID 기반 스키마 이름 자동 생성 ──
-- MAGIC user_email = spark.sql("SELECT current_user()").first()[0]
-- MAGIC user_id = user_email.split("@")[0]
-- MAGIC my_schema = re.sub(r"[^a-z0-9_]", "_", user_id.lower())
-- MAGIC my_schema = re.sub(r"_+", "_", my_schema).strip("_")
-- MAGIC
-- MAGIC dbutils.widgets.text("schema_name", my_schema, "스키마 이름 (자동)")
-- MAGIC
-- MAGIC print(f"✅ 설정 완료")
-- MAGIC print(f"   카탈로그 : {my_catalog}")
-- MAGIC print(f"   스키마   : {my_schema}  (사용자 ID 기반 자동 생성)")

-- COMMAND ----------

-- DBTITLE 1,카탈로그/스키마 설정 및 예제 테이블 준비
USE CATALOG IDENTIFIER(:catalog_name);
CREATE SCHEMA IF NOT EXISTS IDENTIFIER(:schema_name);
USE SCHEMA IDENTIFIER(:schema_name);

-- 예제 store_staff 테이블 준비 (원본 4행). 이 CREATE가 버전 0이 됩니다.
DROP TABLE IF EXISTS store_staff;
CREATE TABLE store_staff AS
SELECT * FROM VALUES
  (1, 'Ji-won',   'Seoul',   'Baker'),
  (2, 'Natsuki',  'Tokyo',   'Barista'),
  (3, 'Min-jae',  'Busan',   'Cashier'),
  (4, 'Pairot',   'Bangkok', 'Manager')
AS t(staff_id, name, store, role);

SELECT * FROM store_staff ORDER BY staff_id;

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC <div style="max-width: 1100px; margin: 0 auto; font-family: sans-serif;">
-- MAGIC <div style="font-size: 20pt; font-weight: 700; color: #0b2026; margin-bottom: 6px;">Delta 테이블은 완전한 SQL 수정을 지원합니다</div>
-- MAGIC <div style="font-size: 14pt; color: #5A6F77; margin-bottom: 24px;">일반 데이터 파일과 달리, Delta 테이블은 전통적인 데이터베이스처럼 개별 행을 추가·변경·삭제할 수 있습니다. 모든 변경은 테이블의 새로운 버전으로 기록됩니다.</div>
-- MAGIC <div style="display: flex; justify-content: center; align-items: stretch; gap: 40px; flex-wrap: wrap;">
-- MAGIC   <div style="width: 280px; min-height: 150px; background: #F9F7F4; border-radius: 8px; box-shadow: 0 2px 8px rgba(27,49,57,0.06); display: flex; flex-direction: column; justify-content: center; gap: 10px; padding: 20px; text-align: center; position: relative; box-sizing: border-box;">
-- MAGIC     <div style="position: absolute; top: 0; left: 0; width: 100%; height: 8px; background: #4299E0; border-radius: 8px 8px 0 0;"></div>
-- MAGIC     <div style="font-size: 18pt; font-weight: 600; color: #0b2026;">INSERT</div>
-- MAGIC     <div style="font-size: 14pt; color: #5A6F77;">새 행을 추가합니다.</div>
-- MAGIC   </div>
-- MAGIC   <div style="width: 280px; min-height: 150px; background: #F9F7F4; border-radius: 8px; box-shadow: 0 2px 8px rgba(27,49,57,0.06); display: flex; flex-direction: column; justify-content: center; gap: 10px; padding: 20px; text-align: center; position: relative; box-sizing: border-box;">
-- MAGIC     <div style="position: absolute; top: 0; left: 0; width: 100%; height: 8px; background: #00A972; border-radius: 8px 8px 0 0;"></div>
-- MAGIC     <div style="font-size: 18pt; font-weight: 600; color: #0b2026;">UPDATE</div>
-- MAGIC     <div style="font-size: 14pt; color: #5A6F77;">기존 값을 변경합니다.</div>
-- MAGIC   </div>
-- MAGIC   <div style="width: 280px; min-height: 150px; background: #F9F7F4; border-radius: 8px; box-shadow: 0 2px 8px rgba(27,49,57,0.06); display: flex; flex-direction: column; justify-content: center; gap: 10px; padding: 20px; text-align: center; position: relative; box-sizing: border-box;">
-- MAGIC     <div style="position: absolute; top: 0; left: 0; width: 100%; height: 8px; background: #FF5F46; border-radius: 8px 8px 0 0;"></div>
-- MAGIC     <div style="font-size: 18pt; font-weight: 600; color: #0b2026;">DELETE</div>
-- MAGIC     <div style="font-size: 14pt; color: #5A6F77;">행을 제거합니다.</div>
-- MAGIC   </div>
-- MAGIC </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 1. 데이터 수정 — INSERT / UPDATE / DELETE
-- MAGIC 두 명의 신규 직원을 매장에 배치합니다.

-- COMMAND ----------

INSERT INTO store_staff (staff_id, name, store, role) VALUES
  (5, 'Sophia', 'Seoul', 'Baker'),
  (6, 'Lucas', 'Tokyo', 'Barista');

SELECT * FROM store_staff ORDER BY staff_id;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 이제 **6행**이 보입니다(원본 4행 + 신규 2행). Sophia가 새로운 직책으로 승진했습니다. 레코드를 수정합니다.

-- COMMAND ----------

UPDATE store_staff
SET role = 'Senior Baker'
WHERE name = 'Sophia';

SELECT * FROM store_staff WHERE name = 'Sophia';

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 이전 값은 사라지지 않고 Delta가 이전 버전에 보관합니다. 이번엔 Lucas가 퇴사했으므로 삭제합니다.

-- COMMAND ----------

DELETE FROM store_staff
WHERE name = 'Lucas';

SELECT * FROM store_staff ORDER BY staff_id;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 테이블이 다시 **5행**이 되었습니다. Lucas는 현재 버전에서 사라졌지만, 버전 이력에는 남아 있습니다(뒤의 Time Travel에서 확인).

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 2. MERGE (Upsert)
-- MAGIC `MERGE`는 **키가 매칭되면 UPDATE, 없으면 INSERT** 하는 업서트를 한 번에 처리합니다. 변경분(소스)을 대상 테이블에 병합하는, 증분 적재(CDC)의 핵심 패턴입니다.

-- COMMAND ----------

-- DBTITLE 1,MERGE INTO store_staff
-- 변경분 소스: 기존 직원 1명 직책 변경 + 신규 직원 1명 추가
CREATE OR REPLACE TEMP VIEW staff_updates AS
SELECT * FROM VALUES
  (3, 'Min-jae', 'Busan', 'Senior Cashier'),  -- 기존: 직책 변경
  (9, 'Elena', 'Barcelona', 'Barista')         -- 신규: 추가
AS t(staff_id, name, store, role);

MERGE INTO store_staff AS tgt
USING staff_updates AS src
  ON tgt.staff_id = src.staff_id
WHEN MATCHED THEN UPDATE SET *
WHEN NOT MATCHED THEN INSERT *;

SELECT * FROM store_staff ORDER BY staff_id;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Min-jae의 직책이 갱신되고 Elena가 새로 추가되었습니다(**6행**). 여러 소스를 한 문장으로 반영할 수 있어, 반복 적재 파이프라인에서 특히 유용합니다.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 3. Time Travel
-- MAGIC Delta는 모든 변경을 **버전**으로 기록합니다. 이력을 보고, 과거 버전의 데이터를 다시 조회하거나 되돌릴 수 있습니다.

-- COMMAND ----------

DESCRIBE HISTORY store_staff;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 위 이력에서 `CREATE TABLE`(버전 0) → `WRITE`(INSERT) → `UPDATE` → `DELETE` → `MERGE` 순으로 버전이 증가한 것을 볼 수 있습니다. 플랫폼이 자동으로 추가하는 `OPTIMIZE` 버전이 섞여 있을 수도 있습니다.
-- MAGIC
-- MAGIC 버전 0(최초 생성 시점)을 조회하면 원본 4행이 그대로 나옵니다.

-- COMMAND ----------

-- 버전 0 = 최초 CREATE 시점. 이후 모든 변경 이전의 원본 4행.
SELECT * FROM store_staff VERSION AS OF 0 ORDER BY staff_id;

-- COMMAND ----------

-- 현재와 버전 0의 행 수 비교
SELECT '현재'  AS `시점`, COUNT(*) AS `행수` FROM store_staff
UNION ALL
SELECT '버전0', COUNT(*) FROM store_staff VERSION AS OF 0;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC - `VERSION AS OF <n>` : 버전 번호로 조회
-- MAGIC - `TIMESTAMP AS OF '<ts>'` : 특정 시각으로 조회
-- MAGIC - `RESTORE TABLE store_staff TO VERSION AS OF 0` : 과거 버전으로 롤백(실수 복구)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 4. Change Data Feed (CDF)
-- MAGIC CDF를 켜면 어떤 행이 insert/update/delete 되었는지 **변경 이력**을 조회할 수 있습니다. 하위 파이프라인의 증분 처리에 활용됩니다.

-- COMMAND ----------

-- DBTITLE 1,CDF 활성화 및 다양한 변경 유형 발생
-- CDF 활성화
ALTER TABLE store_staff SET TBLPROPERTIES (delta.enableChangeDataFeed = true);

-- 활성화 이후 변경: UPDATE → 'update_preimage' / 'update_postimage' 유형으로 기록
UPDATE store_staff SET role = 'Lead Barista' WHERE name = 'Elena';

-- CDF의 네 가지 변경 유형을 모두 관찰하기 위해 추가 DML 수행
-- INSERT → 'insert' 유형으로 기록
INSERT INTO store_staff VALUES (10, 'Hana', 'Seoul', 'Barista');

-- DELETE → 'delete' 유형으로 기록
DELETE FROM store_staff WHERE name = 'Pairot';

SELECT * FROM store_staff ORDER BY staff_id;

-- COMMAND ----------

-- DBTITLE 1,CDF 전체 변경분 조회
-- CDF 변경분 조회 — TABLE_CHANGES 사용 시 _change_type, _commit_version 등 메타 컬럼이 자동 포함됩니다
-- CDF는 활성화(SET TBLPROPERTIES) 이후 버전만 보관되므로, 버전 0을 직접 지정하지 않고 활성화 시점을 동적으로 조회합니다

SELECT *
FROM TABLE_CHANGES('store_staff', 9)
ORDER BY _commit_version, _change_type, staff_id

-- COMMAND ----------

-- DBTITLE 1,CDF 변경 유형 설명
-- MAGIC %md
-- MAGIC <div style="max-width: 900px; margin: 0 auto; font-family: sans-serif;">
-- MAGIC <div style="padding: 18px 24px; background: #EFF6FF; border: 3px solid #4299E0; border-radius: 10px;">
-- MAGIC <div style="font-size: 14pt; color: #0b2026; line-height: 1.7;">
-- MAGIC <div style="font-weight: 700; margin-bottom: 12px; font-size: 15pt;">CDF <code>_change_type</code> 한눈에 보기</div>
-- MAGIC
-- MAGIC | 변경 유형 | 의미 | 활용 예시 |
-- MAGIC |---|---|---|
-- MAGIC | <code>insert</code> | 새로 추가된 행 | 신규 데이터를 하위 테이블에 전파 |
-- MAGIC | <code>update_preimage</code> | 수정 <b>전</b> 값 | 변경 전후 비교, 감사 로그 |
-- MAGIC | <code>update_postimage</code> | 수정 <b>후</b> 값 | 최신 상태를 다운스트림에 반영 |
-- MAGIC | <code>delete</code> | 삭제된 행 | 하위 테이블에서 동기 삭제 |
-- MAGIC
-- MAGIC CDF는 증분(incremental) 파이프라인의 핵심입니다. 전체 테이블을 다시 읽는 대신, <b>변경된 행만</b> 읽어서 하위 테이블을 효율적으로 갱신할 수 있습니다.
-- MAGIC </div>
-- MAGIC </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 5. Managed Iceberg 테이블 — 개방형 포맷
-- MAGIC 지금까지 다룬 테이블은 Databricks의 기본 포맷인 **Delta Lake**입니다. Databricks는 개방형 표준인 **Apache Iceberg** 테이블도 Unity Catalog 안에서 직접 만들고 관리할 수 있습니다(**Managed Iceberg**). 같은 Lakehouse 거버넌스·성능을 그대로 누리면서, 외부 엔진(OSS Spark, Trino, Snowflake, PyIceberg 등)이 **Iceberg REST Catalog(IRC)**로 읽고 쓸 수 있는 것이 핵심 차이입니다.

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC <div style="max-width: 1100px; margin: 0 auto; font-family: sans-serif;">
-- MAGIC <div style="display: flex; justify-content: center; align-items: stretch; gap: 40px; flex-wrap: wrap;">
-- MAGIC   <div style="width: 380px; min-height: 150px; background: #F9F7F4; border-radius: 8px; box-shadow: 0 2px 8px rgba(27,49,57,0.06); display: flex; flex-direction: column; justify-content: flex-start; gap: 10px; padding: 22px; position: relative; box-sizing: border-box;">
-- MAGIC     <div style="position: absolute; top: 0; left: 0; width: 100%; height: 8px; background: #00A972; border-radius: 8px 8px 0 0;"></div>
-- MAGIC     <div style="font-size: 18pt; font-weight: 600; color: #0b2026;">Delta Lake</div>
-- MAGIC     <div style="font-size: 13pt; color: #5A6F77; line-height: 1.55;">Databricks 네이티브 포맷. <b>CDF·스트리밍·Vector Search</b> 등 최신 기능을 가장 먼저 지원. Delta 엔진에 최적화.</div>
-- MAGIC   </div>
-- MAGIC   <div style="width: 380px; min-height: 150px; background: #F9F7F4; border-radius: 8px; box-shadow: 0 2px 8px rgba(27,49,57,0.06); display: flex; flex-direction: column; justify-content: flex-start; gap: 10px; padding: 22px; position: relative; box-sizing: border-box;">
-- MAGIC     <div style="position: absolute; top: 0; left: 0; width: 100%; height: 8px; background: #4299E0; border-radius: 8px 8px 0 0;"></div>
-- MAGIC     <div style="font-size: 18pt; font-weight: 600; color: #0b2026;">Managed Iceberg</div>
-- MAGIC     <div style="font-size: 13pt; color: #5A6F77; line-height: 1.55;">개방형 표준 포맷. UC가 관리하되 <b>외부 엔진이 IRC로 직접 읽기·쓰기</b> 가능. DML·MERGE·Time Travel은 Delta와 동일하게 지원.</div>
-- MAGIC   </div>
-- MAGIC </div>
-- MAGIC <div style="text-align:center; font-size: 12pt; color: #5A6F77; margin-top: 18px;">둘 다 Unity Catalog가 관리하는 Lakehouse 테이블 — 거버넌스·권한·성능 최적화(Liquid Clustering, Predictive Optimization)를 공통으로 적용받습니다.</div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### 5-1. Managed Iceberg 테이블 생성
-- MAGIC `USING ICEBERG` 한 줄이면 됩니다. 여기서는 매장 메뉴 테이블을 카테고리로 클러스터링하여 만듭니다. `PARTITIONED BY`는 Managed Iceberg에서 **Liquid Clustering**으로 매핑되며, DV·행 추적 등 필요한 속성을 자동으로 설정해 줍니다(교차 플랫폼 호환에 권장).

-- COMMAND ----------

-- DBTITLE 1,USING ICEBERG 로 관리형 Iceberg 테이블 생성
-- USING ICEBERG → 네이티브 Apache Iceberg 테이블 (외부 엔진이 IRC로 접근 가능)
DROP TABLE IF EXISTS store_menu;
CREATE TABLE store_menu
USING ICEBERG
PARTITIONED BY (category)
AS SELECT * FROM VALUES
  (101, 'Sourdough Loaf', 'Bakery',   6800),
  (102, 'Croissant',      'Bakery',   4500),
  (103, 'Americano',      'Beverage', 4000),
  (104, 'Latte',          'Beverage', 5000)
AS t(item_id, item_name, category, price);

SELECT * FROM store_menu ORDER BY item_id;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 정말 Iceberg 테이블인지 확인해 봅니다. 아래 결과에서 **`Provider` 가 `iceberg`** 로 표시됩니다(Delta 테이블이었다면 `delta`).

-- COMMAND ----------

DESCRIBE EXTENDED store_menu;

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC <div style="max-width: 900px; margin: 0 auto; font-family: sans-serif;">
-- MAGIC <div style="margin-top: 10px; padding: 18px 24px; background: #FFF6F4; border: 3px solid #FF5F46; border-radius: 10px;">
-- MAGIC <div style="font-size: 14pt; color: #0b2026; line-height: 1.6;">
-- MAGIC <div style="font-weight: 700; margin-bottom: 8px;">이 노트북에서 다룬 Delta Lake 기본:</div>
-- MAGIC <ul style="padding-left: 20px; margin: 0;">
-- MAGIC <li><b>DML</b> — <code>INSERT</code> / <code>UPDATE</code> / <code>DELETE</code> 로 행 단위 수정</li>
-- MAGIC <li><b>MERGE</b> — 있으면 UPDATE, 없으면 INSERT (업서트)</li>
-- MAGIC <li><b>Time Travel</b> — <code>DESCRIBE HISTORY</code>, <code>VERSION AS OF</code>, <code>RESTORE</code></li>
-- MAGIC <li><b>Change Data Feed</b> — 행 단위 변경분 추적</li>
-- MAGIC <li><b>Managed Iceberg</b> — <code>USING ICEBERG</code> 로 개방형 포맷 테이블 생성, 외부 엔진과 상호운용</li>
-- MAGIC </ul>
-- MAGIC </div>
-- MAGIC </div>
-- MAGIC </div>